package main_pkg;

import java.io.File;
import java.io.IOException;
import java.io.PrintWriter;
import java.util.Scanner;

public class CSVProcessor {
	public static void writeCSV(byte[][] image,String pathOut,String filename) {
		if(!filename.endsWith(".csv")) {
			filename+=".csv";
		}
		try(PrintWriter csvout = new PrintWriter(new File(pathOut+File.separator+filename))) {
			for (byte[] ligne:image) {
				for(int i = 0;i < ligne.length;i++) {
					csvout.print(ligne[i]+(i<(ligne.length-1) ? "," : ""));
					
				}
				csvout.println("");
			}
		} catch (Exception e) {
			System.err.println(e.getMessage());
		}
	}
	
	public static byte[][] readCSV(String pahtIn,int[] dim) throws IOException{
		
		// ENREGISTRER L'IMAGE DANS UNE MATRICE:
		byte[][] image = new byte[dim[0]][];
		File monFichierCSV = new File(pahtIn);
		Scanner sc = new Scanner(monFichierCSV);
		int ligne =0;
		while(sc.hasNext()) {
			String chaine = sc.next();
			byte[] row = str2ByteArray(chaine);
			image[ligne]=row;
			ligne++;
			
		}
		sc.close();
		return image;
		
	}
	public static byte[] str2ByteArray(String chaine) {
		String[] tmp_str = chaine.split(",");
		byte[] res = new byte[tmp_str.length];
		for(int i = 0; i < tmp_str.length; i++) {
			res[i]=Byte.parseByte(tmp_str[i]);
		}
		return res;
	}
}
