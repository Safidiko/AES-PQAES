package main_pkg;

public  class ImageProcessing {
	public static boolean estIdentique(byte[][]image1,byte[][]image2) {
		if(image1.length != image2.length && image1[0].length != image2[0].length)
			return false;
		for(int i=0; i<image1.length;i++) {
			for(int j=0;j<image1[0].length;j++) {
				if(image1[i][j] != image2[i][j]) {
					return false;
				}
			}
			
		}
		return true;
	}
	
	public static double calculateMSE(byte[][]image1,byte[][]image2) {
		double mse = 0;
		int ligne = image1.length;
		int col   = image1[0].length;
		for(int i=0; i<ligne;i++) {
			for(int j=0;j<col;j++) {
				if(image1[i][j] != image2[i][j]) {
					mse+=Math.pow(image1[i][j] - image2[i][j], 2);
				}
			}
		}
		return mse/(ligne*col);
	}
	
	public static double calculPsnr(double mse) {
		double max = 255;
		return 10 * Math.log10(max*max/mse);
	}
}
