package main_pkg;
import java.io.File;
import java.io.FileWriter;


public class Indicator {
	String[] hash_function;
	int [] length_hash_function;
	PQ_AES pqaes;
	AES aes;
	byte[] bytesKey;
	
	String [][]msg = new String [5][4];
	int[] wordsKeyExpansion;
	int[] pq_wordsKeyExpansion;
	
	String padd_method[] = {"PKCS","ANSI_x923","W3C","OneZero"};
	
	
	/*inspired on : https://waytolearnx.com/2020/03/exporter-des-donnees-dans-un-fichier-csv-en-java.html*/
	  //D�limiteurs qui doivent �tre dans le fichier CSV
	    @SuppressWarnings("unused")
		private static final String DELIMITER = ",";
	    private static final String SEPARATOR = "\n";

	
	public  void initialize_msg() {
		/*for 256bits*/
		msg[0][0] = "";
		msg[0][1] = "Comparing aes and pqaes:";
		msg[0][2] = "Comparing padded aes and pqaes:";
		msg[0][3] = "Comparing padded aes and pqaes :";
		
		/*for 512bits*/
		msg[1][0] = "";
		msg[1][1] = "Comparing padded aes and pqaes :";
		msg[1][2] = "Comparing padded aes and pqaes with PKCS WC3 OneZero ANSI_x923:";
		msg[1][3] = "Comparing padded aes and pqaes with PKCS WC3 OneZero ANSI_x923 :";
		
		/*for 1024bits*/
		msg[2][0] = "";
		msg[2][1] = "Comparing padded aes and pqaes with PKCS WC3 OneZero ANSI_x923 :";
		msg[2][2] = "Comparing padded aes and pqaes with PKCS WC3 OneZero ANSI_x923 using bit length : 256 512 1024 2048 4096 with time evaluation :";
		msg[2][3] = "Comparing padded aes and pqaes with PKCS WC3 OneZero ANSI_x923 using bit length : 256 512 1024 2048 4096 with time evaluation  :";

		/*for 2048bits*/
		msg[3][0] = "";
		msg[3][1] = "Comparing padded aes and pqaes with PKCS WC3 OneZero ANSI_x923 using bit length : 256 512 1024 2048 4096 with time evaluation  :";
		msg[3][2] = "Comparing padded aes and pqaes with PKCS WC3 OneZero ANSI_x923 using bit length : 256 512 1024 2048 4096 with time evaluation while the pqaes uses HMAC (Hash-based Message Authentication Code) Key Derivation Function (HKDF):SHA,SHA3,SHAKE,KECCAK,RAWSHAKE:";
		msg[3][3] = "Comparing padded aes and pqaes with PKCS WC3 OneZero ANSI_x923 using bit length : 256 512 1024 2048 4096 with time evaluation while the pqaes uses HMAC (Hash-based Message Authentication Code) Key Derivation Function (HKDF):SHA,SHA3,SHAKE,KECCAK,RAWSHAKE :";

		/*for 4096bits*/
		msg[4][0] = "";
		msg[4][1] = "Comparing padded aes and pqaes with PKCS WC3 OneZero ANSI_x923 using bit length : 256 512 1024 2048 4096 with time evaluation while the pqaes uses HMAC (Hash-based Message Authentication Code) Key Derivation Function (HKDF):SHA,SHA3,SHAKE,KECCAK,RAWSHAKE :";
		msg[4][2] = "Comparing padded aes and pqaes with PKCS WC3 OneZero ANSI_x923 using bit length : 256 512 1024 2048 4096 with time evaluation while the pqaes uses HMAC (Hash-based Message Authentication Code) Key Derivation Function (HKDF):SHA,SHA3,SHAKE,KECCAK,RAWSHAKE in the wordsKeyExpansion knowing that aes/pqaes cipher mode applies addRoundKey, subBytes, shiftRows, mixColumns for each round. Auxilliary functions like sboxTransform, shiftRows, mixColumns give the good performance of the AES/PQAES(postquantum crypto) :";
		msg[4][3] = "Comparing padded aes and pqaes with PKCS WC3 OneZero ANSI_x923 using bit length : 256 512 1024 2048 4096 with time evaluation while the pqaes uses HMAC (Hash-based Message Authentication Code) Key Derivation Function (HKDF):SHA,SHA3,SHAKE,KECCAK,RAWSHAKE in the wordsKeyExpansion knowing that aes/pqaes cipher mode applies addRoundKey, subBytes, shiftRows, mixColumns for each round. Auxilliary functions like sboxTransform, shiftRows, mixColumns give the good performance of the AES/PQAES(postquantum crypto)  :";

		
		
		
	}
	public Indicator(String[] hash_function, int [] length_hash_function) {
		// TODO Auto-generated constructor stub
		this.hash_function = hash_function;
		this.length_hash_function = length_hash_function;
		initialize_msg();
	}



	public AES getAes() {
		return aes;
	}



	public void setAes(AES aes) {
		this.aes = aes;
	}



	public void setHash_function(String[] hash_function) {
		this.hash_function = hash_function;
	}



	public void setLength_hash_function(int[] length_hash_function) {
		this.length_hash_function = length_hash_function;
	}
	


	public void setPqaes(PQ_AES pqaes) {
		this.pqaes = pqaes;
	}



	public void setBytesKey(byte[] bytesKey) {
		this.bytesKey = bytesKey;
	}
	

	
	public ExtractIndicator treatement(int h, int l) {
	      FileWriter file = null;
	      ExtractIndicator extr = new ExtractIndicator(hash_function, length_hash_function);
	      try
	      {
	    	  /*PQAES*/
	    	 /*creating file inspired on : https://zetcode.com/java/createfile/#:~:text=The%20File%27s%20createNewFile%20method%20creates,name%20does%20not%20yet%20exist.&text=The%20createNewFile%20returns%20true%20if,the%20named%20file%20already%20exists.
	    	  * https://stackoverflow.com/questions/9620683/java-fileoutputstream-create-file-if-not-exists 
	    	  * */
	    	String status = "log_";
	    	String namefile = status+"PQAES_"+this.hash_function[h]+"_"+this.length_hash_function[l]+".txt";
	    	File yourFile = new File("src/"+namefile);
	    	yourFile.createNewFile(); 
	        
	    	file = new FileWriter("src/"+namefile);
	        //Ajouter une nouvelle ligne apr�s l'en-t�te
//		        file.append(DELIMITER);
			for(int indice_msg = 0; indice_msg < 4; indice_msg++) {
				if((h <= 3)&&(length_hash_function[l] >=1024)) {
					//pqaes.setkey(bytesKey) with expandable 256bits
					//wordsKeyExpansion = aes.createKeyExpansion(bytesKey);
					pqaes.setkey(bytesKey);
					extr.pqaes_time_word_expansion -= (System.nanoTime()/1000);
					pq_wordsKeyExpansion = pqaes.createKeyExpansion(hash_function[h], 256); //expandable 256bits
					extr.pqaes_time_word_expansion += (System.nanoTime()/1000);
					extr.pqaes_time_word_expansion_cmpt+=1;
					
					
				}else {
				
					//wordsKeyExpansion = aes.createKeyExpansion(bytesKey);
					pqaes.setkey(bytesKey);
					extr.pqaes_time_word_expansion -= (System.nanoTime()/1000);
					pq_wordsKeyExpansion = pqaes.createKeyExpansion(hash_function[h], length_hash_function[l]); 
					extr.pqaes_time_word_expansion += (System.nanoTime()/1000);
					extr.pqaes_time_word_expansion_cmpt+=1;

					
				}
				
				file.append(Indicator.SEPARATOR);
				file.append(Indicator.SEPARATOR);
				
				String strMessage = msg[l][indice_msg];
				//System.out.println("Plain "+strMessage + "with "+l);
				file.append("plain_text:"+strMessage);
				file.append(Indicator.SEPARATOR);

				//CIPHERING MODE WITH PADDING
				byte [] bytesMessage = strMessage.getBytes();
				file.append("Encode_PlainText:"+pqaes.toHexString(bytesMessage));		
				file.append(Indicator.SEPARATOR);
				//PADDING METHODS
				int init_pad = -1;
				if(length_hash_function[l]<=2048) {
					init_pad = 0;
				}else {
					init_pad = 1; 
				}
				
				for(int ind_pad = init_pad; ind_pad < this.padd_method.length; ind_pad++) {
					
					switch(ind_pad) {
						case 0:
							extr.pqaes_time_padding_pkcs -= (System.nanoTime()/1000);
						break;
						case 1:
							extr.pqaes_time_padding_ansi_9323 -= (System.nanoTime()/1000);
						break;
						case 2:
							extr.pqaes_time_padding_wc3 -= (System.nanoTime()/1000);
						break;
						case 3:
							extr.pqaes_time_padding_one_zero -= (System.nanoTime()/1000);
						break;
						default :
						break;
					}
					
					byte [] pq_msg_pad = pqaes.padding_all(bytesMessage, this.padd_method[ind_pad]);
					switch(ind_pad) {
					case 0:
						extr.pqaes_time_padding_pkcs += (System.nanoTime()/1000);
						extr.pqaes_time_padding_pkcs_cmpt+=1;
					break;
					case 1:
						extr.pqaes_time_padding_ansi_9323 += (System.nanoTime()/1000);
						extr.pqaes_time_padding_ansi_9323_cmpt +=1;
					break;
					case 2:
						extr.pqaes_time_padding_wc3 += (System.nanoTime()/1000);
						extr.pqaes_time_padding_wc3_cmpt +=1;
					break;
					case 3:
						extr.pqaes_time_padding_one_zero += (System.nanoTime()/1000);
						extr.pqaes_time_padding_one_zero_cmpt+=1;
					break;
					default :
					break;
				}
										
					file.append("Padding_"+this.padd_method[ind_pad]+":"+pqaes.toHexString(pq_msg_pad));
					file.append(Indicator.SEPARATOR);
					
					
					

					
					extr.pqaes_time_ciphering -= (System.nanoTime()/1000);
					byte [] pq_msg_pad_enc = pqaes.cipher(pq_msg_pad, pq_wordsKeyExpansion);
					extr.pqaes_time_ciphering += (System.nanoTime()/1000);
					extr.pqaes_time_ciphering_cmpt += 1;
					
									
					file.append("Encrypted:"+pqaes.toHexString(pq_msg_pad_enc));
					file.append(Indicator.SEPARATOR);

					
					extr.pqaes_time_ciphering_inv -= (System.nanoTime()/1000);				    	
					byte [] pq_msg_pad_dec = pqaes.invCipher(pq_msg_pad_enc, pq_wordsKeyExpansion);
					extr.pqaes_time_ciphering_inv += (System.nanoTime()/1000);
					extr.pqaes_time_ciphering_inv_cmpt += 1;

					
					file.append("Decrypted:"+pqaes.toHexString(pq_msg_pad_dec));
					file.append(Indicator.SEPARATOR);
					
					
					switch(ind_pad) {
					case 0:
						extr.pqaes_time_padding_pkcs_inv -= (System.nanoTime()/1000);
					break;
					case 1:
						extr.pqaes_time_padding_ansi_9323_inv -= (System.nanoTime()/1000);
					break;
					case 2:
						extr.pqaes_time_padding_wc3_inv -= (System.nanoTime()/1000);
					break;
					case 3:
						extr.pqaes_time_padding_one_zero_inv -= (System.nanoTime()/1000);
					break;
					default :
					break;
				}
					
					byte[] pq_msg_pad_inv = pqaes.padding_all_inv(pq_msg_pad_dec, this.padd_method[ind_pad]);
					switch(ind_pad) {
					case 0:
						extr.pqaes_time_padding_pkcs_inv += (System.nanoTime()/1000);
						extr.pqaes_time_padding_pkcs_inv_cmpt+=1;
					break;
					case 1:
						extr.pqaes_time_padding_ansi_9323_inv += (System.nanoTime()/1000);
						extr.pqaes_time_padding_ansi_9323_inv_cmpt +=1;
					break;
					case 2:
						extr.pqaes_time_padding_wc3_inv += (System.nanoTime()/1000);
						extr.pqaes_time_padding_wc3_inv_cmpt +=1;
					break;
					case 3:
						extr.pqaes_time_padding_one_zero_inv += (System.nanoTime()/1000);
						extr.pqaes_time_padding_one_zero_inv_cmpt+=1;
					break;
					default :
					break;
				}
					
					
					
					file.append("PaddingInv_"+this.padd_method[ind_pad]+":"+pqaes.toHexString(pq_msg_pad_inv));
					file.append(Indicator.SEPARATOR);
					String rec = new String(pq_msg_pad_inv);
					file.append("Reconstruct_PlainText:"+rec);
					file.append(Indicator.SEPARATOR);

					
				}

				
			}
	    	
	        file.close();
	      }
	      catch(Exception e)
	      {
	        e.printStackTrace();
	      }
	      
	      
	      
	      
	      
	      
	      /**AES WITH THE SAME KEY */
	      try
	      {
	    	  /*AES*/
	    	 /*creating file inspired on : https://zetcode.com/java/createfile/#:~:text=The%20File%27s%20createNewFile%20method%20creates,name%20does%20not%20yet%20exist.&text=The%20createNewFile%20returns%20true%20if,the%20named%20file%20already%20exists.
	    	  * https://stackoverflow.com/questions/9620683/java-fileoutputstream-create-file-if-not-exists 
	    	  * */
	    	String status = "log_";
	    	String namefile = status+"AESWithSameKey_"+this.hash_function[h]+"_"+this.length_hash_function[l]+".txt";
	    	File yourFile = new File("src/"+namefile);
	    	yourFile.createNewFile(); 
	        
	    	file = new FileWriter("src/"+namefile);
			for(int indice_msg = 0; indice_msg < 4; indice_msg++) {
				if((h <= 3)&&(length_hash_function[l] >=1024)) {
					// without aes.setkey() for aes
					extr.aes_time_word_expansion -= (System.nanoTime()/1000);
					wordsKeyExpansion = aes.createKeyExpansion(bytesKey); //expandable 256bits
					extr.aes_time_word_expansion += (System.nanoTime()/1000);
					extr.aes_time_word_expansion_cmpt+=1;
					
					
				}else {
				
					// without aes.setkey() for aes
					extr.aes_time_word_expansion -= (System.nanoTime()/1000);
					wordsKeyExpansion = aes.createKeyExpansion(bytesKey); 
					extr.aes_time_word_expansion += (System.nanoTime()/1000);
					extr.aes_time_word_expansion_cmpt+=1;

					
				}
				
				file.append(Indicator.SEPARATOR);
				file.append(Indicator.SEPARATOR);
				
				String strMessage = msg[l][indice_msg];
				//System.out.println("Plain "+strMessage + "with "+l);
				file.append("plain_text:"+strMessage);
				file.append(Indicator.SEPARATOR);
				
				//CIPHERING MODE WITH PADDING
				byte [] bytesMessage = strMessage.getBytes();
				//if you want to see the byte message
				//System.out.println("bytesMessage :::"+bytesMessage.length+"this : "+strMessage);
				
				file.append("Encode_PlainText:"+aes.toHexString(bytesMessage));		
				file.append(Indicator.SEPARATOR);
				//PADDING METHODS
				int init_pad = -1;
				if(length_hash_function[l]<=2048) {
					init_pad = 0;
				}else {
					init_pad = 1; 
				}
				
				for(int ind_pad = init_pad; ind_pad < this.padd_method.length; ind_pad++) {
					
					switch(ind_pad) {
						case 0:
							extr.aes_time_padding_pkcs -= (System.nanoTime()/1000);
						break;
						case 1:
							extr.aes_time_padding_ansi_9323 -= (System.nanoTime()/1000);
						break;
						case 2:
							extr.aes_time_padding_wc3 -= (System.nanoTime()/1000);
						break;
						case 3:
							extr.aes_time_padding_one_zero -= (System.nanoTime()/1000);
						break;
						default :
						break;
					}
					
					byte [] msg_pad = aes.padding_all(bytesMessage, this.padd_method[ind_pad]);
					switch(ind_pad) {
					case 0:
						extr.aes_time_padding_pkcs += (System.nanoTime()/1000);
						extr.aes_time_padding_pkcs_cmpt+=1;
					break;
					case 1:
						extr.aes_time_padding_ansi_9323 += (System.nanoTime()/1000);
						extr.aes_time_padding_ansi_9323_cmpt +=1;
					break;
					case 2:
						extr.aes_time_padding_wc3 += (System.nanoTime()/1000);
						extr.aes_time_padding_wc3_cmpt +=1;
					break;
					case 3:
						extr.aes_time_padding_one_zero += (System.nanoTime()/1000);
						extr.aes_time_padding_one_zero_cmpt+=1;
					break;
					default :
					break;
				}
										
					file.append("Padding_"+this.padd_method[ind_pad]+":"+aes.toHexString(msg_pad));
					file.append(Indicator.SEPARATOR);
					
					
					

					
					extr.aes_time_ciphering -= (System.nanoTime()/1000);
					byte [] msg_pad_enc = aes.cipher(msg_pad, wordsKeyExpansion);
					extr.aes_time_ciphering += (System.nanoTime()/1000);
					extr.aes_time_ciphering_cmpt += 1;
					
									
					file.append("Encrypted:"+aes.toHexString(msg_pad_enc));
					file.append(Indicator.SEPARATOR);

					
					extr.aes_time_ciphering_inv -= (System.nanoTime()/1000);				    	
					byte [] msg_pad_dec = aes.invCipher(msg_pad_enc, wordsKeyExpansion);
					extr.aes_time_ciphering_inv += (System.nanoTime()/1000);
					extr.aes_time_ciphering_inv_cmpt += 1;

					
					file.append("Decrypted:"+aes.toHexString(msg_pad_dec));
					file.append(Indicator.SEPARATOR);
					
					
					switch(ind_pad) {
					case 0:
						extr.aes_time_padding_pkcs_inv -= (System.nanoTime()/1000);
					break;
					case 1:
						extr.aes_time_padding_ansi_9323_inv -= (System.nanoTime()/1000);
					break;
					case 2:
						extr.aes_time_padding_wc3_inv -= (System.nanoTime()/1000);
					break;
					case 3:
						extr.aes_time_padding_one_zero_inv -= (System.nanoTime()/1000);
					break;
					default :
					break;
				}
					
					byte[] msg_pad_inv = aes.padding_all_inv(msg_pad_dec, this.padd_method[ind_pad]);
					switch(ind_pad) {
					case 0:
						extr.aes_time_padding_pkcs_inv += (System.nanoTime()/1000);
						extr.aes_time_padding_pkcs_inv_cmpt+=1;
					break;
					case 1:
						extr.aes_time_padding_ansi_9323_inv += (System.nanoTime()/1000);
						extr.aes_time_padding_ansi_9323_inv_cmpt +=1;
					break;
					case 2:
						extr.aes_time_padding_wc3_inv += (System.nanoTime()/1000);
						extr.aes_time_padding_wc3_inv_cmpt +=1;
					break;
					case 3:
						extr.aes_time_padding_one_zero_inv += (System.nanoTime()/1000);
						extr.aes_time_padding_one_zero_inv_cmpt+=1;
					break;
					default :
					break;
				}
					
					
					
					file.append("PaddingInv_"+this.padd_method[ind_pad]+":"+aes.toHexString(msg_pad_inv));
					file.append(Indicator.SEPARATOR);
					String rec = new String(msg_pad_inv);
					file.append("Reconstruct_PlainText:"+rec);
					file.append(Indicator.SEPARATOR);

					
				}

				
			}
	    	
	        file.close();
	      }
	      catch(Exception e)
	      {
	        e.printStackTrace();
	      }
	      
	  	return extr;

	}


	
}
