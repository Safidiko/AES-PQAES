package main_pkg;
/*code by sitraka 09/01/2023*/

public class Main_Article2 {

	public static void main(String[] args) {
		// TODO Auto-generated method stub
		AES aes = new AES(AES.KEY_SIZE_256);
		String strMessage="this is a test!!";
		byte[] bytesKey = aes.createKey();
		System.out.println("key :"+aes.toHexString(bytesKey));

		System.out.println("bytes key length "+bytesKey.length);
		int[] wordsKeyExpansion = aes.createKeyExpansion(bytesKey);
		byte[] bytesMessage = strMessage.getBytes();
		aes.printByte(bytesMessage, "Message");
		byte [] msg_pad = aes.padding_onezero(bytesMessage);
		aes.printByte(msg_pad, "Message pad");
		
		//  ciphering 
		byte [] msg_pad_enc = aes.cipher(msg_pad, wordsKeyExpansion);
		System.out.println("msg enc :"+aes.toHexString(msg_pad_enc));
		
		//deciphering 
		byte [] msg_pad_dec = aes.invCipher(msg_pad_enc, wordsKeyExpansion);
		System.out.println("msg dec :"+aes.toHexString(msg_pad_dec));
		
		
		byte[] msg_pad_inv = aes.padding_onezero_inv(msg_pad_dec);
		
		aes.printByte(msg_pad_inv, "Message pad INV");
		System.out.println(new String(msg_pad_inv));


	// TESTING PQ_AES : 
		PQ_AES pqaes = new PQ_AES(PQ_AES.KEY_SIZE_4096);
		String pq_strMessage="this is a test!!";
		byte[] pq_bytesKey = pqaes.createKey();
		System.out.println("key :"+pqaes.toHexString(pq_bytesKey));
		
		pqaes.setkey(pq_bytesKey); // change between aes and pqaes
		long start_time = System.nanoTime()/1000;
		int[] pq_wordsKeyExpansion = pqaes.createKeyExpansion("sha", 256); //changement
		long stop_time = System.nanoTime()/1000;
		System.out.println("time : "+(stop_time-start_time));
		byte[] pq_bytesMessage = pq_strMessage.getBytes();
		aes.printByte(pq_bytesMessage, "PQ Message");
		byte [] pq_msg_pad = pqaes.padding_onezero(pq_bytesMessage);
		aes.printByte(pq_msg_pad, "PQ Message pad");
		
		//ciphering 
		byte [] pq_msg_pad_enc = pqaes.cipher(pq_msg_pad, pq_wordsKeyExpansion);
		System.out.println("PQ msg enc :"+pqaes.toHexString(pq_msg_pad_enc));
		
		//deciphering
		byte [] pq_msg_pad_dec = pqaes.invCipher(pq_msg_pad_enc, pq_wordsKeyExpansion);
		System.out.println("PQ msg dec :"+pqaes.toHexString(pq_msg_pad_dec));
		
		
		byte[] pq_msg_pad_inv = pqaes.padding_onezero_inv(pq_msg_pad_dec);
		
		aes.printByte(pq_msg_pad_inv, "Message pad INV");
		System.out.println(new String(pq_msg_pad_inv));




	}

}
