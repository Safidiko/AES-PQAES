package main_pkg;
/*code by sitraka 09/01/2023*/

public class Main_Safidy {

	public static void main(String[] args) {
		
		
		System.out.println("Hello!");
//
//		
//		byte b = (byte) 255;
//		System.out.println("byte to int"+b);
//		
//		// enregistrement csv  : entr�e : byte___ sortie : int
//		int test = Byte.toUnsignedInt(b);
//		System.out.println("byte to int"+test);
//		
//		
//		
//		
//		// TODO Auto-generated method stub
//		AES aes = new AES(AES.KEY_SIZE_512);
//		String strMessage="Hallo Leute! Es ist der F�hrer!";
//		byte[] bytesKey = aes.createKey();
//		System.out.println("key :"+aes.toHexString(bytesKey));
//
//		System.out.println("bytes key length "+bytesKey.length);
//		int[] wordsKeyExpansion = aes.createKeyExpansion(bytesKey);
//		byte[] bytesMessage = strMessage.getBytes();
//		aes.printByte(bytesMessage, "Message");
//		
//		//  ciphering 
//		byte [] msg_enc = aes.cipher(bytesMessage, wordsKeyExpansion);
//		System.out.println("msg enc :"+aes.toHexString(msg_enc));
//		System.out.println("byte msg enc :");
//		
//		aes.printByte(msg_enc);
//
//		
//
//		//deciphering 
//		byte [] msg_dec = aes.invCipher(msg_enc, wordsKeyExpansion);
//		System.out.println("msg dec :"+aes.toHexString(msg_dec));
//		
//		System.out.println("string deciphering :");
//		System.out.println(new String(msg_dec));
//
//		
//
//	// TESTING PQ_AES : 
//		PQ_AES pqaes = new PQ_AES(PQ_AES.KEY_SIZE_4096);
//		String pq_strMessage="this is a test!!";
//		byte[] pq_bytesKey = pqaes.createKey();
//		System.out.println("key :"+pqaes.toHexString(pq_bytesKey));
//		
//		pqaes.setkey(pq_bytesKey); // change between aes and pqaes
//		//pqaes.set_info("sha");
//		//pqaes.set_info("sha3");
//		//pqaes.set_info("keccak");
//		//pqaes.set_info("shake");		
//		
//		int[] pq_wordsKeyExpansion = pqaes.createKeyExpansion("sha", 256); //changement
//		
//		byte[] pq_bytesMessage = pq_strMessage.getBytes();
//		aes.printByte(pq_bytesMessage, "PQ Message");
//		
//	   
//		
//		//ciphering 
//		byte [] pq_msg_enc = pqaes.cipher(pq_bytesMessage, pq_wordsKeyExpansion);
//		System.out.println("PQ msg enc :"+pqaes.toHexString(pq_msg_enc));
//		
//		//deciphering
//		byte [] pq_msg_dec = pqaes.invCipher(pq_msg_enc, pq_wordsKeyExpansion);
//		System.out.println("PQ msg dec :"+pqaes.toHexString(pq_msg_dec));
//		
//		
//		aes.printByte(pq_msg_dec, "Message dec");
//		System.out.println(new String(pq_msg_dec));


	}

}
