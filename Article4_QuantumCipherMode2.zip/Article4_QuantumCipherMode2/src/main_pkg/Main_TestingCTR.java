package main_pkg;

public class Main_TestingCTR {

	public static void main(String[] args) {
		// TODO Auto-generated method stub
		byte[] cmpt = new byte[1];
		cmpt[0] = 0;
		for(int i = 0; i<1000; i++) {
			System.out.print("count:");
			for(int j = 0; j < cmpt.length; j++) {
				System.out.print(" "+cmpt[j]);
			}
			System.out.println("");
			cmpt = bytes_arrays_addOne(cmpt);
		}

		
/*		byte[] cmpt = new byte[4];
		for(int i =0; i< cmpt.length; i++) {
			cmpt[i] = 0;
		}
		for(int i = 0; i<1000; i++) {
			System.out.print("count:");
			for(int j = 0; j < cmpt.length; j++) {
				System.out.print(" "+cmpt[j]);
			}
			System.out.println("");
			cmpt = bytes_arrays_fixedLength_addOne(cmpt);

		}
	*/	
			
			
	}

	
	public static byte [] bytes_arrays_addOne(byte []input){
		byte ret = 1;
		byte []output = new byte[input.length];
		for(int i=input.length-1; i >=0; i--) {
			output[i] = (byte) (input[i]+(byte) ret);
			if(output[i] == 0) {
				ret = 1;
			}else {
				ret = 0;
			}
		}
		if(ret == 1) {
			byte[] output2 = new byte[input.length+1];
			output2[0] = 1;
			for(int i = 0; i < output.length; i++) {
				output2[i+1] = output[i];
			}
			return output2;
		}
		return output;
	}

	public static byte [] bytes_arrays_fixedLength_addOne(byte []input){
		byte ret = 1;
		byte []output = new byte[input.length];
		for(int i=input.length-1; i >=0; i--) {
			output[i] = (byte) (input[i]+(byte) ret);
			if((output[i] == 0)&&(ret == 1)){
				ret = 1;
			}else {
				ret = 0;
			}
		}
		return output;
	}

	
	
}
