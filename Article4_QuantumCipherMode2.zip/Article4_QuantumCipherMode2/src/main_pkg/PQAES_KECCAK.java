package main_pkg;

public class PQAES_KECCAK implements PostQuantique {
	/**
	 * 
	 */
	private PQ_AES paes_keccak; 
	public PQAES_KECCAK(int blockLength) {
		paes_keccak = new PQ_AES(blockLength);
		paes_keccak.set_info("keccak");
	}
	public byte[] createKey() {
		return paes_keccak.createKey();	
	}
	public void setkey(byte [] key) {
		paes_keccak.setkey(key);
	}
	public int[] createKeyExpansion(int length_hash) {
		return paes_keccak.createKeyExpansion("keccak", length_hash);
	}
	public byte[][] cipher(byte[][] image,int[]wordsKeyExpansion) {
		
		byte[][] imageEncrypted = new byte[image.length][];
		int i = 0;
		for(byte [] tmp:image) {
			byte[] tmpEncrypted = paes_keccak.cipher(tmp, wordsKeyExpansion);
			imageEncrypted[i] = tmpEncrypted;
			i++;
		}
		
		return imageEncrypted; 
	}
	public byte[][] invCipher(byte[][] imageEncrypted,int[] wordsKeyExpansion) {
		
		byte[][] image = new byte[imageEncrypted.length][];
		int i = 0;
		for(byte [] tmpEncrypted:imageEncrypted) {
			byte[] tmp = paes_keccak.invCipher(tmpEncrypted, wordsKeyExpansion);
			image[i] = tmp;
			i++;
		}
		return image;
	}
	public static void main(String[] args) {
		byte[][] image =new byte[][] {
			{1,2,3},
			{4,5,6},
			{7,8,9}
		};
		PQAES_KECCAK paes_keccak = new PQAES_KECCAK(PQ_AES.KEY_SIZE_256);
		byte[] cle = paes_keccak.createKey();
		paes_keccak.setkey(cle);
		int[] keyExpansion = paes_keccak.createKeyExpansion(PQ_AES.KEY_SIZE_256);
		byte[][] imageCiphered = paes_keccak.cipher(image, keyExpansion);
		byte[][] imageDeciphered =paes_keccak.invCipher(imageCiphered, keyExpansion);
		System.out.println("image ciphered");
		ReadCSV.displayMatrice(image);
		System.out.println("");
		
		System.out.println("image ciphered");
		ReadCSV.displayMatrice(imageCiphered);
		
		System.out.println("");
		System.out.println("image reconstructed");
		ReadCSV.displayMatrice(imageDeciphered);
}
}

