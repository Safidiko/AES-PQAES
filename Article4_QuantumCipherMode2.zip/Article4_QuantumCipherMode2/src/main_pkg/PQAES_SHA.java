package main_pkg;

public class PQAES_SHA implements PostQuantique {
	/**
	 * 
	 */
	private PQ_AES paes_sha; 
	public PQAES_SHA(int blockLength) {
		paes_sha = new PQ_AES(blockLength);
		paes_sha.set_info("sha");
	}
	public byte[] createKey() {
		return paes_sha.createKey();	
	}
	public void setkey(byte [] key) {
		paes_sha.setkey(key);
	}
	public int[] createKeyExpansion(int length_hash) {
		return paes_sha.createKeyExpansion("sha", length_hash);
	}
	public byte[][] cipher(byte[][] image,int[]wordsKeyExpansion) {
		
		byte[][] imageEncrypted = new byte[image.length][];
		int i = 0;
		for(byte [] tmp:image) {
			byte[] tmpEncrypted = paes_sha.cipher(tmp, wordsKeyExpansion);
			imageEncrypted[i] = tmpEncrypted;
			i++;
		}
		
		return imageEncrypted;
	}
	public byte[][] invCipher(byte[][] imageEncrypted,int[] wordsKeyExpansion) {
		
		byte[][] image = new byte[imageEncrypted.length][];
		int i = 0;
		for(byte [] tmpEncrypted:imageEncrypted) {
			byte[] tmp = paes_sha.invCipher(tmpEncrypted, wordsKeyExpansion);
			image[i] = tmp;
			i++;
		}
		return image;
	}
	public static void main(String[] args) {
		byte[][] image =new byte[][] {
			{1,2,3},
			{4,5,6},
			{7,8,9}
		};
		PQAES_SHA aes = new PQAES_SHA(PQ_AES.KEY_SIZE_256);
		byte[] cle = aes.createKey();
		aes.setkey(cle);
		int[] keyExpansion = aes.createKeyExpansion(PQ_AES.KEY_SIZE_256);
		byte[][] imageCiphered = aes.cipher(image, keyExpansion);
		byte[][] imageDeciphered =aes.invCipher(imageCiphered, keyExpansion);
		System.out.println("image ciphered");
		ReadCSV.displayMatrice(image);
		System.out.println("");
		
		System.out.println("image ciphered");
		ReadCSV.displayMatrice(imageCiphered);
		
		System.out.println("");
		System.out.println("image reconstructed");
		ReadCSV.displayMatrice(imageDeciphered);
}
}