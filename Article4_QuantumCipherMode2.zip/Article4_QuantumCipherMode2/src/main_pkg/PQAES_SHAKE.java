package main_pkg;

public class PQAES_SHAKE implements PostQuantique {
	private PQ_AES paes_shake; 
	public PQAES_SHAKE(int blockLength) {
		paes_shake = new PQ_AES(blockLength);
		paes_shake.set_info("shake");
	}
	public byte[] createKey() {
		return paes_shake.createKey();	
	}
	public void setkey(byte [] key) {
		paes_shake.setkey(key);
	}
	public int[] createKeyExpansion(int length_hash) {
		return paes_shake.createKeyExpansion("shake", length_hash);
	}
	public byte[][] cipher(byte[][] image,int[]wordsKeyExpansion) {
		
		byte[][] imageEncrypted = new byte[image.length][];
		int i = 0;
		for(byte [] tmp:image) {
			byte[] tmpEncrypted = paes_shake.cipher(tmp, wordsKeyExpansion);
			imageEncrypted[i] = tmpEncrypted;
			i++;
		}
		
		return imageEncrypted; 
	}
	public byte[][] invCipher(byte[][] imageEncrypted,int[] wordsKeyExpansion) {
		
		byte[][] image = new byte[imageEncrypted.length][];
		int i = 0;
		for(byte [] tmpEncrypted:imageEncrypted) {
			byte[] tmp = paes_shake.invCipher(tmpEncrypted, wordsKeyExpansion);
			image[i] = tmp;
			i++;
		}
		return image;
	}
	public static void main(String[] args) {
		byte[][] image =new byte[][] {
			{1,2,3},
			{4,5,6},
			{7,8,9}
		};
		PQAES_SHAKE paes_shake = new PQAES_SHAKE(PQ_AES.KEY_SIZE_256);
		byte[] cle = paes_shake.createKey();
		paes_shake.setkey(cle);
		int[] keyExpansion = paes_shake.createKeyExpansion(PQ_AES.KEY_SIZE_256);
		byte[][] imageCiphered = paes_shake.cipher(image, keyExpansion);
		byte[][] imageDeciphered =paes_shake.invCipher(imageCiphered, keyExpansion);
		System.out.println("image ciphered");
		ReadCSV.displayMatrice(image);
		System.out.println("");
		
		System.out.println("image ciphered");
		ReadCSV.displayMatrice(imageCiphered);
		
		System.out.println("");
		System.out.println("image reconstructed");
		ReadCSV.displayMatrice(imageDeciphered);
}
}