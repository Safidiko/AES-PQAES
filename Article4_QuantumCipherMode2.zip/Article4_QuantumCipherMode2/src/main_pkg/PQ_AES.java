package main_pkg;


import java.io.File;
import java.io.FileInputStream;
import java.io.FileOutputStream;
import java.io.IOException;
import java.io.UnsupportedEncodingException;
import java.nio.ByteBuffer;
import java.util.ArrayList;
import java.util.Arrays;
import java.util.BitSet;
import java.util.Iterator;
import java.util.List;
import java.util.Random;

import main_pkg.AES.AESBlocks;

/*code by sitraka 09/01/2023*/

public class PQ_AES {
	HKDF hkdf;
	byte key[];
    public static final int LENGTH_EXPANSION_128 = 44*32;
    public static final int LENGTH_EXPANSION_256 = 60*32;
    public static final int LENGTH_EXPANSION_512 = 92*32;  //  ((Nr+1)*Nb*8*4)/32 = (Nr+1)*Nb
    public static final int LENGTH_EXPANSION_1024 = 156*32;
    public static final int LENGTH_EXPANSION_2048 = 284*32;
    public static final int LENGTH_EXPANSION_4096 = 540*32;
    
    
    public static final int KEY_SIZE_128 = 128;
    public static final int KEY_SIZE_192 = 192;
    public static final int KEY_SIZE_256 = 256;
    public static final int KEY_SIZE_512 = 512;
    public static final int KEY_SIZE_1024 = 1024;
    public static final int KEY_SIZE_2048 = 2048;
    public static final int KEY_SIZE_4096 = 4096;
    public static final int NB_VALUE = 4;
    
    private static String DEFAULT_CHARSET = "UTF-8";

    private static int m_version = 1;


    int length_pqaes = -1;
    
    
    // AES-128 Nk=4, Nb=4, Nr=10
    // AES-192 Nk=6, Nb=4, Nr=12
    // AES-256 Nk=8, Nb=4, Nr=14
    protected int Nk = 4;
    protected int Nb = NB_VALUE;
    protected int Nr = 10;
    public int getNk() {
        return Nk;
    }

    public int getNb() {
        return Nb;
    }

    public int getNr() {
        return Nr;
    }

    
    
    /*FINITE MULTIPLICATION */
    // get ith bit of value, 0 <= i <= 7
    // for value = B7B6B5B4B3B2B1B0
    private static byte getBit(byte value, int i) {
        final byte bMasks[] = {(byte) 0x01, (byte) 0x02, (byte) 0x04,
                              (byte) 0x08, (byte) 0x10, (byte) 0x20,
                              (byte) 0x40, (byte) 0x80};
        byte bBit = (byte) (value & bMasks[i]);
        return (byte) ((byte) (bBit >> i) & (byte) 0x01);
    }

    private static byte xtime(byte value) {
        int iResult = 0;
        iResult = (int) (value & 0x000000ff) * 02;
        return (byte) (((iResult & 0x100) != 0) ? iResult ^ 0x11b : iResult);
    }

    private static byte finiteMultiplication(int v1, int v2) {
        return finiteMultiplication((byte) v1, (byte) v2);
    }

    private static byte finiteMultiplication(byte v1, byte v2) {
        byte bTemps[] = new byte[8];
        byte bResult = 0;
        bTemps[0] = v1;
        for (int i = 1; i < bTemps.length; i++) {
            bTemps[i] = xtime(bTemps[i - 1]);
        }
        for (int i = 0; i < bTemps.length; i++) {
            if (getBit(v2, i) != 1) {
                bTemps[i] = 0;
            }
            bResult ^= bTemps[i];
        }
        return bResult;
    }
    
    /*END FINITE MULTIPLICATION*/
    //public String strTrace = new String();

    protected static final byte[][] sbox = { {(byte) 0x63, (byte) 0x7c,
            (byte) 0x77, (byte) 0x7b, (byte) 0xf2, (byte) 0x6b, (byte) 0x6f,
            (byte) 0xc5, (byte) 0x30, (byte) 0x01, (byte) 0x67, (byte) 0x2b,
            (byte) 0xfe, (byte) 0xd7, (byte) 0xab, (byte) 0x76}, {(byte) 0xca,
            (byte) 0x82, (byte) 0xc9, (byte) 0x7d, (byte) 0xfa, (byte) 0x59,
            (byte) 0x47, (byte) 0xf0, (byte) 0xad, (byte) 0xd4, (byte) 0xa2,
            (byte) 0xaf, (byte) 0x9c, (byte) 0xa4, (byte) 0x72, (byte) 0xc0},
            {(byte) 0xb7, (byte) 0xfd, (byte) 0x93, (byte) 0x26, (byte) 0x36,
            (byte) 0x3f, (byte) 0xf7, (byte) 0xcc, (byte) 0x34, (byte) 0xa5,
            (byte) 0xe5, (byte) 0xf1, (byte) 0x71, (byte) 0xd8, (byte) 0x31,
            (byte) 0x15}, {(byte) 0x04, (byte) 0xc7, (byte) 0x23, (byte) 0xc3,
            (byte) 0x18, (byte) 0x96, (byte) 0x05, (byte) 0x9a, (byte) 0x07,
            (byte) 0x12, (byte) 0x80, (byte) 0xe2, (byte) 0xeb, (byte) 0x27,
            (byte) 0xb2, (byte) 0x75}, {(byte) 0x09, (byte) 0x83, (byte) 0x2c,
            (byte) 0x1a, (byte) 0x1b, (byte) 0x6e, (byte) 0x5a, (byte) 0xa0,
            (byte) 0x52, (byte) 0x3b, (byte) 0xd6, (byte) 0xb3, (byte) 0x29,
            (byte) 0xe3, (byte) 0x2f, (byte) 0x84}, {(byte) 0x53, (byte) 0xd1,
            (byte) 0x00, (byte) 0xed, (byte) 0x20, (byte) 0xfc, (byte) 0xb1,
            (byte) 0x5b, (byte) 0x6a, (byte) 0xcb, (byte) 0xbe, (byte) 0x39,
            (byte) 0x4a, (byte) 0x4c, (byte) 0x58, (byte) 0xcf}, {(byte) 0xd0,
            (byte) 0xef, (byte) 0xaa, (byte) 0xfb, (byte) 0x43, (byte) 0x4d,
            (byte) 0x33, (byte) 0x85, (byte) 0x45, (byte) 0xf9, (byte) 0x02,
            (byte) 0x7f, (byte) 0x50, (byte) 0x3c, (byte) 0x9f, (byte) 0xa8},
            {(byte) 0x51, (byte) 0xa3, (byte) 0x40, (byte) 0x8f, (byte) 0x92,
            (byte) 0x9d, (byte) 0x38, (byte) 0xf5, (byte) 0xbc, (byte) 0xb6,
            (byte) 0xda, (byte) 0x21, (byte) 0x10, (byte) 0xff, (byte) 0xf3,
            (byte) 0xd2}, {(byte) 0xcd, (byte) 0x0c, (byte) 0x13, (byte) 0xec,
            (byte) 0x5f, (byte) 0x97, (byte) 0x44, (byte) 0x17, (byte) 0xc4,
            (byte) 0xa7, (byte) 0x7e, (byte) 0x3d, (byte) 0x64, (byte) 0x5d,
            (byte) 0x19, (byte) 0x73}, {(byte) 0x60, (byte) 0x81, (byte) 0x4f,
            (byte) 0xdc, (byte) 0x22, (byte) 0x2a, (byte) 0x90, (byte) 0x88,
            (byte) 0x46, (byte) 0xee, (byte) 0xb8, (byte) 0x14, (byte) 0xde,
            (byte) 0x5e, (byte) 0x0b, (byte) 0xdb}, {(byte) 0xe0, (byte) 0x32,
            (byte) 0x3a, (byte) 0x0a, (byte) 0x49, (byte) 0x06, (byte) 0x24,
            (byte) 0x5c, (byte) 0xc2, (byte) 0xd3, (byte) 0xac, (byte) 0x62,
            (byte) 0x91, (byte) 0x95, (byte) 0xe4, (byte) 0x79}, {(byte) 0xe7,
            (byte) 0xc8, (byte) 0x37, (byte) 0x6d, (byte) 0x8d, (byte) 0xd5,
            (byte) 0x4e, (byte) 0xa9, (byte) 0x6c, (byte) 0x56, (byte) 0xf4,
            (byte) 0xea, (byte) 0x65, (byte) 0x7a, (byte) 0xae, (byte) 0x08},
            {(byte) 0xba, (byte) 0x78, (byte) 0x25, (byte) 0x2e, (byte) 0x1c,
            (byte) 0xa6, (byte) 0xb4, (byte) 0xc6, (byte) 0xe8, (byte) 0xdd,
            (byte) 0x74, (byte) 0x1f, (byte) 0x4b, (byte) 0xbd, (byte) 0x8b,
            (byte) 0x8a}, {(byte) 0x70, (byte) 0x3e, (byte) 0xb5, (byte) 0x66,
            (byte) 0x48, (byte) 0x03, (byte) 0xf6, (byte) 0x0e, (byte) 0x61,
            (byte) 0x35, (byte) 0x57, (byte) 0xb9, (byte) 0x86, (byte) 0xc1,
            (byte) 0x1d, (byte) 0x9e}, {(byte) 0xe1, (byte) 0xf8, (byte) 0x98,
            (byte) 0x11, (byte) 0x69, (byte) 0xd9, (byte) 0x8e, (byte) 0x94,
            (byte) 0x9b, (byte) 0x1e, (byte) 0x87, (byte) 0xe9, (byte) 0xce,
            (byte) 0x55, (byte) 0x28, (byte) 0xdf}, {(byte) 0x8c, (byte) 0xa1,
            (byte) 0x89, (byte) 0x0d, (byte) 0xbf, (byte) 0xe6, (byte) 0x42,
            (byte) 0x68, (byte) 0x41, (byte) 0x99, (byte) 0x2d, (byte) 0x0f,
            (byte) 0xb0, (byte) 0x54, (byte) 0xbb, (byte) 0x16}
    };
    protected static final byte[][] sboxInv = { {(byte) 0x52, (byte) 0x09,
            (byte) 0x6a, (byte) 0xd5, (byte) 0x30, (byte) 0x36, (byte) 0xa5,
            (byte) 0x38, (byte) 0xbf, (byte) 0x40, (byte) 0xa3, (byte) 0x9e,
            (byte) 0x81, (byte) 0xf3, (byte) 0xd7, (byte) 0xfb}, {(byte) 0x7c,
            (byte) 0xe3, (byte) 0x39, (byte) 0x82, (byte) 0x9b, (byte) 0x2f,
            (byte) 0xff, (byte) 0x87, (byte) 0x34, (byte) 0x8e, (byte) 0x43,
            (byte) 0x44, (byte) 0xc4, (byte) 0xde, (byte) 0xe9, (byte) 0xcb},
            {(byte) 0x54, (byte) 0x7b, (byte) 0x94, (byte) 0x32, (byte) 0xa6,
            (byte) 0xc2, (byte) 0x23, (byte) 0x3d, (byte) 0xee, (byte) 0x4c,
            (byte) 0x95, (byte) 0x0b, (byte) 0x42, (byte) 0xfa, (byte) 0xc3,
            (byte) 0x4e}, {(byte) 0x08, (byte) 0x2e, (byte) 0xa1, (byte) 0x66,
            (byte) 0x28, (byte) 0xd9, (byte) 0x24, (byte) 0xb2, (byte) 0x76,
            (byte) 0x5b, (byte) 0xa2, (byte) 0x49, (byte) 0x6d, (byte) 0x8b,
            (byte) 0xd1, (byte) 0x25}, {(byte) 0x72, (byte) 0xf8, (byte) 0xf6,
            (byte) 0x64, (byte) 0x86, (byte) 0x68, (byte) 0x98, (byte) 0x16,
            (byte) 0xd4, (byte) 0xa4, (byte) 0x5c, (byte) 0xcc, (byte) 0x5d,
            (byte) 0x65, (byte) 0xb6, (byte) 0x92}, {(byte) 0x6c, (byte) 0x70,
            (byte) 0x48, (byte) 0x50, (byte) 0xfd, (byte) 0xed, (byte) 0xb9,
            (byte) 0xda, (byte) 0x5e, (byte) 0x15, (byte) 0x46, (byte) 0x57,
            (byte) 0xa7, (byte) 0x8d, (byte) 0x9d, (byte) 0x84}, {(byte) 0x90,
            (byte) 0xd8, (byte) 0xab, (byte) 0x00, (byte) 0x8c, (byte) 0xbc,
            (byte) 0xd3, (byte) 0x0a, (byte) 0xf7, (byte) 0xe4, (byte) 0x58,
            (byte) 0x05, (byte) 0xb8, (byte) 0xb3, (byte) 0x45, (byte) 0x06},
            {(byte) 0xd0, (byte) 0x2c, (byte) 0x1e, (byte) 0x8f, (byte) 0xca,
            (byte) 0x3f, (byte) 0x0f, (byte) 0x02, (byte) 0xc1, (byte) 0xaf,
            (byte) 0xbd, (byte) 0x03, (byte) 0x01, (byte) 0x13, (byte) 0x8a,
            (byte) 0x6b}, {(byte) 0x3a, (byte) 0x91, (byte) 0x11, (byte) 0x41,
            (byte) 0x4f, (byte) 0x67, (byte) 0xdc, (byte) 0xea, (byte) 0x97,
            (byte) 0xf2, (byte) 0xcf, (byte) 0xce, (byte) 0xf0, (byte) 0xb4,
            (byte) 0xe6, (byte) 0x73}, {(byte) 0x96, (byte) 0xac, (byte) 0x74,
            (byte) 0x22, (byte) 0xe7, (byte) 0xad, (byte) 0x35, (byte) 0x85,
            (byte) 0xe2, (byte) 0xf9, (byte) 0x37, (byte) 0xe8, (byte) 0x1c,
            (byte) 0x75, (byte) 0xdf, (byte) 0x6e}, {(byte) 0x47, (byte) 0xf1,
            (byte) 0x1a, (byte) 0x71, (byte) 0x1d, (byte) 0x29, (byte) 0xc5,
            (byte) 0x89, (byte) 0x6f, (byte) 0xb7, (byte) 0x62, (byte) 0x0e,
            (byte) 0xaa, (byte) 0x18, (byte) 0xbe, (byte) 0x1b}, {(byte) 0xfc,
            (byte) 0x56, (byte) 0x3e, (byte) 0x4b, (byte) 0xc6, (byte) 0xd2,
            (byte) 0x79, (byte) 0x20, (byte) 0x9a, (byte) 0xdb, (byte) 0xc0,
            (byte) 0xfe, (byte) 0x78, (byte) 0xcd, (byte) 0x5a, (byte) 0xf4},
            {(byte) 0x1f, (byte) 0xdd, (byte) 0xa8, (byte) 0x33, (byte) 0x88,
            (byte) 0x07, (byte) 0xc7, (byte) 0x31, (byte) 0xb1, (byte) 0x12,
            (byte) 0x10, (byte) 0x59, (byte) 0x27, (byte) 0x80, (byte) 0xec,
            (byte) 0x5f}, {(byte) 0x60, (byte) 0x51, (byte) 0x7f, (byte) 0xa9,
            (byte) 0x19, (byte) 0xb5, (byte) 0x4a, (byte) 0x0d, (byte) 0x2d,
            (byte) 0xe5, (byte) 0x7a, (byte) 0x9f, (byte) 0x93, (byte) 0xc9,
            (byte) 0x9c, (byte) 0xef}, {(byte) 0xa0, (byte) 0xe0, (byte) 0x3b,
            (byte) 0x4d, (byte) 0xae, (byte) 0x2a, (byte) 0xf5, (byte) 0xb0,
            (byte) 0xc8, (byte) 0xeb, (byte) 0xbb, (byte) 0x3c, (byte) 0x83,
            (byte) 0x53, (byte) 0x99, (byte) 0x61}, {(byte) 0x17, (byte) 0x2b,
            (byte) 0x04, (byte) 0x7e, (byte) 0xba, (byte) 0x77, (byte) 0xd6,
            (byte) 0x26, (byte) 0xe1, (byte) 0x69, (byte) 0x14, (byte) 0x63,
            (byte) 0x55, (byte) 0x21, (byte) 0x0c, (byte) 0x7d}
    };
    protected static final int Rcon[] = {0x01000000,
                                        0x01000000, 0x02000000, 0x04000000,
                                        0x08000000,
                                        0x10000000, 0x20000000, 0x40000000,
                                        0x80000000,
                                        0x1b000000, 0x36000000, 0x6c000000};

    /*inspired at : https://www.geeksforgeeks.org/java-program-to-convert-hex-string-to-byte-array/*/
    public byte[] toStringHex(String key) {
    	 int len = key.length();
         byte[] ans = new byte[len / 2];
        
         for (int i = 0; i < len; i += 2) {
              // using left shift operator on every character
             ans[i / 2] = (byte) ((Character.digit(key.charAt(i), 16) << 4)
                     + Character.digit(key.charAt(i+1), 16));
         }
         
         /*System.out.print("Byte Array : ");
           
         for(int i=0;i<ans.length;i++){
             System.out.print(ans[i]+" ");
         }
         System.out.println("");
         */
         
         return ans;
    	
    }
    

	/*inspired on java code stackoverflow*/
	   public String toHexString2(byte[] bytes) {
	        char[] hexArray = "0123456789ABCDEF".toCharArray();
	        char[] hexChars = new char[bytes.length * 2];
	        for (int j = 0; j < bytes.length; j++) {
	            int v = bytes[j] & 0xFF;
	            hexChars[j * 2] = hexArray[v >>> 4];
	            hexChars[j * 2 + 1] = hexArray[v & 0x0F];
	        }
	        return new String(hexChars);
	    }
	    
	    
	    public String toHexString(byte[] byteArray)
	    {
	        String hex = "";
	  
	        // Iterating through each byte in the array
	        for (byte i : byteArray) {
	            hex += String.format("%02X", i);
	        }
	  
	        //System.out.print(hex);
	        return hex;
	    }


	public PQ_AES(int length_pqaes) {
		// TODO Auto-generated constructor stub
		this.length_pqaes = length_pqaes;
        switch (length_pqaes) {
        case KEY_SIZE_128:
            Nk = 4;
            Nb = 4;
            Nr = 10;
            break;
        case KEY_SIZE_192:
            Nk = 6;
            Nb = 4;
            Nr = 12;
            break;
        case KEY_SIZE_256:
            Nk = 8;
            Nb = 4;
            Nr = 14;
            break;
        case KEY_SIZE_512:
            Nk = 16;
            Nb = 4;
            Nr = 22;
            break;
        case KEY_SIZE_1024:
            Nk = 32;
            Nb = 4;
            Nr = 38;
            break;
        case KEY_SIZE_2048:
            Nk = 64;
            Nb = 4;
            Nr = 70;
            break;
        case KEY_SIZE_4096:
            Nk = 128;
            Nb = 4;
            Nr = 134;
            break;
        default:
            throw new java.lang.UnsupportedOperationException(
                    "key length can only be:128, 192 or 256");
        }

	}
	
	public byte[] createKey() {
	        byte key[] = new byte[length_pqaes/8];
	        java.util.Random rndGen = new java.util.Random();
	        rndGen.nextBytes(key);
	        return key;
	}

	public byte[] createRandomMsg() {
        byte key[] = new byte[length_pqaes/8];
        java.util.Random rndGen = new java.util.Random();
        rndGen.nextBytes(key);
        return key;
	}

	public void setkey(String key) {
		if(key.length() != (length_pqaes/4)) {
			System.out.println("Error key length on setkey");
		}else {
		this.key = toStringHex(key);
		}
	}
	public void setkey(byte [] key) {
		this.key = key;
	}
	
	int[] createKeyExpansion(String info, int length_hash, byte [] key) {
		setkey(key);
		return createKeyExpansion(info, length_hash);
	}
	
	int[] createKeyExpansion(String info, int length_hash) {
		//wordsKeyExpansion
		this.hkdf = new HKDF(info, length_hash);
		int [] wordsKeyExpansion = null;
		byte [] res = null;

		if(length_pqaes == KEY_SIZE_256) {
			wordsKeyExpansion = new int[LENGTH_EXPANSION_256/32]; //divisé par 8 et non par 32 
			res = hkdf.expand(LENGTH_EXPANSION_256, this.key);
			int j = 0;
			for(int i = 0; i < LENGTH_EXPANSION_256/8; i+=4) {
				byte [] temp = new byte[4];
				temp[0] = res[i];
				temp[1] = res[i+1];
				temp[2] = res[i+2];
				temp[3] = res[i+3];
				wordsKeyExpansion[j] = toInt(temp, 0);
				j++;
				
			}
/*			 System.out.println("length is : ");
			 System.out.println(wordsKeyExpansion.length);
			 System.out.println("key expansion is : ");

			 for(int i = 0; i < wordsKeyExpansion.length; i++) {
				 System.out.println(wordsKeyExpansion[i]+" ");
			 }			 
			System.out.println("res : "+res.length);
			System.out.println("length exp : "+LENGTH_EXPANSION_256);
			System.out.println(toHexString(res));*/
		}else 		if(length_pqaes == KEY_SIZE_512) {
			wordsKeyExpansion = new int[LENGTH_EXPANSION_512/32];
			//System.out.println("length :: "+LENGTH_EXPANSION_512);
			//System.out.println("key :: "+toHexString(key));
			res = hkdf.expand(LENGTH_EXPANSION_512, this.key);
			
			
			int j = 0;
			for(int i = 0; i < LENGTH_EXPANSION_512/8; i+=4) {
				byte [] temp = new byte[4];
				temp[0] = res[i];
				temp[1] = res[i+1];
				temp[2] = res[i+2];
				temp[3] = res[i+3];
				wordsKeyExpansion[j] = toInt(temp, 0);
				j++;
				
			}
		}else 		if(length_pqaes == KEY_SIZE_1024) {
			wordsKeyExpansion = new int[LENGTH_EXPANSION_1024/32];
		//	System.out.println("length :: "+LENGTH_EXPANSION_1024);
		//	System.out.println("key :: "+toHexString(key));
			res = hkdf.expand(LENGTH_EXPANSION_1024, this.key);
			
			
			int j = 0;
			for(int i = 0; i < LENGTH_EXPANSION_1024/8; i+=4) {
				byte [] temp = new byte[4];
				temp[0] = res[i];
				temp[1] = res[i+1];
				temp[2] = res[i+2];
				temp[3] = res[i+3];
				wordsKeyExpansion[j] = toInt(temp, 0);
				j++;
				
			}
		}else 		if(length_pqaes == KEY_SIZE_2048) {
			wordsKeyExpansion = new int[LENGTH_EXPANSION_2048/32];
			//System.out.println("length :: "+LENGTH_EXPANSION_2048);
			//System.out.println("key :: "+toHexString(key));
			res = hkdf.expand(LENGTH_EXPANSION_2048, this.key);
			
			
			int j = 0;
			for(int i = 0; i < LENGTH_EXPANSION_2048/8; i+=4) {
				byte [] temp = new byte[4];
				temp[0] = res[i];
				temp[1] = res[i+1];
				temp[2] = res[i+2];
				temp[3] = res[i+3];
				wordsKeyExpansion[j] = toInt(temp, 0);
				j++;
				
			}
		}if(length_pqaes == KEY_SIZE_4096) {
			wordsKeyExpansion = new int[LENGTH_EXPANSION_4096/32];
			//System.out.println("length :: "+LENGTH_EXPANSION_4096);
			//System.out.println("key :: "+toHexString(key));
			res = hkdf.expand(LENGTH_EXPANSION_4096, this.key);
			
			
			int j = 0;
			for(int i = 0; i < LENGTH_EXPANSION_4096/8; i+=4) {
				byte [] temp = new byte[4];
				temp[0] = res[i];
				temp[1] = res[i+1];
				temp[2] = res[i+2];
				temp[3] = res[i+3];
				wordsKeyExpansion[j] = toInt(temp, 0);
				j++;
				
			}
		}
	
		
		
		
		
		
		return wordsKeyExpansion;
	}
	
	public static int toInt(byte[] bytes, int offset) {
		  int ret = 0;
		  for (int i=0; i<4 && i+offset<bytes.length; i++) {
		    ret <<= 8;
		    ret |= (int)bytes[i] & 0xFF;
		  }
		  return ret;
		}

	
	
	
	/*CIPHER WITH WORD EXPANSION*/
    /**
     * encrypt the input message (bytesMessage)
     * the procedure is change the message in the packet format listed below, and then use aes to encrypt
     * |message size|version of richard AES|message body|
     * 0------------7---------------------11-------------
     * we need to record message size becord aes is a block cipher algorithm,
     * if you don't remember the original message size, you might get lot of 0x00 at your decrypted message.
     * @param bytesMessage byte[] message which will be encrypted
     * @param wordsKeyExpansion int[] key expansion array (generated by key byte array)
     * @return byte[] the encrypted bytes array
     */
    public byte[] cipher(byte bytesMessage[], int wordsKeyExpansion[]) {
        // create packet
       // long lMessageSize = bytesMessage.length;
        byte []bytesPacket = bytesMessage; //add by dast
        AESBlocks abk = new AESBlocks(bytesPacket);
        AESBlocks abkEncrypted = new AESBlocks(abk.getDataLength());

        byte out[][];
        for (int i = 0; i < abk.size(); i++) { 
            out = this.cipher(abk.getBlock(i), wordsKeyExpansion);
            abkEncrypted.addBlock(out);
        }

        return abkEncrypted.getBytes();
    }

    public byte[] cipher_padd(byte bytesMessage[], int wordsKeyExpansion[]) {
        // create packet
        long lMessageSize = bytesMessage.length;
        byte[] bytesPacket = new byte[bytesMessage.length+12];
        bytesPacket[0] = (byte) (0xFFl & lMessageSize);
        bytesPacket[1] = (byte) ((0xFF00l & lMessageSize) >> 8);
        bytesPacket[2] = (byte) ((0xFF0000l & lMessageSize) >> 16);
        bytesPacket[3] = (byte) ((0xFF000000l & lMessageSize) >> 24);
        bytesPacket[4] = (byte) ((0xFF00000000l & lMessageSize) >> 32);
        bytesPacket[5] = (byte) ((0xFF0000000000l & lMessageSize) >> 40);
        bytesPacket[6] = (byte) ((0xFF000000000000l & lMessageSize) >> 48);
        bytesPacket[7] = (byte) ((0xFF00000000000000l & lMessageSize) >> 56);
    	
        bytesPacket[8]  = (byte) (0xFF & m_version);
        bytesPacket[9]  = (byte) ((0x00FF & m_version) >> 8);
        bytesPacket[10] = (byte) ((0x0000FF & m_version) >> 16);
        bytesPacket[11] = (byte) ((0x000000FF & m_version) >> 24);
    	
        // copy message to packet
        for(int i = 0; i < bytesMessage.length; i++) {
            bytesPacket[i+12] = bytesMessage[i];
        }
        System.out.println("Printing padding\n");
        /*Printing padding*/
        for(int i=0; i < bytesPacket.length; i++) {
        	System.out.print(bytesPacket[i]+" ");
        }
        System.out.println("End printing padding\n");

        AESBlocks abk = new AESBlocks(bytesPacket);
        AESBlocks abkEncrypted = new AESBlocks(abk.getDataLength());

        byte out[][];
        for (int i = 0; i < abk.size(); i++) { //nanalana 1
            out = this.cipher(abk.getBlock(i), wordsKeyExpansion);
            abkEncrypted.addBlock(out);
        }
        
        return abkEncrypted.getBytes();
    }

    /**
     * encrypt the input message (bytesMessage)
     * @param bytesMessage byte[][] message which will be encrypted
     * @param wordsKeyExpansion int[] key expansion array (generated by key byte array)
     * @return byte[][]
     */
    private byte[][] cipher(byte bytesMessage[][], int wordsKeyExpansion[]) {
        byte state[][] = new byte[4][Nb];
        state = bytesMessage;
        //strTrace = "";

        //strTrace += AESMessage.getTrace("Cipher Started Initial state", state); // debug trace
        state = addRoundKey(state, wordsKeyExpansion, 0);
        //strTrace += AESMessage.getTrace("After addRoundKey", state); // debug trace

        for (int round = 1; round <= Nr - 1; round++) {
            //strTrace += AESMessage.getTrace("Round " + round + "Started"); // debug trace
            state = subBytes(state);
            //strTrace += AESMessage.getTrace("After subBytes", state); // debug trace
            state = shiftRows(state);
            //strTrace += AESMessage.getTrace("After shiftRows", state); // debug trace
            state = mixColumns(state);
            //strTrace += AESMessage.getTrace("After mixColumns", state); // debug trace
            state = addRoundKey(state, wordsKeyExpansion, round * Nb);
            //strTrace += AESMessage.getTrace("After addRoundKey", state); // debug trace
        }
        //strTrace += AESMessage.getTrace("Final round Started"); // debug trace
        state = subBytes(state);
        //strTrace += AESMessage.getTrace("After subBytes", state); // debug trace
        state = shiftRows(state);
        //strTrace += AESMessage.getTrace("After shiftRows", state); // debug trace
        state = addRoundKey(state, wordsKeyExpansion, Nr * Nb);
        //strTrace += AESMessage.getTrace("After addRoundKey", state); // debug trace
        return state;
    }

    private static byte[][] subBytes(byte state[][]) {
        for (int i = 0; i < state.length; i++)
            for (int j = 0; j < state[i].length; j++)
                state[i][j] = sboxTransform(state[i][j]);
        return state;
    }

    private static byte sboxTransform(byte value) {
        byte bUpper = 0, bLower = 0;
        bUpper = (byte) ((byte) (value >> 4) & 0x0f);
        bLower = (byte) (value & 0x0f);
        return sbox[bUpper][bLower];
    }

    private byte[][] shiftRows(byte state[][]) {
        byte stateNew[][] = new byte[state.length][state[0].length];
        // r=0 is not shifted
        stateNew[0] = state[0];
        for (int r = 1; r < state.length; r++)
            for (int c = 0; c < state[r].length; c++)
                stateNew[r][c] = state[r][(c + shift(r, Nb)) % Nb];

        return stateNew;
    }

    private static int shift(int r, int iNb) {
        return r;
    }

    private byte[][] mixColumns(byte state[][]) {
        byte stateNew[][] = new byte[state.length][state[0].length];
        for (int c = 0; c < Nb; c++) {
            stateNew[0][c] = xor4Bytes(finiteMultiplication(state[0][c], 0x02),
                                       finiteMultiplication(state[1][c], 0x03),
                                       state[2][c], state[3][c]);
            stateNew[1][c] = xor4Bytes(state[0][c],
                                       finiteMultiplication(state[1][c], 0x02),
                                       finiteMultiplication(state[2][c], 0x03),
                                       state[3][c]);
            stateNew[2][c] = xor4Bytes(state[0][c], state[1][c],
                                       finiteMultiplication(state[2][c], 0x02),
                                       finiteMultiplication(state[3][c], 0x03));
            stateNew[3][c] = xor4Bytes(finiteMultiplication(state[0][c], 0x03),
                                       state[1][c], state[2][c],
                                       finiteMultiplication(state[3][c], 0x02));
        }
        return stateNew;
    }

    private byte xor4Bytes(byte b1, byte b2, byte b3, byte b4) {
        byte bResult = 0;
        bResult ^= b1;
        bResult ^= b2;
        bResult ^= b3;
        bResult ^= b4;
        return bResult;
    }

    private byte[][] addRoundKey(byte state[][], int w[], int l) {
        byte stateNew[][] = new byte[state.length][state[0].length];
        for (int c = 0; c < Nb; c++) {
            stateNew[0][c] = (byte) (state[0][c] ^ getByte(w[l + c], 3));
            stateNew[1][c] = (byte) (state[1][c] ^ getByte(w[l + c], 2));
            stateNew[2][c] = (byte) (state[2][c] ^ getByte(w[l + c], 1));
            stateNew[3][c] = (byte) (state[3][c] ^ getByte(w[l + c], 0));
        }
        return stateNew;
    }

    // iByte is the byte number of value
    // value = |byte3|byte2|byte1|byte0|
    private byte getByte(int value, int iByte) {
        return (byte) ((value >>> (iByte * 8)) & 0x000000ff);
    }

    //No need this one , only for AES
/*    private static int subWord(int word) {
        int newWord = 0;
        newWord ^= (int) sboxTransform((byte) (word >>> 24)) & 0x000000ff;
        newWord <<= 8;

        newWord ^= (int) sboxTransform((byte) ((word & 0xff0000) >>> 16)) &
                0x000000ff;
        newWord <<= 8;

        newWord ^= (int) sboxTransform((byte) ((word & 0xff00) >>> 8)) &
                0x000000ff;
        newWord <<= 8;

        newWord ^= (int) sboxTransform((byte) (word & 0xff)) & 0x000000ff;

        return newWord;
    }

    
    private static int rotWord(int word) {
        return (word << 8) ^ ((word >> 24) & 0x000000ff);
    }

    private static int toWord(byte b1, byte b2, byte b3, byte b4) {
        int word = 0;
        word ^= ((int) b1) << 24;

        word ^= (((int) b2) & 0x000000ff) << 16;

        word ^= (((int) b3) & 0x000000ff) << 8;

        word ^= (((int) b4) & 0x000000ff);
        return word;
    }
*/
	/*END CIPHER WITH WORD EXPANSION*/
    
    
    
    /* INV CIPHER WITH WORD EXPANSION*/
    /**
     * decrypt the input message (bytesMessage)
     * the procedure is use aes to decrypt and then get the message form the packet.
     * the packet format listed below:
     * |message size|version of richard AES|message body|
     * 0------------7---------------------11-------------
     * we need to record message size becord aes is a block cipher algorithm,
     * if you don't remember the original message size, you might get lot of 0x00 at your decrypted message.
     * @param bytesMessage byte[] message(encrypted) which will be decrypted
     * @param wordsKeyExpansion int[] key expansion array (generated by key byte array)
     * @return byte[] the decrypted bytes array
     */
    public byte[] invCipher(byte bytesMessage[], int wordsKeyExpansion[]) {
        AESBlocks abk = new AESBlocks(bytesMessage);
        AESBlocks abkDecrypted = new AESBlocks(abk.getDataLength());

        byte out[][];
        for (int i = 0; i < abk.size(); i++) {
            out = this.invCipher(abk.getBlock(i), wordsKeyExpansion);
            abkDecrypted.addBlock(out);
        }
 
        return abkDecrypted.getBytes();
    }

    
    public byte[] invCipher_padd(byte bytesMessage[], int wordsKeyExpansion[]) {
        AESBlocks abk = new AESBlocks(bytesMessage);
        AESBlocks abkDecrypted = new AESBlocks(abk.getDataLength());

        byte out[][];
        for (int i = 0; i < abk.size(); i++) {
            out = this.invCipher(abk.getBlock(i), wordsKeyExpansion);
            abkDecrypted.addBlock(out);
        }

        // extract message size to lPacketSize
        byte bytesPacket[] = abkDecrypted.getBytes();
        long lPacketSize = (((long)bytesPacket[7]) << 56) & 0xFF00000000000000l;
        lPacketSize = lPacketSize | ((((long)bytesPacket[6]) << 48)&0x00FF000000000000l);
        lPacketSize = lPacketSize | ((((long)bytesPacket[5]) << 40)&0x0000FF0000000000l);
        lPacketSize = lPacketSize | ((((long)bytesPacket[4]) << 32)&0x000000FF00000000l);
        lPacketSize = lPacketSize | ((((long)bytesPacket[3]) << 24)&0x00000000FF000000l);
        lPacketSize = lPacketSize | ((((long)bytesPacket[2]) << 16)&0x0000000000FF0000l);
        lPacketSize = lPacketSize | ((((long)bytesPacket[1]) << 8)&0x000000000000FF00l);
        lPacketSize = lPacketSize | (((long)bytesPacket[0])&0x00000000000000FFl);
    	
        // extract version to iVersion
        int iVersion = (((int)bytesPacket[11]) << 24) & 0xFF000000;
        iVersion = iVersion | ((((int)bytesPacket[10]) << 16) & 0x00FF0000);
        iVersion = iVersion | ((((int)bytesPacket[9] ) << 8 ) & 0x0000FF00);
        iVersion = iVersion | (( (int)bytesPacket[8] ) & 0x000000FF);   
        /*
        if (this.m_version != iVersion) {
            // should do something if version conflict
            // but current is no need to process
        }
        */

    	
        // retreve messages form packet
        byte bytesResult[] = new byte[(int)lPacketSize];
        for (int i=0; i<bytesResult.length; i++) { //nanalana
            bytesResult[i] = bytesPacket[i+12];
        }
        return bytesResult;
    }

    /**
     * decrypt the input message (bytesMessage)
     * @param bytesMessage byte[][] message(encrypted) which will be decrypted
     * @param wordsKeyExpansion int[] key expansion array (generated by key byte array)
     * @return byte[][]
     */
    private byte[][] invCipher(byte bytesMessage[][], int wordsKeyExpansion[]) {
        byte state[][] = new byte[4][Nb];
        state = bytesMessage;
        //strTrace = "";

        //strTrace += AESMessage.getTrace("Inverse Cipher Started Initial state", state); // debug trace
        state = addRoundKey(state, wordsKeyExpansion, Nr * Nb);
        //strTrace += AESMessage.getTrace("After addRoundKey", state); // debug trace

        for (int round = (Nr - 1); round >= 1; round--) {
            //strTrace += AESMessage.getTrace("Round " + round + " started!"); // debug trace
            state = invShiftRows(state);
            //strTrace += AESMessage.getTrace("After invShiftRows", state); // debug trace
            state = invSubBytes(state);
            //strTrace += AESMessage.getTrace("After invSubBytes", state); // debug trace
            state = addRoundKey(state, wordsKeyExpansion, round * Nb);
            //strTrace += AESMessage.getTrace("After addRoundKey", state); // debug trace
            state = invMixColumns(state);
            //strTrace += AESMessage.getTrace("After invMixColumns", state); // debug trace
        }
        state = invShiftRows(state);
        //strTrace += AESMessage.getTrace("After invShiftRows", state); // debug trace
        state = invSubBytes(state);
        //strTrace += AESMessage.getTrace("After invSubBytes", state); // debug trace
        state = addRoundKey(state, wordsKeyExpansion, 0);
        //strTrace += AESMessage.getTrace("After addRoundKey", state); // debug trace

        return state;
    }

    private byte[][] invShiftRows(byte state[][]) {
        byte stateNew[][] = new byte[state.length][state[0].length];
        // r=0 is not shifted
        stateNew[0] = state[0];
        for (int r = 1; r < state.length; r++)
            for (int c = 0; c < state[r].length; c++)
                stateNew[r][(c + shift(r, Nb)) % Nb] = state[r][c];

        return stateNew;
    }

    private static byte[][] invSubBytes(byte state[][]) {
        for (int i = 0; i < state.length; i++)
            for (int j = 0; j < state[i].length; j++)
                state[i][j] = invSboxTransform(state[i][j]);
        return state;
    }

    private static byte invSboxTransform(byte value) {
        byte bUpper = 0, bLower = 0;
        bUpper = (byte) ((byte) (value >> 4) & 0x0f);
        bLower = (byte) (value & 0x0f);
        return sboxInv[bUpper][bLower];
    }

    private byte[][] invMixColumns(byte state[][]) {
        byte stateNew[][] = new byte[state.length][state[0].length];
        for (int c = 0; c < Nb; c++) {
            stateNew[0][c] = xor4Bytes(finiteMultiplication(state[0][c], 0x0e),
                                       finiteMultiplication(state[1][c], 0x0b),
                                       finiteMultiplication(state[2][c], 0x0d),
                                       finiteMultiplication(state[3][c], 0x09));
            stateNew[1][c] = xor4Bytes(finiteMultiplication(state[0][c], 0x09),
                                       finiteMultiplication(state[1][c], 0x0e),
                                       finiteMultiplication(state[2][c], 0x0b),
                                       finiteMultiplication(state[3][c], 0x0d));
            stateNew[2][c] = xor4Bytes(finiteMultiplication(state[0][c], 0x0d),
                                       finiteMultiplication(state[1][c], 0x09),
                                       finiteMultiplication(state[2][c], 0x0e),
                                       finiteMultiplication(state[3][c], 0x0b));
            stateNew[3][c] = xor4Bytes(finiteMultiplication(state[0][c], 0x0b),
                                       finiteMultiplication(state[1][c], 0x0d),
                                       finiteMultiplication(state[2][c], 0x09),
                                       finiteMultiplication(state[3][c], 0x0e));
        }
        return stateNew;

    }
    /*END INV CIPHER WITH KEY EXPANSION*/
    
    
    /*PADDING METHODE*/
    public byte[] padding_pkcs(byte[] input) {
    	if(input.length > (length_pqaes/8)) {
    		System.out.println("Error bloc padding pkcs");
    		return new byte[0];
    	}else if(input.length ==  (length_pqaes/8)) {
    		return input;
    	}else {
        	if(this.length_pqaes <= KEY_SIZE_2048) {
            	byte []res = new byte[this.length_pqaes/8];
            	for(int i = 0; i < input.length; i++) {
            		res[i] = input[i];
            	}
            	
            	for(int i = input.length; i<res.length;i++) {
            		res[i] = (byte) ((this.length_pqaes/8)-input.length);
            	}            	
            	return res;    		
        	}else {
        		System.out.println("Not supported by PKCS");
        		return new byte[0];
        	}    		
    	}
    }
    public byte[] padding_pkcs_inv(byte[] input) {
    	if(input.length == 0) { //surpass the bloc length on pkc
    		return new byte[0];
    	}
    	if(this.length_pqaes <= PQ_AES.KEY_SIZE_2048) {
        	/* Testing for case one */
        	if(input[input.length-1] == 1) {
            	if(input[input.length-1] != 1) {
            		return input; //recup all input
            	}
        	}

        	int j = input.length-1;
        	while((input[j] == input[j-1])&(j>1)) {
        		j--;
        	}
        	/*if all similar of length or if all zero return tab void*/
        	//System.out.println("Comparing PKC INV "+input[j]+" VS "+(byte)(((this.length_pqaes/8))%256));
        	
        	if(input[j] == (byte)((this.length_pqaes/8))%256) {
        		//System.out.println("here extrem case");
        		return new byte[0];
        	}
        	//TONGA ETO VE
        	
        	int length_res = j++;
        	//System.out.println("HERE  TROP  "+(int)(input[length_res]&0xFF));
        	if(((this.length_pqaes/8)-(int)(input[length_res]&0xFF))  == length_res) {
            	byte []res = new byte[length_res];
            	for(int i= 0; i <res.length;i++) {
            		res[i] = input[i];
            	}
            	return res;    		
        	}else {
        		return input; //recup all input    		
        	}    		
    	}
    	
    	return new byte[0]; //NOT SUPPORTED FOR > 4096
    }

    public byte[] padding_ansi_x923(byte[] input) {
    	if(input.length > (length_pqaes/8)) {
    		System.out.println("Error bloc padding pkcs");
    		return new byte[0];
    	}else if(input.length ==  (length_pqaes/8)) {
    		return input;
    	}else {
        	if(this.length_pqaes <= KEY_SIZE_2048) {
            	byte []res = new byte[this.length_pqaes/8];
            	for(int i = 0; i < input.length; i++) {
            		res[i] = input[i];
            	}
            	
            	for(int i = input.length; i<res.length-1;i++) {
            		res[i] = 0;
            	}
        		res[res.length-1] = (byte) ((this.length_pqaes/8)-input.length);
            	
            	return res;
        	}else {
        		
        		//verif to be added
        		if(input.length ==  ((length_pqaes/8)-1)) {
            		return input;
        		}

        		//System.out.println("here");
            	byte []res = new byte[this.length_pqaes/8];
            	for(int i = 0; i < input.length; i++) {
            		res[i] = input[i];
            	}
            	
            	for(int i = input.length; i<res.length-2;i++) {
            		res[i] = 0;
            	}
            	res[res.length-2] = (byte) ((int) ((this.length_pqaes/8)-input.length)/256);
            	res[res.length-1] =  ((byte) ((((int) ((this.length_pqaes/8)-input.length))%256)));
             //	System.out.println("here :: "+res[res.length-2]+" vs "+(0xFF&(res[res.length-1])));

            	
            	return res;
        		      		
          	}
    	}
    }


	public byte[] padding_ansi_x923_inv(byte[] input) {
    	if(input.length == 0) {
    		return new byte[0];
    	}
    	
    	if(this.length_pqaes <= PQ_AES.KEY_SIZE_2048) {
        	int real_length = input[input.length-1];
        	/*last case for 2048 bit extrem case all zero*/
        	boolean allzero = true;
        	for(int i = 0; i <input.length; i++) {
        		if(input[i] != 0) {
        			allzero = false;
        		}
        	}
        	if(allzero) {
        		return new byte[0];
        	}

        	
        	//testing if padd is one
        	if(real_length == 1) {
            	byte []res = new byte[(this.length_pqaes/8)-real_length];
        		for(int i = 0; i < res.length; i++) {
        			res[i] = input[i];
        		}
        		return res;
        	}
        	
        	//cmpt the number of zero
        	int j = input.length-2;
        	int cmpt_zero = 0;

        	while((input[j] == 0)&&(j>=1)) {
        		j--;
        		cmpt_zero++;
        	}
        	if(input[j] == 0) {
        		cmpt_zero++;
        	}
        	//cmpt_zero++;
        	//TROP
        	real_length = (int)(real_length&0xFF);
        	//System.out.println("compting zero :: "+cmpt_zero+" vs real_length :: "+real_length);
        	
        	if(cmpt_zero == real_length-1) {
            	//System.out.println("cmpt :: "+cmpt_zero);
            	//System.out.println("real length :: "+real_length);
            	
            	if(real_length == (this.length_pqaes/8)%256) {
            		return new byte[0];
            	}
            	
            	byte []res = new byte[(this.length_pqaes/8)-real_length];
            	//System.out.println("length all :: "+res.length);
            	
            	for(int i = 0; i < res.length; i++) {
            		res[i] = input[i];
            	}

            	return res;    		
        	}else {
        		return input;
        	}
    	}else {
        	int real_length = (int)(0xFF&input[input.length-2])*256+(int)(0xFF&input[input.length-1]);
        	//System.out.println("real length"+real_length);
        	/*testing if padd is one*/
        	if(real_length <= 2) {
            	byte []res = new byte[(this.length_pqaes/8)-2]; //always minus two
        		for(int i = 0; i < res.length; i++) {
        			res[i] = input[i];
        		}
        		return res;
        	}
        	
        	/*cmpt the number of zero*/
        	int j = input.length-3;
        	int cmpt_zero = 0;

        	while((input[j] == 0)&&(j>=1)) {
        		j--;
        		cmpt_zero++;
        	}
        	if(input[j] == 0) {
        		cmpt_zero++;
        	}

        	//System.out.println("compting zero :: "+cmpt_zero+" vs real_length NOVAINA :: "+(real_length));
        	
        	if(cmpt_zero == real_length-2) {
//            	System.out.println("cmpt :: "+cmpt_zero);
//            	System.out.println("real length :: "+real_length);
            	
            	if(real_length == (this.length_pqaes/8)) { //sans modulo 256
            		return new byte[0];
            	}
            	
            	byte []res = new byte[(this.length_pqaes/8)-real_length];
 //           	System.out.println("length all :: "+res.length);
            	
            	for(int i = 0; i < res.length; i++) {
            		res[i] = input[i];
            	}

            	return res;    		
        	}else {
        		return input;
        	}
    		
    	}
//    	return new byte[0]; // NOT YEST SUPPORTED
    	
    }


    public byte[] padding_w3c(byte[] input) {
    	if(input.length > (length_pqaes/8)) {
    		System.out.println("Error bloc padding pkcs");
    		return new byte[0];
    	}else if(input.length ==  (length_pqaes/8)) {
    		return input;
    	}else {
        	if(this.length_pqaes <= KEY_SIZE_2048) {
            	byte []res = new byte[this.length_pqaes/8];
            	for(int i = 0; i < input.length; i++) {
            		res[i] = input[i];
            	}
            	
            	byte[] random_value = new byte[1];
            	/*generate random different of input[input.length-1]*/
            	if(input.length != 0) {
                	
                	do {
                		/*generated random number inspired : https://www.tutorialspoint.com/generate-random-bytes-in-java*/
                		Random rd = new Random();
                		 rd.nextBytes(random_value);
                	}while(random_value[0] == input[input.length-1]);
            		
            	}else {
            		/*generated random number inspired : https://www.tutorialspoint.com/generate-random-bytes-in-java*/
            		Random rd = new Random();
            		rd.nextBytes(random_value);
            	}

            	for(int i = input.length; i<res.length-1;i++) {
            		res[i] = random_value[0];
            	}
        		res[res.length-1] = (byte) ((this.length_pqaes/8)-input.length);
        		
            	return res;
        	}else {
        		
        		//verif to be added
        		if(input.length ==  ((length_pqaes/8)-1)) {
            		return input;
        		}

            	byte []res = new byte[this.length_pqaes/8];
            	for(int i = 0; i < input.length; i++) {
            		res[i] = input[i];
            	}
            	
            	byte[] random_value = new byte[1];
            	/*generate random different of input[input.length-1]*/
            	if(input.length != 0) {
                	
                	do {
                		/*generated random number inspired : https://www.tutorialspoint.com/generate-random-bytes-in-java*/
                		Random rd = new Random();
                		 rd.nextBytes(random_value);
                	}while(random_value[0] == input[input.length-1]);
            		
            	}else {
            		/*generated random number inspired : https://www.tutorialspoint.com/generate-random-bytes-in-java*/
            		Random rd = new Random();
            		rd.nextBytes(random_value);
            	}
            	
            	for(int i = input.length; i<res.length-2;i++) {
            		res[i] = random_value[0];
            	}
            	
            	res[res.length-2] = (byte) ((int) ((this.length_pqaes/8)-input.length)/256);
            	res[res.length-1] =  ((byte) ((((int) ((this.length_pqaes/8)-input.length))%256)));
             	//System.out.println("here :: "+res[res.length-2]+" vs "+(0xFF&(res[res.length-1])));

            	
            	return res;

        	}
    	}

    }

    public byte[] padding_wc3_inv(byte[] input) {
    	if(input.length == 0) {
    		return new byte[0];
    	}
    	if(this.length_pqaes <= PQ_AES.KEY_SIZE_2048) {
        	
        	int real_length = (int)(0xFF&input[input.length-1]);
        	/*verify for extrem case 2048bit */
        	boolean is_extremcase =true;
        	for(int i = 0; i<input.length-2;i++) {
        		if(input[i] != input[i+1]) {
        			is_extremcase = false;
        		}
        	}
        	if(is_extremcase) {
        		if(input[input.length-1] != 0) {
        			is_extremcase =false;
        		}
        	}
        	if(is_extremcase) {
        		return new byte[0];
        	}
        	//testing if padd is one
        	if(real_length == 1) {
            	byte []res = new byte[(this.length_pqaes/8)-real_length];
        		for(int i = 0; i < res.length; i++) {
        			res[i] = input[i];
        		}
        		return res;
        	}
        	
        	int j = input.length-2;
        	int cmpt_random = 0;
        	byte number_random = input[input.length-2];
        	while((input[j] == number_random)&&(j>=1)) {
        		j--;
        		cmpt_random++;
        	}

        	//cmpt the number of random
        	if(input[j] == number_random) {
        		cmpt_random++;
        	}
//        	System.out.println("value of j2 :: "+j);

  //      	System.out.println("compting random :: "+cmpt_random);

        	if(cmpt_random == real_length-1) {
//            	System.out.println("cmpt :: "+cmpt_random);
//            	System.out.println("real length :: "+real_length);
            	
            	if(real_length == (byte)(this.length_pqaes/8)%256) {
            		return new byte[0];
            	}
            	
            	byte []res = new byte[(this.length_pqaes/8)-real_length];
//            	System.out.println("length all :: "+res.length);
            	
            	for(int i = 0; i < res.length; i++) {
            		res[i] = input[i];
            	}

            	return res;    		
        	}else {
            	
        		return input;
        	}
    	}else {
    		int real_length = (int)(0xFF&input[input.length-2])*256+(int)(0xFF&input[input.length-1]);
 //       	System.out.println("real length "+real_length);
        	//testing if padd is one
        	if(real_length <= 2) {
//        		System.out.println("here");
            	byte []res = new byte[(this.length_pqaes/8)-2]; //always two
        		for(int i = 0; i < res.length; i++) {
        			res[i] = input[i];
        		}
        		return res;
        	}
        	int j = input.length-3;
        	int cmpt_random = 0;
        	byte number_random = input[input.length-3];
        	while((input[j] == number_random)&&(j>=1)) {
        		j--;
        		cmpt_random++;
        	}

        	//cmpt the number of random
        	if(input[j] == number_random) {
        		cmpt_random++;
        	}
//        	System.out.println("value of j2 :: "+j);

//        	System.out.println("compting random :: "+cmpt_random);

        	if(cmpt_random == real_length-2) {
//            	System.out.println("cmpt :: "+cmpt_random);
//            	System.out.println("real length :: "+real_length);
            	
            	if(real_length == (this.length_pqaes/8)) { //sans modulo
            		return new byte[0];
            	}
            	
            	byte []res = new byte[(this.length_pqaes/8)-real_length];
//            	System.out.println("length all :: "+res.length);
            	
            	for(int i = 0; i < res.length; i++) {
            		res[i] = input[i];
            	}

            	return res;    		
        	}else {
            	
        		return input;
        	}            	
    	}
    }

    
    public byte[] padding_onezero(byte[] input) {
    	if(input.length > (length_pqaes/8)) {
    		System.out.println("Error bloc padding pkcs");
    		return new byte[0];
    	}else if(input.length ==  (length_pqaes/8)) {
    		return input;
    	}else {
            	byte []res = new byte[this.length_pqaes/8];
            	for(int i = 0; i < input.length; i++) {
            		res[i] = input[i];
            	}
            	res[input.length] = (byte) 128;
            	for(int i = input.length+1; i < res.length; i++) {
            		res[i] = 0;
            	}
            	
            	return res;
    	}

    }

    public byte[] padding_onezero_inv(byte[] input) {
    	if(input.length == 0) {
    		return new byte[0];
    	}

    	int pos_stop = input.length-1;
    	
    	//testing if padd is one 
    	if(input[pos_stop] == (byte)128) {
        	byte []res = new byte[(this.length_pqaes/8)-1];
    		for(int i = 0; i < res.length; i++) {
    			res[i] = input[i];
    		}
    		return res;
    	}
    	
    	int j = input.length-1;
    	int cmpt_zero = 0;
    	while((input[j] == 0)&&(j>=1)) {
    		j--;
    		cmpt_zero++;
    	}
    	// return for void test
    	if((j==0)&&(input[0] == (byte)128)){
    		return new byte[0]; //no block case
    	}else {
    		if(input[j] == (byte)128) {
//    			System.out.println("normal case");
//    			System.out.println("number of zero "+cmpt_zero);
    			byte[]res = new byte[(this.length_pqaes/8)-cmpt_zero-1]; //remove the stop code
    			for(int i = 0; i < res.length; i++) {
    				res[i] = input[i];
    			}
    			return res;
    		}else {
    			return input;
    		}	
    	}
    }

    public byte[] padding_all(byte[] input, String method_pad) {
    	String padd_method[] = {"PKCS","ANSI_x923","W3C","OneZero"};
    	if(padd_method[0].equals(method_pad)) {
    		return padding_pkcs(input);
    	}else 	if(padd_method[1].equals(method_pad)) {
    		return padding_ansi_x923(input);
    	}else if(padd_method[2].equals(method_pad)) {
    		return padding_w3c(input);
    	}else if(padd_method[3].equals(method_pad)) {
    		return padding_onezero(input);
    	}
    	
    	return new byte[0];
    }
    
    public byte[] padding_all_inv(byte[] input, String method_pad) {
    	String padd_method[] = {"PKCS","ANSI_x923","W3C","OneZero"};
    	if(padd_method[0].equals(method_pad)) {
    		return padding_pkcs_inv(input);
    	}else 	if(padd_method[1].equals(method_pad)) {
    		return padding_ansi_x923_inv(input);
    	}else if(padd_method[2].equals(method_pad)) {
    		return padding_wc3_inv(input);
    	}else if(padd_method[3].equals(method_pad)) {
    		return padding_onezero_inv(input);
    	}
    	
    	return new byte[0];
    }
    
    public void printByte(byte[] input) {
   	 for(int i = 0; i < input.length; i++) {
   		 System.out.print(input[i]+" ");
   	 }
   	 System.out.println("\n");
    }

    public void printByte(byte[] input, String title) {
   	 System.out.println("title : "+title);
   	 for(int i = 0; i < input.length; i++) {
   		 System.out.print(input[i]+" ");
   	 }
   	 System.out.println("\n");
    }

    /* AESBLOCS CLASS*/
    public class AESBlocks {
        @SuppressWarnings("rawtypes")
		public AESBlocks(long originalDataLength) {
            m_listBlocks = new ArrayList();
            m_originalDataLength = originalDataLength;
        }

        @SuppressWarnings("rawtypes")
		private List m_listBlocks;
        private long m_originalDataLength = 0;

        @SuppressWarnings({ "rawtypes", "unchecked" })
		private void initBlocks(byte[] bytesMessage) {
            int Nb = PQ_AES.NB_VALUE;
            m_listBlocks = new ArrayList((bytesMessage.length % (4 * Nb)) + 1);

            int iRow = 0, iColumn = 0, i = 1;
            byte block[][] = new byte[4][Nb];
            block[0][0] = bytesMessage[0];

            m_originalDataLength = bytesMessage.length;

            boolean bBlockAlreadyAdded = false;

            for (i = 1; i < bytesMessage.length; i++) {
                if (i % (4 * Nb) == 0) {
                    m_listBlocks.add(block);
                    bBlockAlreadyAdded = true;
                    block = new byte[4][Nb];
                }
                iRow = i % Nb;
                iColumn = (i / 4) % Nb;
                block[iColumn][iRow] = bytesMessage[i];
                bBlockAlreadyAdded = false;
            } // end for

            if (!bBlockAlreadyAdded)
                m_listBlocks.add(block);
        }

        public AESBlocks(byte[] bytesMessage) {
            initBlocks(bytesMessage);
        }

        public AESBlocks(String sMessage) {
            try {
                initBlocks(sMessage.getBytes(DEFAULT_CHARSET));
            } catch (UnsupportedEncodingException ex) {
                throw new RuntimeException("the charset: " + DEFAULT_CHARSET +
                                           " is not supported!", ex);
            }
        }

        public int size() {
            return m_listBlocks.size();
        }

        public long getDataLength() {
            return m_originalDataLength;
        }

        public byte getValue(int iBlockIndex, int iColumn, int iRow) {
            return ((byte[][]) m_listBlocks.get(iBlockIndex))[iColumn][iRow];
        }

        public void setValue(int iBlockIndex, int iColumn, int iRow, byte value) {
            ((byte[][]) m_listBlocks.get(iBlockIndex))[iColumn][iRow] = value;
        }

        public byte[][] getBlock(int iBlockIndex) {
            return (byte[][]) m_listBlocks.get(iBlockIndex);
        }

        @SuppressWarnings("unchecked")
		public void addBlock(byte[][] block) {
            m_listBlocks.add(block);
        }

        public String toString() {
            try {
                return (new String(this.getBytes(), DEFAULT_CHARSET));
            } catch (UnsupportedEncodingException ex) {
                throw new RuntimeException("the charset: " + DEFAULT_CHARSET +
                                           " is not supported!", ex);
            }
        }

        @SuppressWarnings("rawtypes")
		public byte[] getBytes() {
            int Nb = PQ_AES.NB_VALUE;

            int iBlockSize = 4 * Nb;
            byte[] bytes = new byte[iBlockSize * this.m_listBlocks.size()];

            int iCursor = 0;
            Iterator iter = m_listBlocks.iterator();
            while (iter.hasNext()) {
                byte[][] block = (byte[][]) iter.next();
                for (int i = 0; i < iBlockSize; i++) {
                    int iRow = i % 4;
                    int iCol = (i / 4) % 4;

                    //if ( (iCursor+i) >= m_originalDataLength ) {
                    //  break;
                    //}
                    bytes[iCursor + i] = block[iCol][iRow];
                }
                iCursor += iBlockSize;
            }
            return bytes;
        }

    } // end class AESBlocks
    /*END AESBLOCKS CLASS*/
	
	byte [] iv = null;
	/*setting iv*/
	private byte [] byte_fixedlength(byte [] input) {
		
		if(input ==null) {
			return null;
		}
		if(input.length == this.length_pqaes/8) {
			return input;
		}
		
		byte [] output = new byte[this.length_pqaes/8];
		if(input.length < output.length) {
			for(int i = 0; i <output.length; i++) {
				output[i] = 0;
			}
			for(int i = input.length-1; i>= 0; i--) {
				output[output.length-1+i-(input.length-1)] = input[i];
			}
			return output;
		}
		return null;
	}
	
	public void setIV(byte []iv) {
		this.iv = byte_fixedlength(iv);
	}
	private String info;
	public void set_info(String info) {
		this.info = info;
		// ADDING BOF SECURITY
	}
	
	/*CIPHERING MODE*/
    /*CIPHERING MODE*/
	@SuppressWarnings("unused")
	public void cipher_ecb_file(String file_name_default, String file_type) throws IOException {
		String file_name = file_name_default+"."+file_type;
		String file_name2 = file_name_default+"_encECB."+file_type;

	   	
	   	int length_buffer = this.length_pqaes/8;
	  // 	System.out.println("length buffer "+length_buffer);


		
		byte[] buffer = new byte[length_buffer]; //to be modified for each encryption type
		byte[] buffer_prev = new byte[length_buffer];
		FileInputStream in = null;
		try {
			 in = new FileInputStream(file_name);
		} catch (Exception e) {
			// TODO: handle exception
		}
		if(in == null) {
			return;
		}
		
	   	 /*creating file inspired on : https://zetcode.com/java/createfile/#:~:text=The%20File%27s%20createNewFile%20method%20creates,name%20does%20not%20yet%20exist.&text=The%20createNewFile%20returns%20true%20if,the%20named%20file%20already%20exists.
	   	  * https://stackoverflow.com/questions/9620683/java-fileoutputstream-create-file-if-not-exists 
	   	  * */
	   	File yourFile = new File(file_name2);
	   	yourFile.createNewFile(); 

	   	
		FileOutputStream out = new FileOutputStream(file_name2);
		int len_input = in.read(buffer);
		int prev_len_input = -1;
		
		
		int[] wordsKeyExpansion = this.createKeyExpansion(this.info, this.length_pqaes, this.key);

		
		while(len_input != -1)
		{
		  //len_input should contain the number of bytes read in this operation.
		  //do stuff...

			 prev_len_input= len_input;
			 for(int i = 0; i< buffer.length; i++) {
				 buffer_prev[i] = buffer[i];
			 }
 			 	 			
	 		len_input = in.read(buffer);	
	 		if(len_input == -1) {
	 			 
	 			
				 byte[] buffer_prev_enc = null;
 				 if(prev_len_input != length_buffer) {
 					//Getting LAST PADDING SHOULD BE NEW INSTANCE INSTEAD OF CLASSIC LENGTH
 					 byte [] buffer_last = new byte[prev_len_input];
 					 for(int i = 0; i <buffer_last.length ; i++) {
 						 buffer_last[i] = buffer_prev[i];
 					 }
 					 buffer_prev = buffer_last;
 					 
 					 //padding for last part
 					 byte[] buffer_prev_padd = this.padding_onezero(buffer_prev);	
 					 buffer_prev_enc  = this.cipher(buffer_prev_padd, wordsKeyExpansion);
 				 }else {
 					buffer_prev_enc  = this.cipher(buffer_prev, wordsKeyExpansion);
 				 }
 				 
 				 //printing last file 
 				 out.write(buffer_prev_enc, 0, length_buffer);
 				 
 				 
 			 }else {
 				 //other case
 				 byte[] buffer_prev_enc  = this.cipher(buffer_prev, wordsKeyExpansion);
 				 out.write(buffer_prev_enc, 0, prev_len_input);
 			 }

		}
		
		in.close();
		out.close();
			
	}
	
	
	
	@SuppressWarnings("unused")
	public void invCipher_ecb_file(String file_name_default, String file_type) throws IOException {
		String file_name = file_name_default+"."+file_type;
		String file_name2 = file_name_default+"_decECB."+file_type;

	   	
	   	int length_buffer = this.length_pqaes/8;
	  // 	System.out.println("length buffer "+length_buffer);


		
		byte[] buffer = new byte[length_buffer]; //to be modified for each encryption type
		byte[] buffer_prev = new byte[length_buffer];
		FileInputStream in = null;
		try {
			 in = new FileInputStream(file_name);
		} catch (Exception e) {
			// TODO: handle exception
		}
		if(in == null) {
			return;
		}
		
	   	 /*creating file inspired on : https://zetcode.com/java/createfile/#:~:text=The%20File%27s%20createNewFile%20method%20creates,name%20does%20not%20yet%20exist.&text=The%20createNewFile%20returns%20true%20if,the%20named%20file%20already%20exists.
	   	  * https://stackoverflow.com/questions/9620683/java-fileoutputstream-create-file-if-not-exists 
	   	  * */
	   	File yourFile = new File(file_name2);
	   	yourFile.createNewFile(); 

	   	
		FileOutputStream out = new FileOutputStream(file_name2);
		int len_input = in.read(buffer);
		int prev_len_input = -1;
		
	
		int[] wordsKeyExpansion = this.createKeyExpansion(this.info, this.length_pqaes, this.key);

		
		while(len_input != -1)
		{
		  //len_input should contain the number of bytes read in this operation.
		  //do stuff...

			 prev_len_input= len_input;
			 for(int i = 0; i< buffer.length; i++) {
				 buffer_prev[i] = buffer[i];
			 }
 			 	 			
	 		len_input = in.read(buffer);	
	 		if(len_input == -1) {
				 byte[] buffer_prev_dec = null;
				 //with padding or without padding

				 //padding for last part
 				byte[] buffer_prev_dec_padd  = this.invCipher(buffer_prev, wordsKeyExpansion);
 				buffer_prev_dec = this.padding_onezero_inv(buffer_prev_dec_padd);	
 				 
 				 //printing last file 
 				 out.write(buffer_prev_dec, 0, buffer_prev_dec.length); //buffer_prev
 				 
 				 
 			 }else {
 				 //other case
				 byte[] buffer_prev_dec = this.invCipher(buffer_prev, wordsKeyExpansion);
 				 out.write(buffer_prev_dec, 0, buffer_prev_dec.length);
 			 }

		}
		
		in.close();
		out.close();
			
	}



    /*xor array bytes : https://programming-idioms.org/idiom/238/xor-byte-arrays/5801/java*/
byte [] bytes_arrays_xor(byte []input1, byte [] input2){
	byte[] result = new byte[input1.length];
	if(input1.length != input2.length) {
		return null;
	}else {
		for (int i = 0; i < input1.length; i++) {
		  result[i] = (byte) (input1[i] ^ input2[i]);
		}
		
	}
	return result;
}


/*CBC MODE*/
/*CIPHERING MODE*/
@SuppressWarnings("unused")
public void cipher_cbc_file(String file_name_default, String file_type) throws IOException {
	String file_name = file_name_default+"."+file_type;
	String file_name2 = file_name_default+"_encCBC."+file_type;

   	
   	int length_buffer = this.length_pqaes/8;
  // 	System.out.println("length buffer "+length_buffer);
   	
   	/*intialisation of iv*/

   	byte[] iv = new byte[length_buffer]; //to be modified for each encryption type
   	if(this.iv == null) {
	   	for (int i = 0; i <iv.length; i++) {
			iv[i] = 0;
		}	   		
   	}else {
	   	for (int i = 0; i <iv.length; i++) {
			iv[i] = this.iv[i];
		}
   	}
	
	byte [] next_chain = iv;
	
	byte[] buffer = new byte[length_buffer]; //to be modified for each encryption type
	byte[] buffer_prev = new byte[length_buffer];
	FileInputStream in = null;
	try {
		 in = new FileInputStream(file_name);
	} catch (Exception e) {
		// TODO: handle exception
	}
	if(in == null) {
		return;
	}
	
   	 /*creating file inspired on : https://zetcode.com/java/createfile/#:~:text=The%20File%27s%20createNewFile%20method%20creates,name%20does%20not%20yet%20exist.&text=The%20createNewFile%20returns%20true%20if,the%20named%20file%20already%20exists.
   	  * https://stackoverflow.com/questions/9620683/java-fileoutputstream-create-file-if-not-exists 
   	  * */
   	File yourFile = new File(file_name2);
   	yourFile.createNewFile(); 

   	
	FileOutputStream out = new FileOutputStream(file_name2);
	int len_input = in.read(buffer);
	int prev_len_input = -1;
	
	
	int[] wordsKeyExpansion = this.createKeyExpansion(this.info, this.length_pqaes, this.key);

	
	while(len_input != -1)
	{
	  //len_input should contain the number of bytes read in this operation.
	  //do stuff...

		 prev_len_input= len_input;
		 for(int i = 0; i< buffer.length; i++) {
			 buffer_prev[i] = buffer[i];
		 }

		 /*System.out.println("Encription next cipher text\n");
			 for(int i = 0; i< next_ciphertext.length; i++) {
				 System.out.print(" "+next_ciphertext[i]);
			 }
*/
		 
 		len_input = in.read(buffer);	
 		if(len_input == -1) {
			 byte[] buffer_prev_enc = null;
				 if(prev_len_input != length_buffer) {
					 
					//Getting LAST PADDING SHOULD BE NEW INSTANCE INSTEAD OF CLASSIC LENGTH
					 byte [] buffer_last = new byte[prev_len_input];
					 for(int i = 0; i <buffer_last.length ; i++) {
						 buffer_last[i] = buffer_prev[i];
					 }
					 buffer_prev = buffer_last;

					 
					
					byte[] buffer_prev_padd = this.padding_onezero(buffer_prev);
	 				byte []to_encrypt = bytes_arrays_xor(next_chain, buffer_prev_padd);
	 				buffer_prev_enc  = this.cipher(to_encrypt, wordsKeyExpansion);
				 }else {
					byte []to_encrypt = bytes_arrays_xor(next_chain, buffer_prev);
					buffer_prev_enc  = this.cipher(to_encrypt, wordsKeyExpansion);
				 }
				 
				 //printing last file 
				 out.write(buffer_prev_enc, 0, length_buffer);
				 //copy next_ciphertext = buffer_prev_enc;
			  				 
				 
			 }else {
				 //other case
				 
				 byte []to_encrypt = bytes_arrays_xor(next_chain, buffer_prev);
				 byte[] buffer_prev_enc  = this.cipher(to_encrypt, wordsKeyExpansion);
				 out.write(buffer_prev_enc, 0, length_buffer);//prev_len_input
				 //copy next_ciphertext = buffer_prev_enc;
				 for(int i =0; i< buffer_prev_enc.length; i++) {
					next_chain[i] = buffer_prev_enc[i];
				 }
				 
				 
			 }

	}
	
	in.close();
	out.close();
		
}



@SuppressWarnings("unused")
public void invCipher_cbc_file(String file_name_default, String file_type) throws IOException {
	String file_name = file_name_default+"."+file_type;
	String file_name2 = file_name_default+"_decCBC."+file_type;

   	
   	int length_buffer = this.length_pqaes/8;
  // 	System.out.println("length buffer "+length_buffer);

   	
   	/*intialisation of iv*/
   	byte[] iv = new byte[length_buffer]; //to be modified for each encryption type
   	if(this.iv == null) {
	   	for (int i = 0; i <iv.length; i++) {
			iv[i] = 0;
		}	   		
   	}else {
	   	for (int i = 0; i <iv.length; i++) {
			iv[i] = this.iv[i];
		}
   	}
	
	byte [] next_chain = iv;


	
	byte[] buffer = new byte[length_buffer]; //to be modified for each encryption type
	byte[] buffer_prev = new byte[length_buffer];
	FileInputStream in = null;
	try {
		 in = new FileInputStream(file_name);
	} catch (Exception e) {
		// TODO: handle exception
	}
	if(in == null) {
		return;
	}
	
   	 /*creating file inspired on : https://zetcode.com/java/createfile/#:~:text=The%20File%27s%20createNewFile%20method%20creates,name%20does%20not%20yet%20exist.&text=The%20createNewFile%20returns%20true%20if,the%20named%20file%20already%20exists.
   	  * https://stackoverflow.com/questions/9620683/java-fileoutputstream-create-file-if-not-exists 
   	  * */
   	File yourFile = new File(file_name2);
   	yourFile.createNewFile(); 

   	
	FileOutputStream out = new FileOutputStream(file_name2);
	int len_input = in.read(buffer);
	int prev_len_input = -1;
	
	
	int[] wordsKeyExpansion = this.createKeyExpansion(this.info, this.length_pqaes, this.key);

	
	while(len_input != -1)
	{
	  //len_input should contain the number of bytes read in this operation.
	  //do stuff...

		 prev_len_input= len_input;
		 for(int i = 0; i< buffer.length; i++) {
			 buffer_prev[i] = buffer[i];
		 }
		
	/*	 System.out.println("Decription next cipher text\n");
			 for(int i = 0; i< next_ciphertext.length; i++) {
				 System.out.print(" "+next_ciphertext[i]);
			 }
*/
		 
 		len_input = in.read(buffer);	
 		if(len_input == -1) {
			 byte[] buffer_prev_dec = null;
			 //with padding or without padding
				
					 //padding for last part
			byte [] todecrypt =  this.invCipher(buffer_prev, wordsKeyExpansion);
				byte[] buffer_prev_dec_padd = bytes_arrays_xor(next_chain, todecrypt); 
				buffer_prev_dec = this.padding_onezero_inv(buffer_prev_dec_padd);	
				 
	
				 out.write(buffer_prev_dec, 0, buffer_prev_dec.length);
				//copy next_ciphertext=buffer_prev; 	
				 
				 
			 }else {
		
				 
				 //other case
				 byte [] todecrypt  = this.invCipher(buffer_prev, wordsKeyExpansion); 				 
			 byte[] buffer_prev_dec = bytes_arrays_xor(next_chain, todecrypt);	
			 
				 out.write(buffer_prev_dec, 0, buffer_prev_dec.length);
				//copy next_ciphertext=buffer_prev; 	
				 for(int i = 0; i<buffer_prev.length;i++) {
					next_chain[i] = buffer_prev[i];
				 } 			 
				
			}

	}
	
	in.close();
	out.close();
		
}

@SuppressWarnings("unused")
public void cipher_cfb_file(String file_name_default, String file_type) throws IOException {
	String file_name = file_name_default+"."+file_type;
	String file_name2 = file_name_default+"_encCFB."+file_type;

   	
   	int length_buffer = this.length_pqaes/8;
  // 	System.out.println("length buffer "+length_buffer);


   	/*intialisation of iv*/
   	byte[] iv = new byte[length_buffer]; //to be modified for each encryption type
   	if(this.iv == null) {
	   	for (int i = 0; i <iv.length; i++) {
			iv[i] = 0;
		}	   		
   	}else {
	   	for (int i = 0; i <iv.length; i++) {
			iv[i] = this.iv[i];
		}
   	}

   	byte [] next_chain = iv;

	
	byte[] buffer = new byte[length_buffer]; //to be modified for each encryption type
	byte[] buffer_prev = new byte[length_buffer];
	FileInputStream in = null;
	try {
		 in = new FileInputStream(file_name);
	} catch (Exception e) {
		// TODO: handle exception
	}
	if(in == null) {
		return;
	}
	
   	 /*creating file inspired on : https://zetcode.com/java/createfile/#:~:text=The%20File%27s%20createNewFile%20method%20creates,name%20does%20not%20yet%20exist.&text=The%20createNewFile%20returns%20true%20if,the%20named%20file%20already%20exists.
   	  * https://stackoverflow.com/questions/9620683/java-fileoutputstream-create-file-if-not-exists 
   	  * */
   	File yourFile = new File(file_name2);
   	yourFile.createNewFile(); 

   	
	FileOutputStream out = new FileOutputStream(file_name2);
	int len_input = in.read(buffer);
	int prev_len_input = -1;
	
	
	int[] wordsKeyExpansion = this.createKeyExpansion(this.info, this.length_pqaes, this.key);

	
	while(len_input != -1)
	{
	  //len_input should contain the number of bytes read in this operation.
	  //do stuff...

		 prev_len_input= len_input;
		 for(int i = 0; i< buffer.length; i++) {
			 buffer_prev[i] = buffer[i];
		 }
			 	 			
 		len_input = in.read(buffer);	
 		if(len_input == -1) {
 			 
 			
			 byte[] buffer_prev_enc = null;
				 if(prev_len_input != length_buffer) {
					//Getting LAST PADDING SHOULD BE NEW INSTANCE INSTEAD OF CLASSIC LENGTH
					 byte [] buffer_last = new byte[prev_len_input];
					 for(int i = 0; i <buffer_last.length ; i++) {
						 buffer_last[i] = buffer_prev[i];
					 }
					 buffer_prev = buffer_last;
					 
					 //padding for last part
					 byte[] buffer_prev_padd = this.padding_onezero(buffer_prev);	

					 byte[] toencrypt = this.cipher(next_chain, wordsKeyExpansion);
	 				 buffer_prev_enc  = bytes_arrays_xor(buffer_prev_padd, toencrypt);
	 				 				 
				 }else {
					byte[] toencrypt = this.cipher(next_chain, wordsKeyExpansion);
 				buffer_prev_enc  = bytes_arrays_xor(buffer_prev, toencrypt);
				 }
				 
				 //printing last file 
				 out.write(buffer_prev_enc, 0, length_buffer);
				// copy next_chain with buffer_prev_enc
 				 
				 
			 }else {
				 //other case
				 byte[] toencrypt = this.cipher(next_chain, wordsKeyExpansion);
				 byte[] buffer_prev_enc  = bytes_arrays_xor(buffer_prev, toencrypt);
				 out.write(buffer_prev_enc, 0, prev_len_input);
				 // copy next_chain with buffer_prev_enc
				 for(int i = 0; i < buffer_prev_enc.length; i++) {
					 next_chain[i] = buffer_prev_enc[i];
				 }
				 
			 }

	}
	
	in.close();
	out.close();
		
}


@SuppressWarnings("unused")
public void invCipher_cfb_file(String file_name_default, String file_type) throws IOException {
	String file_name = file_name_default+"."+file_type;
	String file_name2 = file_name_default+"_decFB."+file_type;

   	
   	int length_buffer = this.length_pqaes/8;
  // 	System.out.println("length buffer "+length_buffer);


   	/*intialisation of iv*/
   	byte[] iv = new byte[length_buffer]; //to be modified for each encryption type
   	if(this.iv == null) {
	   	for (int i = 0; i <iv.length; i++) {
			iv[i] = 0;
		}	   		
   	}else {
	   	for (int i = 0; i <iv.length; i++) {
			iv[i] = this.iv[i];
		}
   	}

	
	byte [] next_chain = iv;
	
	byte[] buffer = new byte[length_buffer]; //to be modified for each encryption type
	byte[] buffer_prev = new byte[length_buffer];
	FileInputStream in = null;
	try {
		 in = new FileInputStream(file_name);
	} catch (Exception e) {
		// TODO: handle exception
	}
	if(in == null) {
		return;
	}
	
   	 /*creating file inspired on : https://zetcode.com/java/createfile/#:~:text=The%20File%27s%20createNewFile%20method%20creates,name%20does%20not%20yet%20exist.&text=The%20createNewFile%20returns%20true%20if,the%20named%20file%20already%20exists.
   	  * https://stackoverflow.com/questions/9620683/java-fileoutputstream-create-file-if-not-exists 
   	  * */
   	File yourFile = new File(file_name2);
   	yourFile.createNewFile(); 

   	
	FileOutputStream out = new FileOutputStream(file_name2);
	int len_input = in.read(buffer);
	int prev_len_input = -1;
	
	
	int[] wordsKeyExpansion = this.createKeyExpansion(this.info, this.length_pqaes, this.key);

	
	while(len_input != -1)
	{
	  //len_input should contain the number of bytes read in this operation.
	  //do stuff...

		 prev_len_input= len_input;
		 for(int i = 0; i< buffer.length; i++) {
			 buffer_prev[i] = buffer[i];
		 }
			 	 			
 		len_input = in.read(buffer);	
 		if(len_input == -1) {
			 byte[] buffer_prev_dec = null;
			 //with padding or without padding

			 //padding for last part
			 
				byte [] toencrypt = this.cipher(next_chain, wordsKeyExpansion);
				byte[] buffer_prev_dec_padd  = bytes_arrays_xor(buffer_prev, toencrypt);
				buffer_prev_dec = this.padding_onezero_inv(buffer_prev_dec_padd);	
				 
				 //printing last file 
				 out.write(buffer_prev_dec, 0, buffer_prev_dec.length); //buffer_prev
				 
				 
			 }else {
				 //other case
				 byte [] toencrypt = this.cipher(next_chain, wordsKeyExpansion);
			 byte[] buffer_prev_dec = bytes_arrays_xor(buffer_prev, toencrypt); 
				 out.write(buffer_prev_dec, 0, buffer_prev_dec.length);
				 // next chain is the encrypted file
				 for(int i = 0; i< buffer_prev.length; i++) {
					 next_chain[i] = buffer_prev[i];
				 }
			 }

	}
	
	in.close();
	out.close();
		
}

@SuppressWarnings("unused")
public void cipher_ofb_file(String file_name_default, String file_type) throws IOException {
	String file_name = file_name_default+"."+file_type;
	String file_name2 = file_name_default+"_encOFB."+file_type;

   	
   	int length_buffer = this.length_pqaes/8;
  // 	System.out.println("length buffer "+length_buffer);

   	/*intialisation of iv*/
   	byte[] iv = new byte[length_buffer]; //to be modified for each encryption type
   	if(this.iv == null) {
	   	for (int i = 0; i <iv.length; i++) {
			iv[i] = 0;
		}	   		
   	}else {
	   	for (int i = 0; i <iv.length; i++) {
			iv[i] = this.iv[i];
		}
   	}
	
	byte [] next_chain = iv;

	
	byte[] buffer = new byte[length_buffer]; //to be modified for each encryption type
	byte[] buffer_prev = new byte[length_buffer];
	FileInputStream in = null;
	try {
		 in = new FileInputStream(file_name);
	} catch (Exception e) {
		// TODO: handle exception
	}
	if(in == null) {
		return;
	}
	
   	 /*creating file inspired on : https://zetcode.com/java/createfile/#:~:text=The%20File%27s%20createNewFile%20method%20creates,name%20does%20not%20yet%20exist.&text=The%20createNewFile%20returns%20true%20if,the%20named%20file%20already%20exists.
   	  * https://stackoverflow.com/questions/9620683/java-fileoutputstream-create-file-if-not-exists 
   	  * */
   	File yourFile = new File(file_name2);
   	yourFile.createNewFile(); 

   	
	FileOutputStream out = new FileOutputStream(file_name2);
	int len_input = in.read(buffer);
	int prev_len_input = -1;
	
	
	int[] wordsKeyExpansion = this.createKeyExpansion(this.info, this.length_pqaes, this.key);

	
	while(len_input != -1)
	{
	  //len_input should contain the number of bytes read in this operation.
	  //do stuff...

		 prev_len_input= len_input;
		 for(int i = 0; i< buffer.length; i++) {
			 buffer_prev[i] = buffer[i];
		 }
			 	 			
 		len_input = in.read(buffer);	
 		if(len_input == -1) {
 			 
 			
			 byte[] buffer_prev_enc = null;
				 if(prev_len_input != length_buffer) {
					//Getting LAST PADDING SHOULD BE NEW INSTANCE INSTEAD OF CLASSIC LENGTH
					 byte [] buffer_last = new byte[prev_len_input];
					 for(int i = 0; i <buffer_last.length ; i++) {
						 buffer_last[i] = buffer_prev[i];
					 }
					 buffer_prev = buffer_last;
					 
					 //padding for last part
					 byte[] buffer_prev_padd = this.padding_onezero(buffer_prev);
					 byte[] toencrypt = this.cipher(next_chain, wordsKeyExpansion);
					 buffer_prev_enc  = bytes_arrays_xor(buffer_prev_padd, toencrypt);
				 }else {
					 byte[] toencrypt = this.cipher(next_chain, wordsKeyExpansion);
					 buffer_prev_enc  = bytes_arrays_xor(buffer_prev, toencrypt);
				 }
				 
				 //printing last file 
				 out.write(buffer_prev_enc, 0, length_buffer);
				 
				 
			 }else {
				 //other case
				 byte [] toencrypt = this.cipher(next_chain, wordsKeyExpansion);
				 byte[] buffer_prev_enc  = bytes_arrays_xor(buffer_prev, toencrypt);
				 out.write(buffer_prev_enc, 0, prev_len_input);
				 //copy next_chain is toencrypt
				 for(int i = 0; i < toencrypt.length; i++) {
					 next_chain[i] = toencrypt[i];
				 }
			 }

	}
	
	in.close();
	out.close();
		
}


@SuppressWarnings("unused")
public void invCipher_ofb_file(String file_name_default, String file_type) throws IOException {
	String file_name = file_name_default+"."+file_type;
	String file_name2 = file_name_default+"_decOFB."+file_type;

   	
   	int length_buffer = this.length_pqaes/8;
  // 	System.out.println("length buffer "+length_buffer);

   	/*intialisation of iv*/
   	byte[] iv = new byte[length_buffer]; //to be modified for each encryption type
   	if(this.iv == null) {
	   	for (int i = 0; i <iv.length; i++) {
			iv[i] = 0;
		}	   		
   	}else {
	   	for (int i = 0; i <iv.length; i++) {
			iv[i] = this.iv[i];
		}
   	}
	
	byte [] next_chain = iv;

	
	byte[] buffer = new byte[length_buffer]; //to be modified for each encryption type
	byte[] buffer_prev = new byte[length_buffer];
	FileInputStream in = null;
	try {
		 in = new FileInputStream(file_name);
	} catch (Exception e) {
		// TODO: handle exception
	}
	if(in == null) {
		return;
	}
	
   	 /*creating file inspired on : https://zetcode.com/java/createfile/#:~:text=The%20File%27s%20createNewFile%20method%20creates,name%20does%20not%20yet%20exist.&text=The%20createNewFile%20returns%20true%20if,the%20named%20file%20already%20exists.
   	  * https://stackoverflow.com/questions/9620683/java-fileoutputstream-create-file-if-not-exists 
   	  * */
   	File yourFile = new File(file_name2);
   	yourFile.createNewFile(); 

   	
	FileOutputStream out = new FileOutputStream(file_name2);
	int len_input = in.read(buffer);
	int prev_len_input = -1;
	
	
	int[] wordsKeyExpansion = this.createKeyExpansion(this.info, this.length_pqaes, this.key);

	
	while(len_input != -1)
	{
	  //len_input should contain the number of bytes read in this operation.
	  //do stuff...

		 prev_len_input= len_input;
		 for(int i = 0; i< buffer.length; i++) {
			 buffer_prev[i] = buffer[i];
		 }
			 	 			
 		len_input = in.read(buffer);	
 		if(len_input == -1) {
			 byte[] buffer_prev_dec = null;
			 //with padding or without padding

			 //padding for last part
			byte [] toencrypt = this.cipher(next_chain, wordsKeyExpansion);
				byte[] buffer_prev_dec_padd  = bytes_arrays_xor(buffer_prev, toencrypt);
				buffer_prev_dec = this.padding_onezero_inv(buffer_prev_dec_padd);	
				 
				 //printing last file 
				 out.write(buffer_prev_dec, 0, buffer_prev_dec.length); //buffer_prev
				 
				 
			 }else {
				 //other case
				 byte []toencrypt = this.cipher(next_chain, wordsKeyExpansion);
			 byte[] buffer_prev_dec = bytes_arrays_xor(buffer_prev, toencrypt);
				 out.write(buffer_prev_dec, 0, buffer_prev_dec.length);
				 
			 //copy next_chain is toencrypt
				 for(int i = 0; i < toencrypt.length; i++) {
					 next_chain[i] = toencrypt[i];
				 }

			 }

	}
	
	in.close();
	out.close();
		
}

	
/*need for ctr mode*/
public byte [] bytes_arrays_fixedLength_addOne(byte []input){
	byte ret = 1;
	byte []output = new byte[input.length];
	for(int i=input.length-1; i >=0; i--) {
		output[i] = (byte) (input[i]+(byte) ret);
		if((output[i] == 0)&&(ret == 1)){
			ret = 1;
		}else {
			ret = 0;
		}
	}
	return output;
}

@SuppressWarnings("unused")
public void cipher_ctr_file(String file_name_default, String file_type) throws IOException {
	String file_name = file_name_default+"."+file_type;
	String file_name2 = file_name_default+"_encCTR."+file_type;

   	
   	int length_buffer = this.length_pqaes/8;
  // 	System.out.println("length buffer "+length_buffer);

   	/*intialisation of counter */
	byte[] counter_cmpt = new byte[length_buffer]; //to be modified for each encryption type
	if(this.iv == null) {
		for (int i = 0; i <counter_cmpt.length; i++) {
			counter_cmpt[i] = 0;
		}			
	}else {
		for (int i = 0; i <counter_cmpt.length; i++) {
			counter_cmpt[i] = this.iv[i];
		}
	}
	counter_cmpt = bytes_arrays_fixedLength_addOne(counter_cmpt);

	byte[] buffer = new byte[length_buffer]; //to be modified for each encryption type
	byte[] buffer_prev = new byte[length_buffer];
	FileInputStream in = null;
	try {
		 in = new FileInputStream(file_name);
	} catch (Exception e) {
		// TODO: handle exception
	}
	if(in == null) {
		return;
	}
	
   	 /*creating file inspired on : https://zetcode.com/java/createfile/#:~:text=The%20File%27s%20createNewFile%20method%20creates,name%20does%20not%20yet%20exist.&text=The%20createNewFile%20returns%20true%20if,the%20named%20file%20already%20exists.
   	  * https://stackoverflow.com/questions/9620683/java-fileoutputstream-create-file-if-not-exists 
   	  * */
   	File yourFile = new File(file_name2);
   	yourFile.createNewFile(); 

	FileOutputStream out = new FileOutputStream(file_name2);
	int len_input = in.read(buffer);
	int prev_len_input = -1;
	
	
	int[] wordsKeyExpansion = this.createKeyExpansion(this.info, this.length_pqaes, this.key);

	
	while(len_input != -1)
	{
	  //len_input should contain the number of bytes read in this operation.
	  //do stuff...

				
		 prev_len_input= len_input;
		 for(int i = 0; i< buffer.length; i++) {
			 buffer_prev[i] = buffer[i];
		 }
			 	 			
 		len_input = in.read(buffer);	
 		if(len_input == -1) {
 			 
 			
			 byte[] buffer_prev_enc = null;
				 if(prev_len_input != length_buffer) {
					//Getting LAST PADDING SHOULD BE NEW INSTANCE INSTEAD OF CLASSIC LENGTH
					 byte [] buffer_last = new byte[prev_len_input];
					 for(int i = 0; i <buffer_last.length ; i++) {
						 buffer_last[i] = buffer_prev[i];
					 }
					 buffer_prev = buffer_last;
					 
					 //padding for last part
					 byte[] buffer_prev_padd = this.padding_onezero(buffer_prev);
	 				 byte [] toencrypt = this.cipher(counter_cmpt, wordsKeyExpansion);
					 buffer_prev_enc  = bytes_arrays_xor(buffer_prev_padd, toencrypt);
				 }else {
	 				byte [] toencrypt = this.cipher(counter_cmpt, wordsKeyExpansion);
					buffer_prev_enc  = bytes_arrays_xor(buffer_prev, toencrypt);
				 }
				 
				 //printing last file 
				 out.write(buffer_prev_enc, 0, length_buffer);
				 
				 
			 }else {
				 
				 //other case
				 byte [] toencrypt = this.cipher(counter_cmpt, wordsKeyExpansion);
				 byte[] buffer_prev_enc  = bytes_arrays_xor(buffer_prev, toencrypt);
				 out.write(buffer_prev_enc, 0, prev_len_input);
				 counter_cmpt = bytes_arrays_fixedLength_addOne(counter_cmpt);
			 }

	}
	
	in.close();
	out.close();
		
}

@SuppressWarnings("unused")
public void invCipher_ctr_file(String file_name_default, String file_type) throws IOException {
	String file_name = file_name_default+"."+file_type;
	String file_name2 = file_name_default+"_decCTR."+file_type;

   	
   	int length_buffer = this.length_pqaes/8;
  // 	System.out.println("length buffer "+length_buffer);

   	/*intialisation of counter */
	byte[] counter_cmpt = new byte[length_buffer]; //to be modified for each encryption type
	if(this.iv == null) {
		for (int i = 0; i <counter_cmpt.length; i++) {
			counter_cmpt[i] = 0;
		}			
	}else {
		for (int i = 0; i <counter_cmpt.length; i++) {
			counter_cmpt[i] = this.iv[i];
		}
	}
	counter_cmpt = bytes_arrays_fixedLength_addOne(counter_cmpt);
	
	
	byte[] buffer = new byte[length_buffer]; //to be modified for each encryption type
	byte[] buffer_prev = new byte[length_buffer];
	FileInputStream in = null;
	try {
		 in = new FileInputStream(file_name);
	} catch (Exception e) {
		// TODO: handle exception
	}
	if(in == null) {
		return;
	}
	
   	 /*creating file inspired on : https://zetcode.com/java/createfile/#:~:text=The%20File%27s%20createNewFile%20method%20creates,name%20does%20not%20yet%20exist.&text=The%20createNewFile%20returns%20true%20if,the%20named%20file%20already%20exists.
   	  * https://stackoverflow.com/questions/9620683/java-fileoutputstream-create-file-if-not-exists 
   	  * */
   	File yourFile = new File(file_name2);
   	yourFile.createNewFile(); 

   	
	FileOutputStream out = new FileOutputStream(file_name2);
	int len_input = in.read(buffer);
	int prev_len_input = -1;
	
	
	int[] wordsKeyExpansion = this.createKeyExpansion(this.info, this.length_pqaes, this.key);

	
	while(len_input != -1)
	{
	  //len_input should contain the number of bytes read in this operation.
	  //do stuff...

		 prev_len_input= len_input;
		 for(int i = 0; i< buffer.length; i++) {
			 buffer_prev[i] = buffer[i];
		 }
			 	 			
 		len_input = in.read(buffer);	
 		if(len_input == -1) {
			 byte[] buffer_prev_dec = null;
			 //with padding or without padding

			 //padding for last part
			byte[] toencrypt = this.cipher(counter_cmpt, wordsKeyExpansion);
				byte[] buffer_prev_dec_padd  = bytes_arrays_xor(buffer_prev, toencrypt);
				buffer_prev_dec = this.padding_onezero_inv(buffer_prev_dec_padd);	
				 
				 //printing last file 
				 out.write(buffer_prev_dec, 0, buffer_prev_dec.length); //buffer_prev
				 
				 
			 }else {
				 //other case
				 byte[] toencrypt = this.cipher(counter_cmpt, wordsKeyExpansion);
			 byte[] buffer_prev_dec = bytes_arrays_xor(buffer_prev, toencrypt);
				 out.write(buffer_prev_dec, 0, buffer_prev_dec.length);
				 counter_cmpt = bytes_arrays_fixedLength_addOne(counter_cmpt);
			 }

	}
	
	in.close();
	out.close();
		
}


/*FOR GALOIS MODE*/
/*inspired on :: https://stackoverflow.com/questions/9246326/convert-hexadecimal-string-hex-to-a-binary-string*/
/*For the conversion use : aes.toHexString(bytesKey) or aes.toHexString2(bytesKey)*/
public boolean[] toBinary(String hexer) {
	boolean [] result = new boolean[hexer.length()*4];
	int j = 0;
	for(int i = 0; i <hexer.length(); i++) {
		//System.out.println("char at "+hexer.charAt(i));
		switch ((int)hexer.charAt(i)) {
			case '0':
				result[j] = false;
				result[j+1] = false;
				result[j+2] = false;
				result[j+3] = false;  
				break;
			case '1':
				result[j] = false;
				result[j+1] = false;
				result[j+2] = false;
				result[j+3] = true;
				break;

			case '2':
				result[j] = false;
				result[j+1] = false;
				result[j+2] = true;
				result[j+3] = false;
				break;

			case '3':
				result[j] = false;
				result[j+1] = false;
				result[j+2] = true;
				result[j+3] = true;
				break;
			
			case '4':
				result[j] = false;
				result[j+1] = true;
				result[j+2] = false;
				result[j+3] = false;
				break;

			case '5':
				result[j] = false;
				result[j+1] = true;
				result[j+2] = false;
				result[j+3] = true;
				break;
				
			case '6':
				result[j] = false;
				result[j+1] = true;
				result[j+2] = true;
				result[j+3] = false;
				break;
			
			case '7':
				result[j] = false;
				result[j+1] = true;
				result[j+2] = true;
				result[j+3] = true;
				break;
				
			case '8':
				result[j] = true;
				result[j+1] = false;
				result[j+2] = false;
				result[j+3] = false;
				break;

			case '9':
				result[j] = true;
				result[j+1] = false;
				result[j+2] = false;
				result[j+3] = true;
				break;
				
			case 'A':
				result[j] = true;
				result[j+1] = false;
				result[j+2] = true;
				result[j+3] = false;
				break;
				
			case 'B':
				result[j] = true;
				result[j+1] = false;
				result[j+2] = true;
				result[j+3] = true;
				break;
				
			case 'C':
				result[j] = true;
				result[j+1] = true;
				result[j+2] = false;
				result[j+3] = false;
				break;

			case 'D':
				result[j] = true;
				result[j+1] = true;
				result[j+2] = false;
				result[j+3] = true;
				break;

			case 'E':
				result[j] = true;
				result[j+1] = true;
				result[j+2] = true;
				result[j+3] = false;
				break;

			case 'F':
				result[j] = true;
				result[j+1] = true;
				result[j+2] = true;
				result[j+3] = true;
				break;
				
		}
		j+=4;
	}
	return result;
}

/*Binary to byte and bytetobinary*/
/*inspired and modified : https://stackoverflow.com/questions/26944282/java-boolean-to-byte-and-back*/
static boolean[] toBooleanArray(byte[] bytes) {
	/* some modification : let's invert byte*/
	byte[] invert_bytes = bytes.clone();
	for(int i = 0; i <invert_bytes.length; i++) {
		invert_bytes[invert_bytes.length-1-i] = bytes[i];
	}
	bytes = invert_bytes;
	
	BitSet bits = BitSet.valueOf(bytes);
    boolean[] bools = new boolean[bytes.length * 8];
    for (int i = bits.nextSetBit(0); i != -1; i = bits.nextSetBit(i+1)) {
        bools[bools.length-1-i] = true; //some modification instead of : bools[i] = true
    }
    
    return bools;
}

static byte[] toByteArray(boolean[] bools) {
    BitSet bits = new BitSet(bools.length);
    for (int i = 0; i < bools.length; i++) {
        if (bools[bools.length-1-i]) { //some modification instead of : if (bools[i]) 
            bits.set(i);
        }
    }

    byte[] bytes = bits.toByteArray();
    if (bytes.length * 8 >= bools.length) {
    	/*some modification : should be invert*/
    	/*instead of : return bytes; */
    	byte [] result = bytes;
        byte[] result_invert = new byte[result.length];
        for(int i = 0; i < result_invert.length; i++) {
        	result_invert[result_invert.length-1-i] = result[i];
        }
        return result_invert;
    } else {
    	/*some modification : should be invert*/
    	/*instead of : return Arrays.copyOf(bytes, bools.length / 8 + (bools.length % 8 == 0 ? 0 : 1));*/
        byte [] result = Arrays.copyOf(bytes, bools.length / 8 + (bools.length % 8 == 0 ? 0 : 1));
        byte[] result_invert = new byte[result.length];
        for(int i = 0; i < result_invert.length; i++) {
        	result_invert[result_invert.length-1-i] = result[i];
        }
        return result_invert;
    }
}


//MSB -> LSB
public void print_polynome(boolean [] a) {
	for(int i=0; i<a.length; i++) {
		if(a[i] == true) {
			if(i == a.length-1) {
				System.out.print("1");					
			}else  {
				System.out.print("x^"+((a.length-1)-i)+"+");
			}
		}
	}
	System.out.println("");
}
/*evaluate a*b mod poly_irreductible in GF(2^m)*/
boolean [] finite_multiplication_galois(boolean[] a, boolean[] b, boolean[] poly_irreductible_not_modified) {
	/*multiplication inspired on : https://www.normalesup.org/~glafon/eiffel13/polynomes.pdf page 2*/
	boolean []remainder = new boolean[poly_irreductible_not_modified.length-1]; // minus one
	boolean [] result_mult = new boolean[a.length+b.length];

	/*let's rectify polynome reductible*/
	int dec = 0;
	while(poly_irreductible_not_modified[dec] != true) {
		dec++;
	}
	
	/*rectification of polynome c: 000110 --> 110*/
	boolean [] poly_irreductible =null;
	if(dec != 0) {
		poly_irreductible = new boolean[poly_irreductible_not_modified.length-dec];
		for(int i = 0; i <poly_irreductible.length; i++) {
			poly_irreductible[i] = false;
		}
		for(int i = dec; i < poly_irreductible_not_modified.length; i++) {
			poly_irreductible[i-dec] = poly_irreductible_not_modified[i];
		}
	}else {
		poly_irreductible = poly_irreductible_not_modified;
	}

	
	/*System.out.println("c : ");
	print_polynome(poly_irreductible);
	 */
	
	for(int k = 0; k < result_mult.length-1; k++) {
		boolean somme = false;
		for(int i = 0; i <= k; i++) {
			if((i<a.length)&&((k-i)<b.length)) {
				somme  = somme^(a[a.length-1-i]&&b[b.length-1-(k-i)]);
				// l'addition sera remplacé par xor
				// la multiplication sera remplacé par and
			}
		}
		result_mult[result_mult.length-1-k] = somme;
	}
	
	//print_polynome(result_mult);
	//boolean[] quotient = new boolean[result_mult.length-(poly_irreductible.length)+1];
	
	//let's add modulo c
	int pos = 0;
	while(pos <= result_mult.length - poly_irreductible.length) {
		if(result_mult[pos] == true) {
			for(int i = pos; i < pos + poly_irreductible.length; i++) {
				result_mult[i] ^= poly_irreductible[i-pos];
			}
		}
		pos++;
	}
	
	
	//print_polynome(result_mult);
	
	for(int i=result_mult.length-remainder.length; i < result_mult.length; i++) {
		remainder[i-(result_mult.length-remainder.length)] = result_mult[i];
	}
	//System.out.println("remainder length : "+remainder.length);
	//print_polynome(remainder);

	return remainder;
}


	
byte [] finite_multiplication_galois(byte[] a, byte[] b, boolean[] poly_irreductible_not_modified) {
	boolean[] result = finite_multiplication_galois(toBooleanArray(a), toBooleanArray(b), poly_irreductible_not_modified);
	return toByteArray(result);
}


/*Let's use it for more quick operation, no need to translate a and poly_irreductible boolean for each operation*/	
byte [] finite_multiplication_galois(boolean[] a, byte[] b, boolean[] poly_irreductible_not_modified) {
boolean[] result = finite_multiplication_galois(a, toBooleanArray(b), poly_irreductible_not_modified);
return toByteArray(result);
}

byte [] finite_multiplication_galois2(byte[] a, byte[] b, byte[] poly_irreductible_not_modified) {
/*	System.out.println("a1 "+toBooleanArray(a).length);
	print_polynome(toBooleanArray(a));
	System.out.println("b1 "+toBooleanArray(b).length);
	print_polynome(toBooleanArray(b));
*/
	boolean[] result = finite_multiplication_galois(toBooleanArray(a), toBooleanArray(b), toBooleanArray(poly_irreductible_not_modified));
	return toByteArray(result);
}

byte [] finite_multiplication_galois(byte[] a, byte[] b, byte[] poly_irreductible_not_modified) {
/*	System.out.println("a2 "+toBinary(toHexString2(a)).length);
    print_polynome(toBinary(toHexString2(a)));
   	System.out.println("b2 "+toBinary(toHexString2(b)).length+"->"+toHexString2(b));
    print_polynome(toBinary(toHexString2(b)));
*/	 
	boolean[] result = finite_multiplication_galois(toBinary(toHexString(a)), toBinary(toHexString(b)), toBinary(toHexString(poly_irreductible_not_modified)));
	return toByteArray(result);
}



/*CIPHERING GALOIS MODE*/
byte [] aad = null;
public void setAAD(String s) {
	setAAD(s.getBytes());
}
public void setAAD(byte [] aad) {
	if((aad ==null)||(aad.length != this.length_pqaes/8)) {
		this.aad = null;
	}
	this.aad = aad;
}
/*initialization of polynome GCM*/
boolean[] init_poly_irreductible() {
	boolean [] result = new boolean [this.length_pqaes+1];
	//initialization

	switch(this.length_pqaes) { 
		case AES.KEY_SIZE_128 : 
			//polynome will be x^128+x^7+x^2+x+1
			/*by spec and on this table : https://www.hpl.hp.com/techreports/98/HPL-98-135.pdf*/
			for(int i = 0; i < result.length;i++) {
				switch(result.length-1-i){
					case 128 : 
						result[i] = true;
						break;
					case 7:
						result[i] = true;
						break;
					case 2:
						result[i] = true;
						break;
					case 1 : 
						result[i] = true;
						break;
					case 0:
						result[i] = true;
						break;
					default : 
						result[i] = false;
				}
			}
				//print_polynome(result);
			  
			break;
		case AES.KEY_SIZE_256 : 
			// x^256+x^10+x^5+x^2+1
			for(int i = 0; i < result.length;i++) {
				switch(result.length-1-i){
					case 256 : 
						result[i] = true;
						break;
					case 10:
						result[i] = true;
						break;
					case 5:
						result[i] = true;
						break;
					case 2 : 
						result[i] = true;
						break;
					case 0:
						result[i] = true;
						break;
					default : 
						result[i] = false;
				}
			}
				//print_polynome(result);

			break;
		case AES.KEY_SIZE_512 :
			//x^512+x^8+x^5+x^2+1
			for(int i = 0; i < result.length;i++) {
				switch(result.length-1-i){
					case 512 : 
						result[i] = true;
						break;
					case 8:
						result[i] = true;
						break;
					case 5:
						result[i] = true;
						break;
					case 2 : 
						result[i] = true;
						break;
					case 0:
						result[i] = true;
						break;
					default : 
						result[i] = false;
				}
			}
				//print_polynome(result);
			
			break;
		case AES.KEY_SIZE_1024 : 
			//x^1024+x^19+x^6+x+1
			for(int i = 0; i < result.length;i++) {
				switch(result.length-1-i){
					case 1024 : 
						result[i] = true;
						break;
					case 19:
						result[i] = true;
						break;
					case 6:
						result[i] = true;
						break;
					case 1 : 
						result[i] = true;
						break;
					case 0:
						result[i] = true;
						break;
					default : 
						result[i] = false;
				}
			}
				//print_polynome(result);
			    			
			break;
		case AES.KEY_SIZE_2048 : 
			//x^2048+x^19+x^14+x^13+1
			for(int i = 0; i < result.length;i++) {
				switch(result.length-1-i){
					case 2048 : 
						result[i] = true;
						break;
					case 19:
						result[i] = true;
						break;
					case 14:
						result[i] = true;
						break;
					case 13: 
						result[i] = true;
						break;
					case 0:
						result[i] = true;
						break;
					default : 
						result[i] = false;
				}
			}
				//print_polynome(result);

			break;
		case AES.KEY_SIZE_4096 : 
			//x^4096+x^27+x^15+x+1
			for(int i = 0; i < result.length;i++) {
				switch(result.length-1-i){
					case 4096 : 
						result[i] = true;
						break;
					case 27:
						result[i] = true;
						break;
					case 15:
						result[i] = true;
						break;
					case 1: 
						result[i] = true;
						break;
					case 0:
						result[i] = true;
						break;
					default : 
						result[i] = false;
				}
			}
				//print_polynome(result);

			break;
	}
	return result;
}

byte[] byte_concat(byte []a, byte [] b) {
	if((a == null)&&(b == null))
	{
		return null;
	}else if((a == null)&&(b != null)) {
		return b.clone();
	}else if((a != null)&&(b == null)) {
		return a.clone();
	}else {
		byte []res = new byte[a.length+b.length];
		for(int i = 0; i < a.length; i++) {
			res[i] = a[i];
		}
		
		for(int i = a.length; i < b.length; i++) {
			res[i] = b[i-a.length];
		}
		return res;
	}
}

public boolean byte_is_equal(byte []a, byte[]b) {
	boolean result = true;
	byte []fixa = null;
	byte []fixb = null;
	if(a.length < b.length) {
		fixa = byte_fixedlength(a);
		fixb = b;
	}else if(a.length > b.length){
		fixa = a;
		fixb = byte_fixedlength(b);
	}else {
		fixa = a;
		fixb = b;
	}
	
	if(fixa.length != fixb.length) {
		result = false;
		return result;
	}else {
		
		for(int i = 0; i < fixa.length; i++) {
			if(fixa[i] != fixb[i]) {
				result = false;
				return result;
			}
		}
	}
	return result;
}
@SuppressWarnings("unused")
public void cipher_gcm_file(String file_name_default, String file_type) throws IOException {
	String file_name = file_name_default+"."+file_type;
	String file_name2 = file_name_default+"_encGCM."+file_type;

   	
   	int length_buffer = this.length_pqaes/8;
  // 	System.out.println("length buffer "+length_buffer);

   		
	byte[] buffer = new byte[length_buffer]; //to be modified for each encryption type
	byte[] buffer_prev = new byte[length_buffer];
	
	FileInputStream in = null;
	try {
		 in = new FileInputStream(file_name);
	} catch (Exception e) {
		// TODO: handle exception
	}
	if(in == null) {
		return;
	}
	
   	 /*creating file inspired on : https://zetcode.com/java/createfile/#:~:text=The%20File%27s%20createNewFile%20method%20creates,name%20does%20not%20yet%20exist.&text=The%20createNewFile%20returns%20true%20if,the%20named%20file%20already%20exists.
   	  * https://stackoverflow.com/questions/9620683/java-fileoutputstream-create-file-if-not-exists 
   	  * */
   	File yourFile = new File(file_name2);
   	yourFile.createNewFile(); 

	FileOutputStream out = new FileOutputStream(file_name2);
	
	int len_input = in.read(buffer);
	int prev_len_input = -1;
	
	
	int[] wordsKeyExpansion = this.createKeyExpansion(this.info, this.length_pqaes, this.key);

	/*Change place of initialization*/
	/*intializaation of counter */
	boolean [] polynome_irreductible = this.init_poly_irreductible();
	
	byte [] allzeros = new byte [this.length_pqaes/8];
	for(int i = 0; i < allzeros.length; i++) {
		allzeros[i] = 0;
	}
	boolean [] H = toBooleanArray(this.cipher(allzeros, wordsKeyExpansion));
	//System.out.println("H");
	//print_polynome(H);
	byte[] counter_cmpt = new byte[length_buffer]; //to be modified for each encryption type
	if(this.iv == null) {
		for (int i = 0; i <counter_cmpt.length; i++) {
			counter_cmpt[i] = 0;
		}			
	}else { 
		if(this.iv.length == 12) { //if 96bits
			for (int i = 0; i <counter_cmpt.length; i++) {
				counter_cmpt[i] = 0;
			}			
			
			for (int i = 0; i < iv.length; i++) {
				counter_cmpt[i] = this.iv[i];
			}
			counter_cmpt[counter_cmpt.length-1] = 1;
			
		}else {
			counter_cmpt = finite_multiplication_galois(H,this.iv, polynome_irreductible);
		}
	}
	 // need first counter for the last verification
	byte [] counter_cmpt_first = counter_cmpt.clone();
	counter_cmpt = bytes_arrays_fixedLength_addOne(counter_cmpt);

	/*next_galois_chain initialization*/
	byte [] next_galois_chain = new byte[length_buffer];
	for(int i =0; i < next_galois_chain.length;i++) {
		next_galois_chain[i] = 0;
	}
	
	byte [] aad_separate = new byte[length_buffer];

	if(this.aad != null) {
		for(int i =0; i < next_galois_chain.length;i++) {
			next_galois_chain[i] = 0;
		}
		
		int pos = 0;
		while(pos < this.aad.length) {
			for(int i = pos; i <pos+length_buffer; i++) {
					if(i < this.aad.length) {
						aad_separate[i-pos] = this.aad[i];
					}else {
						aad_separate[i-pos] = 0;
					}
			}
			//Galois hash : GHASH
			next_galois_chain = finite_multiplication_galois(H, bytes_arrays_xor(aad_separate, next_galois_chain), polynome_irreductible);
			pos += length_buffer;
		}
		
	}
	//printByte(next_galois_chain, "next galois chain");
	
	while(len_input != -1)
	{
	  //len_input should contain the number of bytes read in this operation.
	  //do stuff...
				
		 prev_len_input= len_input;
		 for(int i = 0; i< buffer.length; i++) {
			 buffer_prev[i] = buffer[i];
		 }
			 	 			
 		len_input = in.read(buffer);	
 		if(len_input == -1) {
 			 
 			
			 byte[] buffer_prev_enc = null;
				 if(prev_len_input != length_buffer) {
					//Getting LAST PADDING SHOULD BE NEW INSTANCE INSTEAD OF CLASSIC LENGTH
					 byte [] buffer_last = new byte[prev_len_input];
					 for(int i = 0; i <buffer_last.length ; i++) {
						 buffer_last[i] = buffer_prev[i];
					 }
					 buffer_prev = buffer_last;
					 
					 //padding for last part
					 byte[] buffer_prev_padd = this.padding_onezero(buffer_prev);
	 				 byte [] toencrypt = this.cipher(counter_cmpt, wordsKeyExpansion);
					 buffer_prev_enc  = bytes_arrays_xor(buffer_prev_padd, toencrypt);
				 }else {
	 				byte [] toencrypt = this.cipher(counter_cmpt, wordsKeyExpansion);
					buffer_prev_enc  = bytes_arrays_xor(buffer_prev, toencrypt);
				 }
				 
				 //printing last file 
				 out.write(buffer_prev_enc, 0, length_buffer);
				 
				 /*Writing on last file the  tag information */
				 /*GHASH*/
				next_galois_chain = finite_multiplication_galois(H, bytes_arrays_xor(buffer_prev_enc, next_galois_chain), polynome_irreductible);
				/*inspired on it : https://stackoverflow.com/questions/2183240/java-integer-to-byte-array */
				byte [] lenCT = ByteBuffer.allocate(4).putInt(buffer.length).array();
				byte [] auth_length = null;
				
				if(this.aad != null) {
	   				byte [] lenAAD = ByteBuffer.allocate(4).putInt(this.aad.length).array();
					auth_length = byte_fixedlength(byte_concat(lenCT, lenAAD));
				}else {
					auth_length = byte_fixedlength(lenCT);
				}
			 /*GHASH*/
			next_galois_chain = finite_multiplication_galois(H, bytes_arrays_xor(auth_length, next_galois_chain), polynome_irreductible);
			next_galois_chain = bytes_arrays_xor(next_galois_chain, this.cipher(counter_cmpt_first, wordsKeyExpansion));
			/*GHASH*/
			next_galois_chain = finite_multiplication_galois(H, next_galois_chain, polynome_irreductible);   			
			System.out.println("TAG : "+toHexString(next_galois_chain));
		out.write(next_galois_chain, 0, length_buffer);
			
 		
 		
 		}else {
				 
				 //other case
				 byte [] toencrypt = this.cipher(counter_cmpt, wordsKeyExpansion);
				 byte[] buffer_prev_enc  = bytes_arrays_xor(buffer_prev, toencrypt);
				 out.write(buffer_prev_enc, 0, prev_len_input);

				 counter_cmpt = bytes_arrays_fixedLength_addOne(counter_cmpt);
				 
				 /*GALOIS MODE RECCURSIVE GHASH*/
				next_galois_chain = finite_multiplication_galois(H, bytes_arrays_xor(next_galois_chain, buffer_prev_enc), polynome_irreductible);
				
			 }

	}
	
	in.close();
	out.close();
		
}



@SuppressWarnings("unused")
public boolean invCipher_gcm_file(String file_name_default, String file_type) throws IOException {
	boolean result = false;
	String file_name = file_name_default+"."+file_type;
	String file_name2 = file_name_default+"_decGCM."+file_type;
	


   	int length_buffer = this.length_pqaes/8;
  // 	System.out.println("length buffer "+length_buffer);

	
	byte[] buffer = new byte[length_buffer]; //to be modified for each encryption type
	byte[] buffer_prev = new byte[length_buffer];
	FileInputStream in = null;
	try {
		 in = new FileInputStream(file_name);
	} catch (Exception e) {
		// TODO: handle exception
	}
	if(in == null) {
		return false;
	}
	
   	 /*creating file inspired on : https://zetcode.com/java/createfile/#:~:text=The%20File%27s%20createNewFile%20method%20creates,name%20does%20not%20yet%20exist.&text=The%20createNewFile%20returns%20true%20if,the%20named%20file%20already%20exists.
   	  * https://stackoverflow.com/questions/9620683/java-fileoutputstream-create-file-if-not-exists 
   	  * */
   	File yourFile = new File(file_name2);
   	yourFile.createNewFile(); 

	FileOutputStream out = new FileOutputStream(file_name2);
	
	int len_input = in.read(buffer);
	int prev_len_input = -1;
	
	int[] wordsKeyExpansion = this.createKeyExpansion(this.info, this.length_pqaes, this.key);
	
	/*Change place of initialization*/
	/*intializaation of counter */
	boolean [] polynome_irreductible = this.init_poly_irreductible();
	
	byte [] allzeros = new byte [this.length_pqaes/8];
	for(int i = 0; i < allzeros.length; i++) {
		allzeros[i] = 0;
	}
	boolean [] H = toBooleanArray(this.cipher(allzeros, wordsKeyExpansion));
	//System.out.println("H");
	//print_polynome(H);
	byte[] counter_cmpt = new byte[length_buffer]; //to be modified for each encryption type
	if(this.iv == null) {
		for (int i = 0; i <counter_cmpt.length; i++) {
			counter_cmpt[i] = 0;
		}			
	}else { 
		if(this.iv.length == 12) { //if 96bits
			for (int i = 0; i <counter_cmpt.length; i++) {
				counter_cmpt[i] = 0;
			}			
			
			for (int i = 0; i < iv.length; i++) {
				counter_cmpt[i] = this.iv[i];
			}
			counter_cmpt[counter_cmpt.length-1] = 1;
			
		}else {
			counter_cmpt = finite_multiplication_galois(H,this.iv, polynome_irreductible);
		}
	}
	 // need first counter for the last verification
	byte [] counter_cmpt_first = counter_cmpt.clone();
	
	counter_cmpt = bytes_arrays_fixedLength_addOne(counter_cmpt);

	/*next_galois_chain initialization*/
	byte [] next_galois_chain = new byte[length_buffer];
	for(int i =0; i < next_galois_chain.length;i++) {
		next_galois_chain[i] = 0;
	}
	
	byte [] aad_separate = new byte[length_buffer];

	if(this.aad != null) {
		for(int i =0; i < next_galois_chain.length;i++) {
			next_galois_chain[i] = 0;
		}
		
		int pos = 0;
		while(pos < this.aad.length) {
			for(int i = pos; i <pos+length_buffer; i++) {
					if(i < this.aad.length) {
						aad_separate[i-pos] = this.aad[i];
					}else {
						aad_separate[i-pos] = 0;
					}
			}
			//Galois hash
			next_galois_chain = finite_multiplication_galois(H, bytes_arrays_xor(aad_separate, next_galois_chain), polynome_irreductible);
			pos += length_buffer;
		}
		
	}
	//printByte(next_galois_chain, "next galois chain");
	
	long pos_enc = 0;
	pos_enc+=length_buffer;

   	File yourFileEnc = new File(file_name);
	long length_file = yourFileEnc.length();
	
	
	while(len_input != -1)
	{
	  //len_input should contain the number of bytes read in this operation.
	  //do stuff...

		 prev_len_input= len_input;
		 for(int i = 0; i< buffer.length; i++) {
			 buffer_prev[i] = buffer[i];
		 }
			 	 			
 		len_input = in.read(buffer);	
 		if(len_input == -1) {
				//verify TAG for the last case : the GHASH should be called on the end of operation not here
			 /*Writing on last file the  tag information */
				/*inspired on it : https://stackoverflow.com/questions/2183240/java-integer-to-byte-array */
				byte [] lenCT = ByteBuffer.allocate(4).putInt(buffer.length).array();
				byte [] auth_length = null;
				
				if(this.aad != null) {
	   				byte [] lenAAD = ByteBuffer.allocate(4).putInt(this.aad.length).array();
					auth_length = byte_fixedlength(byte_concat(lenCT, lenAAD));
				}else {
					auth_length = byte_fixedlength(lenCT);
				}
				/*GHASH*/
				next_galois_chain = finite_multiplication_galois(H, bytes_arrays_xor(auth_length, next_galois_chain), polynome_irreductible);
				next_galois_chain = bytes_arrays_xor(next_galois_chain, this.cipher(counter_cmpt_first, wordsKeyExpansion));
				/*GHASH*/
				next_galois_chain = finite_multiplication_galois(H, next_galois_chain, polynome_irreductible);   			
				
				//printByte(buffer_prev, "TAG recorded");
				//System.out.println("TAG : "+toHexString(buffer_prev));

				//printByte(next_galois_chain, "TAG Calculated");
				//System.out.println("TAG : "+toHexString(next_galois_chain));
 			
				result = byte_is_equal(next_galois_chain, buffer_prev);
				//System.out.println("result : " + result);
			  				  				
			 }else {
				 //other case
				 pos_enc+=length_buffer;
//				 System.out.println(pos_enc+" vs "+length_file);
				 if(length_file == pos_enc) {
					 //before the last
					 byte[] buffer_prev_dec = null;
					 //with padding or without padding

					 //padding for last part
					byte[] toencrypt = this.cipher(counter_cmpt, wordsKeyExpansion);
	 				byte[] buffer_prev_dec_padd  = bytes_arrays_xor(buffer_prev, toencrypt);
	 				buffer_prev_dec = this.padding_onezero_inv(buffer_prev_dec_padd);	
	 				 
	 				 //printing last file 
	 				out.write(buffer_prev_dec, 0, buffer_prev_dec.length); //buffer_prev
	 				
	 				//copy on it this first operation of TAG
				 /*GHASH*/
	  				next_galois_chain = finite_multiplication_galois(H, bytes_arrays_xor(buffer_prev, next_galois_chain), polynome_irreductible);
					
	  				
				 }else {
					 
					 //other case
	 				 byte[] toencrypt = this.cipher(counter_cmpt, wordsKeyExpansion);
					 byte[] buffer_prev_dec = bytes_arrays_xor(buffer_prev, toencrypt);
	 				 out.write(buffer_prev_dec, 0, buffer_prev_dec.length);
	 				 counter_cmpt = bytes_arrays_fixedLength_addOne(counter_cmpt); 					 
					 /*GHASH*/
	  				next_galois_chain = finite_multiplication_galois(H, bytes_arrays_xor(buffer_prev, next_galois_chain), polynome_irreductible);

				 }
			 }
	}
	
	in.close();
	out.close();
	
	if(result == false) {
	   	File yourFileDec = new File(file_name2);
	   	yourFileDec.delete();
	}
	return result;
}


/*GCM_OFB : Galois Cipher Mode with OFB */
@SuppressWarnings("unused")
public void cipher_gcm_ofb_file(String file_name_default, String file_type) throws IOException {
	String file_name = file_name_default+"."+file_type;
	String file_name2 = file_name_default+"_encGCMOFB."+file_type;

   	
   	int length_buffer = this.length_pqaes/8;
  // 	System.out.println("length buffer "+length_buffer);

	byte[] buffer = new byte[length_buffer]; //to be modified for each encryption type
	byte[] buffer_prev = new byte[length_buffer];
	FileInputStream in = null;

	try {
		 in = new FileInputStream(file_name);
	} catch (Exception e) {
		// TODO: handle exception
	}
	
	if(in == null) {
		return;
	}

   	 /*creating file inspired on : https://zetcode.com/java/createfile/#:~:text=The%20File%27s%20createNewFile%20method%20creates,name%20does%20not%20yet%20exist.&text=The%20createNewFile%20returns%20true%20if,the%20named%20file%20already%20exists.
   	  * https://stackoverflow.com/questions/9620683/java-fileoutputstream-create-file-if-not-exists 
   	  * */
   	File yourFile = new File(file_name2);
   	yourFile.createNewFile(); 

   	
	FileOutputStream out = new FileOutputStream(file_name2);
	int len_input = in.read(buffer);
	int prev_len_input = -1;
	
	
	int[] wordsKeyExpansion = this.createKeyExpansion(this.info, this.length_pqaes, this.key);

	
	
	/*Change place of initialization*/
	/*intializaation of counter */
	boolean [] polynome_irreductible = this.init_poly_irreductible();
	
	byte [] allzeros = new byte [this.length_pqaes/8];
	for(int i = 0; i < allzeros.length; i++) {
		allzeros[i] = 0;
	}
	boolean [] H = toBooleanArray(this.cipher(allzeros, wordsKeyExpansion));
	//System.out.println("H");
	//print_polynome(H);
	byte[] counter_cmpt = new byte[length_buffer]; //to be modified for each encryption type
	if(this.iv == null) {
		for (int i = 0; i <counter_cmpt.length; i++) {
			counter_cmpt[i] = 0;
		}			
	}else { 
		if(this.iv.length == 12) { //if 96bits
			for (int i = 0; i <counter_cmpt.length; i++) {
				counter_cmpt[i] = 0;
			}			
			
			for (int i = 0; i < iv.length; i++) {
				counter_cmpt[i] = this.iv[i];
			}
			counter_cmpt[counter_cmpt.length-1] = 1;
			
		}else {
			counter_cmpt = finite_multiplication_galois(H,this.iv, polynome_irreductible);
		}
	}
	
	byte [] next_chain = counter_cmpt.clone();
	// need first counter for the last verification
	byte [] counter_cmpt_first = next_chain.clone();
	
	/*next_galois_chain initialization*/
	byte [] next_galois_chain = new byte[length_buffer];
	for(int i =0; i < next_galois_chain.length;i++) {
		next_galois_chain[i] = 0;
	}
	
	byte [] aad_separate = new byte[length_buffer];

	if(this.aad != null) {
		for(int i =0; i < next_galois_chain.length;i++) {
			next_galois_chain[i] = 0;
		}
		
		int pos = 0;
		while(pos < this.aad.length) {
			for(int i = pos; i <pos+length_buffer; i++) {
					if(i < this.aad.length) {
						aad_separate[i-pos] = this.aad[i];
					}else {
						aad_separate[i-pos] = 0;
					}
			}
			//Galois hash
			next_galois_chain = finite_multiplication_galois(H, bytes_arrays_xor(aad_separate, next_galois_chain), polynome_irreductible);
			pos += length_buffer;
		}
		
	}
//	printByte(next_galois_chain, "next galois chain");

	

	while(len_input != -1)
	{
	  //len_input should contain the number of bytes read in this operation.
	  //do stuff...

		 prev_len_input= len_input;
		 for(int i = 0; i< buffer.length; i++) {
			 buffer_prev[i] = buffer[i];
		 }
			 	 			
 		len_input = in.read(buffer);	
 		if(len_input == -1) {
 			 
			 byte[] buffer_prev_enc = null;
				 if(prev_len_input != length_buffer) {
					//Getting LAST PADDING SHOULD BE NEW INSTANCE INSTEAD OF CLASSIC LENGTH
					 byte [] buffer_last = new byte[prev_len_input];
					 for(int i = 0; i <buffer_last.length ; i++) {
						 buffer_last[i] = buffer_prev[i];
					 }
					 buffer_prev = buffer_last;
					 
					 //padding for last part
					 byte[] buffer_prev_padd = this.padding_onezero(buffer_prev);
					 byte[] toencrypt = this.cipher(next_chain, wordsKeyExpansion);
					 buffer_prev_enc  = bytes_arrays_xor(buffer_prev_padd, toencrypt);
				 }else {
					 byte[] toencrypt = this.cipher(next_chain, wordsKeyExpansion);
					 buffer_prev_enc  = bytes_arrays_xor(buffer_prev, toencrypt);
				 }
				 
				 //printing last file 
				 out.write(buffer_prev_enc, 0, length_buffer);
				 
				 
				 /*Writing on last file the  tag information */
				 /*GHASH*/
				next_galois_chain = finite_multiplication_galois(H, bytes_arrays_xor(buffer_prev_enc, next_galois_chain), polynome_irreductible);

				/*inspired on it : https://stackoverflow.com/questions/2183240/java-integer-to-byte-array */
				byte [] lenCT = ByteBuffer.allocate(4).putInt(buffer.length).array();
				byte [] auth_length = null;
				
				if(this.aad != null) {
	   				byte [] lenAAD = ByteBuffer.allocate(4).putInt(this.aad.length).array();
					auth_length = byte_fixedlength(byte_concat(lenCT, lenAAD));
				}else {
					auth_length = byte_fixedlength(lenCT);
				}
 			 /*GHASH*/
 			next_galois_chain = finite_multiplication_galois(H, bytes_arrays_xor(auth_length, next_galois_chain), polynome_irreductible);
	  		    next_galois_chain = bytes_arrays_xor(next_galois_chain, this.cipher(counter_cmpt_first, wordsKeyExpansion));
			    /*GHASH*/
			    next_galois_chain = finite_multiplication_galois(H, next_galois_chain, polynome_irreductible);   			
			    System.out.println("TAG : "+toHexString(next_galois_chain));
			out.write(next_galois_chain, 0, length_buffer);			 
			 }else {
				 //other case
				 byte [] toencrypt = this.cipher(next_chain, wordsKeyExpansion);
				 byte[] buffer_prev_enc  = bytes_arrays_xor(buffer_prev, toencrypt);
				 out.write(buffer_prev_enc, 0, prev_len_input);
				 //copy next_chain is toencrypt
				 for(int i = 0; i < toencrypt.length; i++) {
					 next_chain[i] = toencrypt[i];
				 }
				/*GHASH*/
	  			next_galois_chain = finite_multiplication_galois(H, bytes_arrays_xor(buffer_prev_enc, next_galois_chain), polynome_irreductible);
			 }

	}
	
	in.close();
	out.close();
		
}


/*GCM_OFB : Galois Cipher Mode with OFB */
@SuppressWarnings("unused")
public boolean invCipher_gcm_ofb_file(String file_name_default, String file_type) throws IOException {
	String file_name = file_name_default+"."+file_type;
	String file_name2 = file_name_default+"_decGCMOFB."+file_type;

   	
   	int length_buffer = this.length_pqaes/8;
  // 	System.out.println("length buffer "+length_buffer);


	
	byte[] buffer = new byte[length_buffer]; //to be modified for each encryption type
	byte[] buffer_prev = new byte[length_buffer];
	FileInputStream in = null;
	try {
		 in = new FileInputStream(file_name);
	} catch (Exception e) {
		// TODO: handle exception
	}
	
	if(in == null) {
		return false;
	}
	
   	 /*creating file inspired on : https://zetcode.com/java/createfile/#:~:text=The%20File%27s%20createNewFile%20method%20creates,name%20does%20not%20yet%20exist.&text=The%20createNewFile%20returns%20true%20if,the%20named%20file%20already%20exists.
   	  * https://stackoverflow.com/questions/9620683/java-fileoutputstream-create-file-if-not-exists 
   	  * */
   	File yourFile = new File(file_name2);
   	yourFile.createNewFile(); 

   	
	FileOutputStream out = new FileOutputStream(file_name2);
	int len_input = in.read(buffer);
	int prev_len_input = -1;
	
	
	int[] wordsKeyExpansion = this.createKeyExpansion(this.info, this.length_pqaes, this.key);

	/*Change place of initialization*/
	/*intializaation of counter */
	boolean [] polynome_irreductible = this.init_poly_irreductible();
	
	byte [] allzeros = new byte [this.length_pqaes/8];
	for(int i = 0; i < allzeros.length; i++) {
		allzeros[i] = 0;
	}
	boolean [] H = toBooleanArray(this.cipher(allzeros, wordsKeyExpansion));
	//System.out.println("H");
	//print_polynome(H);
	byte[] counter_cmpt = new byte[length_buffer]; //to be modified for each encryption type
	if(this.iv == null) {
		for (int i = 0; i <counter_cmpt.length; i++) {
			counter_cmpt[i] = 0;
		}			
	}else { 
		if(this.iv.length == 12) { //if 96bits
			for (int i = 0; i <counter_cmpt.length; i++) {
				counter_cmpt[i] = 0;
			}			
			
			for (int i = 0; i < iv.length; i++) {
				counter_cmpt[i] = this.iv[i];
			}
			counter_cmpt[counter_cmpt.length-1] = 1;
			
		}else {
			counter_cmpt = finite_multiplication_galois(H,this.iv, polynome_irreductible);
		}
	}
	
	byte [] next_chain = counter_cmpt.clone();
	// need first counter for the last verification
	byte [] counter_cmpt_first = next_chain.clone();
	
	/*next_galois_chain initialization*/
	byte [] next_galois_chain = new byte[length_buffer];
	for(int i =0; i < next_galois_chain.length;i++) {
		next_galois_chain[i] = 0;
	}
	
	byte [] aad_separate = new byte[length_buffer];

	if(this.aad != null) {
		for(int i =0; i < next_galois_chain.length;i++) {
			next_galois_chain[i] = 0;
		}
		
		int pos = 0;
		while(pos < this.aad.length) {
			for(int i = pos; i <pos+length_buffer; i++) {
					if(i < this.aad.length) {
						aad_separate[i-pos] = this.aad[i];
					}else {
						aad_separate[i-pos] = 0;
					}
			}
			//Galois hash
			next_galois_chain = finite_multiplication_galois(H, bytes_arrays_xor(aad_separate, next_galois_chain), polynome_irreductible);
			pos += length_buffer;
		}
		
	}
//	printByte(next_galois_chain, "next galois chain");
	
	long pos_enc = 0;
	pos_enc+=length_buffer;
	
   	File yourFileEnc = new File(file_name);
	long length_file = yourFileEnc.length();

	boolean result = false;

	while(len_input != -1)
	{
	  //len_input should contain the number of bytes read in this operation.
	  //do stuff...
		
		 prev_len_input= len_input;
		 for(int i = 0; i< buffer.length; i++) {
			 buffer_prev[i] = buffer[i];
		 }
			 	 			
 		len_input = in.read(buffer);	

 		
 		if(len_input == -1) {
 			//verify TAG for the last case : the GHASH should be called on the end of operation not here
			 /*Writing on last file the  tag information */
				/*inspired on it : https://stackoverflow.com/questions/2183240/java-integer-to-byte-array */
				byte [] lenCT = ByteBuffer.allocate(4).putInt(buffer.length).array();
				byte [] auth_length = null;
				
				if(this.aad != null) {
	   				byte [] lenAAD = ByteBuffer.allocate(4).putInt(this.aad.length).array();
					auth_length = byte_fixedlength(byte_concat(lenCT, lenAAD));
				}else {
					auth_length = byte_fixedlength(lenCT);
				}
				/*GHASH*/
				next_galois_chain = finite_multiplication_galois(H, bytes_arrays_xor(auth_length, next_galois_chain), polynome_irreductible);
				next_galois_chain = bytes_arrays_xor(next_galois_chain, this.cipher(counter_cmpt_first, wordsKeyExpansion));
				/*GHASH*/
				next_galois_chain = finite_multiplication_galois(H, next_galois_chain, polynome_irreductible);   			
				
				printByte(buffer_prev, "TAG recorded");
				System.out.println("TAG : "+toHexString(buffer_prev));

				printByte(next_galois_chain, "TAG Calculated");
				System.out.println("TAG : "+toHexString(next_galois_chain));
 			
				result = byte_is_equal(next_galois_chain, buffer_prev);
				System.out.println("result : " + result);
				 
			 }else {
				 pos_enc+=length_buffer;
				 //System.out.println(pos_enc+" vs "+length_file);
				 
 			 if(length_file == pos_enc) {
				 //other case
 	 			byte[] buffer_prev_dec = null;
 				 //with padding or without padding

 				 //padding for last part
 				byte [] toencrypt = this.cipher(next_chain, wordsKeyExpansion);
  				byte[] buffer_prev_dec_padd  = bytes_arrays_xor(buffer_prev, toencrypt);
  				buffer_prev_dec = this.padding_onezero_inv(buffer_prev_dec_padd);	
  				 
  				//printing last file 
  				out.write(buffer_prev_dec, 0, buffer_prev_dec.length); //buffer_prev

  				/*GHASH*/
  	  			next_galois_chain = finite_multiplication_galois(H, bytes_arrays_xor(buffer_prev, next_galois_chain), polynome_irreductible);

			 }else {
 				 //other case
 				 byte []toencrypt = this.cipher(next_chain, wordsKeyExpansion);
				 byte[] buffer_prev_dec = bytes_arrays_xor(buffer_prev, toencrypt);
 				 out.write(buffer_prev_dec, 0, buffer_prev_dec.length);
 				 
				 //copy next_chain is toencrypt
 				 for(int i = 0; i < toencrypt.length; i++) {
 					 next_chain[i] = toencrypt[i];
 				 }
 				 
  				/*GHASH*/
  	  			next_galois_chain = finite_multiplication_galois(H, bytes_arrays_xor(buffer_prev, next_galois_chain), polynome_irreductible);

			 }
			 }

	}
	
	in.close();
	out.close();
	
	if(result == false) {
	   	File yourFileDec = new File(file_name2);
	   	yourFileDec.delete();
	}
	return result;
	
}


/*GCM_CFB is Galois cipher Mode using CFB*/
@SuppressWarnings("unused")
public void cipher_gcm_cfb_file(String file_name_default, String file_type) throws IOException {
	String file_name = file_name_default+"."+file_type;
	String file_name2 = file_name_default+"_encGCMCFB."+file_type;

   	
   	int length_buffer = this.length_pqaes/8;
  // 	System.out.println("length buffer "+length_buffer);



	
	byte[] buffer = new byte[length_buffer]; //to be modified for each encryption type
	byte[] buffer_prev = new byte[length_buffer];
	FileInputStream in = null;
	try {
		 in = new FileInputStream(file_name);
	} catch (Exception e) {
		// TODO: handle exception
	}
	
	if(in == null) {
		return;
	}
	
   	 /*creating file inspired on : https://zetcode.com/java/createfile/#:~:text=The%20File%27s%20createNewFile%20method%20creates,name%20does%20not%20yet%20exist.&text=The%20createNewFile%20returns%20true%20if,the%20named%20file%20already%20exists.
   	  * https://stackoverflow.com/questions/9620683/java-fileoutputstream-create-file-if-not-exists 
   	  * */
   	File yourFile = new File(file_name2);
   	yourFile.createNewFile(); 

   	
	FileOutputStream out = new FileOutputStream(file_name2);
	int len_input = in.read(buffer);
	int prev_len_input = -1;
	
	
	int[] wordsKeyExpansion = this.createKeyExpansion(this.info, this.length_pqaes, this.key);

	
	/*Change place of initialization*/
	/*intializaation of counter */
	boolean [] polynome_irreductible = this.init_poly_irreductible();
	
	byte [] allzeros = new byte [this.length_pqaes/8];
	for(int i = 0; i < allzeros.length; i++) {
		allzeros[i] = 0;
	}
	boolean [] H = toBooleanArray(this.cipher(allzeros, wordsKeyExpansion));
	//System.out.println("H");
	//print_polynome(H);
	byte[] counter_cmpt = new byte[length_buffer]; //to be modified for each encryption type
	if(this.iv == null) {
		for (int i = 0; i <counter_cmpt.length; i++) {
			counter_cmpt[i] = 0;
		}			
	}else { 
		if(this.iv.length == 12) { //if 96bits
			for (int i = 0; i <counter_cmpt.length; i++) {
				counter_cmpt[i] = 0;
			}			
			
			for (int i = 0; i < iv.length; i++) {
				counter_cmpt[i] = this.iv[i];
			}
			counter_cmpt[counter_cmpt.length-1] = 1;
			
		}else {
			counter_cmpt = finite_multiplication_galois(H,this.iv, polynome_irreductible);
		}
	}
	
	byte [] next_chain = counter_cmpt.clone();
	// need first counter for the last verification
	byte [] counter_cmpt_first = next_chain.clone();
	
	/*next_galois_chain initialization*/
	byte [] next_galois_chain = new byte[length_buffer];
	for(int i =0; i < next_galois_chain.length;i++) {
		next_galois_chain[i] = 0;
	}
	
	byte [] aad_separate = new byte[length_buffer];

	if(this.aad != null) {
		for(int i =0; i < next_galois_chain.length;i++) {
			next_galois_chain[i] = 0;
		}
		
		int pos = 0;
		while(pos < this.aad.length) {
			for(int i = pos; i <pos+length_buffer; i++) {
					if(i < this.aad.length) {
						aad_separate[i-pos] = this.aad[i];
					}else {
						aad_separate[i-pos] = 0;
					}
			}
			//Galois hash
			next_galois_chain = finite_multiplication_galois(H, bytes_arrays_xor(aad_separate, next_galois_chain), polynome_irreductible);
			pos += length_buffer;
		}
		
	}
//	printByte(next_galois_chain, "next galois chain");

	
	
	while(len_input != -1)
	{
	  //len_input should contain the number of bytes read in this operation.
	  //do stuff...

		 prev_len_input= len_input;
		 for(int i = 0; i< buffer.length; i++) {
			 buffer_prev[i] = buffer[i];
		 }
			 	 			
 		len_input = in.read(buffer);	
 		if(len_input == -1) {
 			 
 			
			 byte[] buffer_prev_enc = null;
				 if(prev_len_input != length_buffer) {
					//Getting LAST PADDING SHOULD BE NEW INSTANCE INSTEAD OF CLASSIC LENGTH
					 byte [] buffer_last = new byte[prev_len_input];
					 for(int i = 0; i <buffer_last.length ; i++) {
						 buffer_last[i] = buffer_prev[i];
					 }
					 buffer_prev = buffer_last;
					 
					 //padding for last part
					 byte[] buffer_prev_padd = this.padding_onezero(buffer_prev);	

					 byte[] toencrypt = this.cipher(next_chain, wordsKeyExpansion);
	 				 buffer_prev_enc  = bytes_arrays_xor(buffer_prev_padd, toencrypt);
	 				 				 
				 }else {
					byte[] toencrypt = this.cipher(next_chain, wordsKeyExpansion);
 				buffer_prev_enc  = bytes_arrays_xor(buffer_prev, toencrypt);
				 }
				 
				 //printing last file 
				 out.write(buffer_prev_enc, 0, length_buffer);
				// copy next_chain with buffer_prev_enc
 				 
				 /*Writing on last file the  tag information */
				 /*GHASH*/
				next_galois_chain = finite_multiplication_galois(H, bytes_arrays_xor(buffer_prev_enc, next_galois_chain), polynome_irreductible);

				/*inspired on it : https://stackoverflow.com/questions/2183240/java-integer-to-byte-array */
				byte [] lenCT = ByteBuffer.allocate(4).putInt(buffer.length).array();
				byte [] auth_length = null;
				
				if(this.aad != null) {
	   				byte [] lenAAD = ByteBuffer.allocate(4).putInt(this.aad.length).array();
					auth_length = byte_fixedlength(byte_concat(lenCT, lenAAD));
				}else {
					auth_length = byte_fixedlength(lenCT);
				}
 			 /*GHASH*/
 			next_galois_chain = finite_multiplication_galois(H, bytes_arrays_xor(auth_length, next_galois_chain), polynome_irreductible);
	  		    next_galois_chain = bytes_arrays_xor(next_galois_chain, this.cipher(counter_cmpt_first, wordsKeyExpansion));
			    /*GHASH*/
			    next_galois_chain = finite_multiplication_galois(H, next_galois_chain, polynome_irreductible);   			
			    System.out.println("TAG : "+toHexString(next_galois_chain));
			out.write(next_galois_chain, 0, length_buffer);			 
				 
			 }else {
				 //other case
				 byte[] toencrypt = this.cipher(next_chain, wordsKeyExpansion);
				 byte[] buffer_prev_enc  = bytes_arrays_xor(buffer_prev, toencrypt);
				 out.write(buffer_prev_enc, 0, prev_len_input);
				 // copy next_chain with buffer_prev_enc
				 for(int i = 0; i < buffer_prev_enc.length; i++) {
					 next_chain[i] = buffer_prev_enc[i];
				 }
				 
				/*GHASH*/
	  			next_galois_chain = finite_multiplication_galois(H, bytes_arrays_xor(buffer_prev_enc, next_galois_chain), polynome_irreductible);

			 }

	}
	
	in.close();
	out.close();
		
}

/*Galois Cipher Mode with CFB*/
@SuppressWarnings("unused")
public boolean invCipher_gcm_cfb_file(String file_name_default, String file_type) throws IOException {
	String file_name = file_name_default+"."+file_type;
	String file_name2 = file_name_default+"_decGCMCFB."+file_type;

   	
   	int length_buffer = this.length_pqaes/8;
  // 	System.out.println("length buffer "+length_buffer);

	
	byte[] buffer = new byte[length_buffer]; //to be modified for each encryption type
	byte[] buffer_prev = new byte[length_buffer];
	FileInputStream in = null;
	try {
		 in = new FileInputStream(file_name);
	} catch (Exception e) {
		// TODO: handle exception
	}
	if(in == null) {
		return false;
	}
	
   	 /*creating file inspired on : https://zetcode.com/java/createfile/#:~:text=The%20File%27s%20createNewFile%20method%20creates,name%20does%20not%20yet%20exist.&text=The%20createNewFile%20returns%20true%20if,the%20named%20file%20already%20exists.
   	  * https://stackoverflow.com/questions/9620683/java-fileoutputstream-create-file-if-not-exists 
   	  * */
   	File yourFile = new File(file_name2);
   	yourFile.createNewFile(); 

   	
	FileOutputStream out = new FileOutputStream(file_name2);
	int len_input = in.read(buffer);
	int prev_len_input = -1;
	
	
	int[] wordsKeyExpansion = this.createKeyExpansion(this.info, this.length_pqaes, this.key);

	/*Change place of initialization*/
	/*intializaation of counter */
	boolean [] polynome_irreductible = this.init_poly_irreductible();
	
	byte [] allzeros = new byte [this.length_pqaes/8];
	for(int i = 0; i < allzeros.length; i++) {
		allzeros[i] = 0;
	}
	boolean [] H = toBooleanArray(this.cipher(allzeros, wordsKeyExpansion));
	//System.out.println("H");
	//print_polynome(H);
	byte[] counter_cmpt = new byte[length_buffer]; //to be modified for each encryption type
	if(this.iv == null) {
		for (int i = 0; i <counter_cmpt.length; i++) {
			counter_cmpt[i] = 0;
		}			
	}else { 
		if(this.iv.length == 12) { //if 96bits
			for (int i = 0; i <counter_cmpt.length; i++) {
				counter_cmpt[i] = 0;
			}			
			
			for (int i = 0; i < iv.length; i++) {
				counter_cmpt[i] = this.iv[i];
			}
			counter_cmpt[counter_cmpt.length-1] = 1;
			
		}else {
			counter_cmpt = finite_multiplication_galois(H,this.iv, polynome_irreductible);
		}
	}
	
	byte [] next_chain = counter_cmpt.clone();
	// need first counter for the last verification
	byte [] counter_cmpt_first = next_chain.clone();
	
	/*next_galois_chain initialization*/
	byte [] next_galois_chain = new byte[length_buffer];
	for(int i =0; i < next_galois_chain.length;i++) {
		next_galois_chain[i] = 0;
	}
	
	byte [] aad_separate = new byte[length_buffer];

	if(this.aad != null) {
		for(int i =0; i < next_galois_chain.length;i++) {
			next_galois_chain[i] = 0;
		}
		
		int pos = 0;
		while(pos < this.aad.length) {
			for(int i = pos; i <pos+length_buffer; i++) {
					if(i < this.aad.length) {
						aad_separate[i-pos] = this.aad[i];
					}else {
						aad_separate[i-pos] = 0;
					}
			}
			//Galois hash
			next_galois_chain = finite_multiplication_galois(H, bytes_arrays_xor(aad_separate, next_galois_chain), polynome_irreductible);
			pos += length_buffer;
		}
		
	}
//	printByte(next_galois_chain, "next galois chain");
	
	long pos_enc = 0;
	pos_enc+=length_buffer;
	
   	File yourFileEnc = new File(file_name);
	long length_file = yourFileEnc.length();

	boolean result = false;

	
	
	while(len_input != -1)
	{
	  //len_input should contain the number of bytes read in this operation.
	  //do stuff...

		 prev_len_input= len_input;
		 for(int i = 0; i< buffer.length; i++) {
			 buffer_prev[i] = buffer[i];
		 }
			 	 			
 		len_input = in.read(buffer);	
 		if(len_input == -1) {
 			//verify TAG for the last case : the GHASH should be called on the end of operation not here
			 /*Writing on last file the  tag information */
				/*inspired on it : https://stackoverflow.com/questions/2183240/java-integer-to-byte-array */
				byte [] lenCT = ByteBuffer.allocate(4).putInt(buffer.length).array();
				byte [] auth_length = null;
				
				if(this.aad != null) {
	   				byte [] lenAAD = ByteBuffer.allocate(4).putInt(this.aad.length).array();
					auth_length = byte_fixedlength(byte_concat(lenCT, lenAAD));
				}else {
					auth_length = byte_fixedlength(lenCT);
				}
				/*GHASH*/
				next_galois_chain = finite_multiplication_galois(H, bytes_arrays_xor(auth_length, next_galois_chain), polynome_irreductible);
				next_galois_chain = bytes_arrays_xor(next_galois_chain, this.cipher(counter_cmpt_first, wordsKeyExpansion));
				/*GHASH*/
				next_galois_chain = finite_multiplication_galois(H, next_galois_chain, polynome_irreductible);   			
				
				printByte(buffer_prev, "TAG recorded");
				System.out.println("TAG : "+toHexString(buffer_prev));

				printByte(next_galois_chain, "TAG Calculated");
				System.out.println("TAG : "+toHexString(next_galois_chain));
 			
				result = byte_is_equal(next_galois_chain, buffer_prev);
				System.out.println("result : " + result);

				 
			 }else {
				 pos_enc+=length_buffer;
				 if(pos_enc == length_file) {
					 byte[] buffer_prev_dec = null;
					 //with padding or without padding

					 //padding for last part
					 
	 				byte [] toencrypt = this.cipher(next_chain, wordsKeyExpansion);
	 				byte[] buffer_prev_dec_padd  = bytes_arrays_xor(buffer_prev, toencrypt);
	 				buffer_prev_dec = this.padding_onezero_inv(buffer_prev_dec_padd);	
	 				 
	 				 //printing last file 
	 				 out.write(buffer_prev_dec, 0, buffer_prev_dec.length); //buffer_prev
	  				/*GHASH*/
	  	  			next_galois_chain = finite_multiplication_galois(H, bytes_arrays_xor(buffer_prev, next_galois_chain), polynome_irreductible);

				 }else {
	 				 //other case
	 				 byte [] toencrypt = this.cipher(next_chain, wordsKeyExpansion);
					 byte[] buffer_prev_dec = bytes_arrays_xor(buffer_prev, toencrypt); 
	 				 out.write(buffer_prev_dec, 0, buffer_prev_dec.length);
	 				 // next chain is the encrypted file
	 				 for(int i = 0; i< buffer_prev.length; i++) {
	 					 next_chain[i] = buffer_prev[i];
	 				 }
	  				/*GHASH*/
	  	  			next_galois_chain = finite_multiplication_galois(H, bytes_arrays_xor(buffer_prev, next_galois_chain), polynome_irreductible);

				 }
			 }

	}
	
	in.close();
	out.close();
	if(result == false) {
	   	File yourFileDec = new File(file_name2);
	   	yourFileDec.delete();
	}
	return result;
}



/*GCM CBC : Galois Counter Mode with CBC*/
@SuppressWarnings("unused")
public void cipher_gcm_cbc_file(String file_name_default, String file_type) throws IOException {
	String file_name = file_name_default+"."+file_type;
	String file_name2 = file_name_default+"_encGCMCBC."+file_type;

   	
   	int length_buffer = this.length_pqaes/8;
  // 	System.out.println("length buffer "+length_buffer);
   	

   	byte[] buffer = new byte[length_buffer]; //to be modified for each encryption type
	byte[] buffer_prev = new byte[length_buffer];
	FileInputStream in = null;
	try {
		 in = new FileInputStream(file_name);
	} catch (Exception e) {
		// TODO: handle exception
	}
	if(in == null) {
		return;
	}
	
   	 /*creating file inspired on : https://zetcode.com/java/createfile/#:~:text=The%20File%27s%20createNewFile%20method%20creates,name%20does%20not%20yet%20exist.&text=The%20createNewFile%20returns%20true%20if,the%20named%20file%20already%20exists.
   	  * https://stackoverflow.com/questions/9620683/java-fileoutputstream-create-file-if-not-exists 
   	  * */
   	File yourFile = new File(file_name2);
   	yourFile.createNewFile(); 

	
	FileOutputStream out = new FileOutputStream(file_name2);
	int len_input = in.read(buffer);
	int prev_len_input = -1;
	
	
	int[] wordsKeyExpansion = this.createKeyExpansion(this.info, this.length_pqaes, this.key);

	/*Change place of initialization*/
	/*intializaation of counter */
	boolean [] polynome_irreductible = this.init_poly_irreductible();
	
	byte [] allzeros = new byte [this.length_pqaes/8];
	for(int i = 0; i < allzeros.length; i++) {
		allzeros[i] = 0;
	}
	boolean [] H = toBooleanArray(this.cipher(allzeros, wordsKeyExpansion));
	//System.out.println("H");
	//print_polynome(H);
	byte[] counter_cmpt = new byte[length_buffer]; //to be modified for each encryption type
	if(this.iv == null) {
		for (int i = 0; i <counter_cmpt.length; i++) {
			counter_cmpt[i] = 0;
		}			
	}else { 
		if(this.iv.length == 12) { //if 96bits
			for (int i = 0; i <counter_cmpt.length; i++) {
				counter_cmpt[i] = 0;
			}			
			
			for (int i = 0; i < iv.length; i++) {
				counter_cmpt[i] = this.iv[i];
			}
			counter_cmpt[counter_cmpt.length-1] = 1;
			
		}else {
			counter_cmpt = finite_multiplication_galois(H,this.iv, polynome_irreductible);
		}
	}
	
	byte [] next_chain = counter_cmpt.clone();
	// need first counter for the last verification
	byte [] counter_cmpt_first = next_chain.clone();
	
	/*next_galois_chain initialization*/
	byte [] next_galois_chain = new byte[length_buffer];
	for(int i =0; i < next_galois_chain.length;i++) {
		next_galois_chain[i] = 0;
	}
	
	byte [] aad_separate = new byte[length_buffer];

	if(this.aad != null) {
		for(int i =0; i < next_galois_chain.length;i++) {
			next_galois_chain[i] = 0;
		}
		
		int pos = 0;
		while(pos < this.aad.length) {
			for(int i = pos; i <pos+length_buffer; i++) {
					if(i < this.aad.length) {
						aad_separate[i-pos] = this.aad[i];
					}else {
						aad_separate[i-pos] = 0;
					}
			}
			//Galois hash
			next_galois_chain = finite_multiplication_galois(H, bytes_arrays_xor(aad_separate, next_galois_chain), polynome_irreductible);
			pos += length_buffer;
		}
		
	}
//	printByte(next_galois_chain, "next galois chain");

	while(len_input != -1)
	{
	  //len_input should contain the number of bytes read in this operation.
	  //do stuff...

		 prev_len_input= len_input;
		 for(int i = 0; i< buffer.length; i++) {
			 buffer_prev[i] = buffer[i];
		 }

		 /*System.out.println("Encription next cipher text\n");
			 for(int i = 0; i< next_ciphertext.length; i++) {
				 System.out.print(" "+next_ciphertext[i]);
			 }
*/
		 
 		len_input = in.read(buffer);	
 		if(len_input == -1) {
			 byte[] buffer_prev_enc = null;
				 if(prev_len_input != length_buffer) {
					 
					//Getting LAST PADDING SHOULD BE NEW INSTANCE INSTEAD OF CLASSIC LENGTH
					 byte [] buffer_last = new byte[prev_len_input];
					 for(int i = 0; i <buffer_last.length ; i++) {
						 buffer_last[i] = buffer_prev[i];
					 }
					 buffer_prev = buffer_last;

					 
					
					byte[] buffer_prev_padd = this.padding_onezero(buffer_prev);
	 				byte []to_encrypt = bytes_arrays_xor(next_chain, buffer_prev_padd);
	 				buffer_prev_enc  = this.cipher(to_encrypt, wordsKeyExpansion);
				 }else {
					byte []to_encrypt = bytes_arrays_xor(next_chain, buffer_prev);
					buffer_prev_enc  = this.cipher(to_encrypt, wordsKeyExpansion);
				 }
				 
				 //printing last file 
				 out.write(buffer_prev_enc, 0, length_buffer);
				 //copy next_ciphertext = buffer_prev_enc;
			 
				 /*Writing on last file the  tag information */
				 /*GHASH*/
				next_galois_chain = finite_multiplication_galois(H, bytes_arrays_xor(buffer_prev_enc, next_galois_chain), polynome_irreductible);

				/*inspired on it : https://stackoverflow.com/questions/2183240/java-integer-to-byte-array */
				byte [] lenCT = ByteBuffer.allocate(4).putInt(buffer.length).array();
				byte [] auth_length = null;
				
				if(this.aad != null) {
	   				byte [] lenAAD = ByteBuffer.allocate(4).putInt(this.aad.length).array();
					auth_length = byte_fixedlength(byte_concat(lenCT, lenAAD));
				}else {
					auth_length = byte_fixedlength(lenCT);
				}
 			 /*GHASH*/
 			next_galois_chain = finite_multiplication_galois(H, bytes_arrays_xor(auth_length, next_galois_chain), polynome_irreductible);
	  		    next_galois_chain = bytes_arrays_xor(next_galois_chain, this.cipher(counter_cmpt_first, wordsKeyExpansion));
			    /*GHASH*/
			    next_galois_chain = finite_multiplication_galois(H, next_galois_chain, polynome_irreductible);   			
			    System.out.println("TAG : "+toHexString(next_galois_chain));
			out.write(next_galois_chain, 0, length_buffer);			 

				 
			 }else {
				 //other case
				 
				 byte []to_encrypt = bytes_arrays_xor(next_chain, buffer_prev);
				 byte[] buffer_prev_enc  = this.cipher(to_encrypt, wordsKeyExpansion);
				 out.write(buffer_prev_enc, 0, length_buffer);//prev_len_input
				 //copy next_ciphertext = buffer_prev_enc;
				 for(int i =0; i< buffer_prev_enc.length; i++) {
					next_chain[i] = buffer_prev_enc[i];
				 }
				 
				 /*GHASH*/
			next_galois_chain = finite_multiplication_galois(H, bytes_arrays_xor(buffer_prev_enc, next_galois_chain), polynome_irreductible);
				 
			 }

	}
	
	in.close();
	out.close();
		
}



@SuppressWarnings("unused")
public void invCipher_gcm_cbc_file(String file_name_default, String file_type) throws IOException {
	String file_name = file_name_default+"."+file_type;
	String file_name2 = file_name_default+"_decGCMCBC."+file_type;

   	
   	int length_buffer = this.length_pqaes/8;
  // 	System.out.println("length buffer "+length_buffer);

	byte[] buffer = new byte[length_buffer]; //to be modified for each encryption type
	byte[] buffer_prev = new byte[length_buffer];
	FileInputStream in = null;
	try {
		 in = new FileInputStream(file_name);
	} catch (Exception e) {
		// TODO: handle exception
	}
	if(in == null) {
		return;
	}

   	 /*creating file inspired on : https://zetcode.com/java/createfile/#:~:text=The%20File%27s%20createNewFile%20method%20creates,name%20does%20not%20yet%20exist.&text=The%20createNewFile%20returns%20true%20if,the%20named%20file%20already%20exists.
   	  * https://stackoverflow.com/questions/9620683/java-fileoutputstream-create-file-if-not-exists 
   	  * */
   	File yourFile = new File(file_name2);
   	yourFile.createNewFile(); 

	
	FileOutputStream out = new FileOutputStream(file_name2);
	int len_input = in.read(buffer);
	int prev_len_input = -1;
	
	
	int[] wordsKeyExpansion = this.createKeyExpansion(this.info, this.length_pqaes, this.key);

	/*Change place of initialization*/
	/*intializaation of counter */
	boolean [] polynome_irreductible = this.init_poly_irreductible();
	
	byte [] allzeros = new byte [this.length_pqaes/8];
	for(int i = 0; i < allzeros.length; i++) {
		allzeros[i] = 0;
	}
	boolean [] H = toBooleanArray(this.cipher(allzeros, wordsKeyExpansion));
	//System.out.println("H");
	//print_polynome(H);
	byte[] counter_cmpt = new byte[length_buffer]; //to be modified for each encryption type
	if(this.iv == null) {
		for (int i = 0; i <counter_cmpt.length; i++) {
			counter_cmpt[i] = 0;
		}			
	}else { 
		if(this.iv.length == 12) { //if 96bits
			for (int i = 0; i <counter_cmpt.length; i++) {
				counter_cmpt[i] = 0;
			}			
			
			for (int i = 0; i < iv.length; i++) {
				counter_cmpt[i] = this.iv[i];
			}
			counter_cmpt[counter_cmpt.length-1] = 1;
			
		}else {
			counter_cmpt = finite_multiplication_galois(H,this.iv, polynome_irreductible);
		}
	}
	
	byte [] next_chain = counter_cmpt.clone();
	// need first counter for the last verification
	byte [] counter_cmpt_first = next_chain.clone();
	
	/*next_galois_chain initialization*/
	byte [] next_galois_chain = new byte[length_buffer];
	for(int i =0; i < next_galois_chain.length;i++) {
		next_galois_chain[i] = 0;
	}
	
	byte [] aad_separate = new byte[length_buffer];

	if(this.aad != null) {
		for(int i =0; i < next_galois_chain.length;i++) {
			next_galois_chain[i] = 0;
		}
		
		int pos = 0;
		while(pos < this.aad.length) {
			for(int i = pos; i <pos+length_buffer; i++) {
					if(i < this.aad.length) {
						aad_separate[i-pos] = this.aad[i];
					}else {
						aad_separate[i-pos] = 0;
					}
			}
			//Galois hash
			next_galois_chain = finite_multiplication_galois(H, bytes_arrays_xor(aad_separate, next_galois_chain), polynome_irreductible);
			pos += length_buffer;
		}
		
	}
//	printByte(next_galois_chain, "next galois chain");
	
	long pos_enc = 0;
	pos_enc+=length_buffer;
	
   	File yourFileEnc = new File(file_name);
	long length_file = yourFileEnc.length();

	boolean result = false;
	
	while(len_input != -1)
	{
	  //len_input should contain the number of bytes read in this operation.
	  //do stuff...

		 prev_len_input= len_input;
		 for(int i = 0; i< buffer.length; i++) {
			 buffer_prev[i] = buffer[i];
		 }
		
	/*	 System.out.println("Decription next cipher text\n");
			 for(int i = 0; i< next_ciphertext.length; i++) {
				 System.out.print(" "+next_ciphertext[i]);
			 }
*/
		 
 		len_input = in.read(buffer);	
 		if(len_input == -1) {
 			//verify TAG for the last case : the GHASH should be called on the end of operation not here
			 /*Writing on last file the  tag information */
				/*inspired on it : https://stackoverflow.com/questions/2183240/java-integer-to-byte-array */
				byte [] lenCT = ByteBuffer.allocate(4).putInt(buffer.length).array();
				byte [] auth_length = null;
				
				if(this.aad != null) {
	   				byte [] lenAAD = ByteBuffer.allocate(4).putInt(this.aad.length).array();
					auth_length = byte_fixedlength(byte_concat(lenCT, lenAAD));
				}else {
					auth_length = byte_fixedlength(lenCT);
				}
				/*GHASH*/
				next_galois_chain = finite_multiplication_galois(H, bytes_arrays_xor(auth_length, next_galois_chain), polynome_irreductible);
				next_galois_chain = bytes_arrays_xor(next_galois_chain, this.cipher(counter_cmpt_first, wordsKeyExpansion));
				/*GHASH*/
				next_galois_chain = finite_multiplication_galois(H, next_galois_chain, polynome_irreductible);   			
				
				printByte(buffer_prev, "TAG recorded");
				System.out.println("TAG : "+toHexString(buffer_prev));

				printByte(next_galois_chain, "TAG Calculated");
				System.out.println("TAG : "+toHexString(next_galois_chain));
 			
				result = byte_is_equal(next_galois_chain, buffer_prev);
				System.out.println("result : " + result);
				 
			 }else {
		
				 pos_enc += length_buffer;
				 if(pos_enc == length_file) {
					 byte[] buffer_prev_dec = null;
					 //with padding or without padding
					
						 //padding for last part
					byte [] todecrypt =  this.invCipher(buffer_prev, wordsKeyExpansion);
					byte[] buffer_prev_dec_padd = bytes_arrays_xor(next_chain, todecrypt); 
					buffer_prev_dec = this.padding_onezero_inv(buffer_prev_dec_padd);	
					 
		
					 out.write(buffer_prev_dec, 0, buffer_prev_dec.length);
					//copy next_ciphertext=buffer_prev; 	
	  				/*GHASH*/
	  	  			next_galois_chain = finite_multiplication_galois(H, bytes_arrays_xor(buffer_prev, next_galois_chain), polynome_irreductible);

					 
				 }else {
	 				 //other case
	 				 byte [] todecrypt  = this.invCipher(buffer_prev, wordsKeyExpansion); 				 
					 byte[] buffer_prev_dec = bytes_arrays_xor(next_chain, todecrypt);	
					 
	 				 out.write(buffer_prev_dec, 0, buffer_prev_dec.length);
	  				//copy next_ciphertext=buffer_prev; 	
	 				 for(int i = 0; i<buffer_prev.length;i++) {
	 					next_chain[i] = buffer_prev[i];
	 				 } 	
	  				/*GHASH*/
	  	  			next_galois_chain = finite_multiplication_galois(H, bytes_arrays_xor(buffer_prev, next_galois_chain), polynome_irreductible);

				 }
				
			}

	}
	
	in.close();
	out.close();
		
}


}
